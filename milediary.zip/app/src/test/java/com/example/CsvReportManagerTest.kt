package com.example

import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.domain.report.CsvReportManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream

class CsvReportManagerTest {

    @Test
    fun testParseCsvLineWithRfc4180EscapedQuotes() {
        val line = """2026-04-10,"100 Main St, Suite 200","Client ""Big Corp"" HQ",24.5,Business"""
        val tokens = CsvReportManager.parseCsvLine(line)

        assertEquals(5, tokens.size)
        assertEquals("2026-04-10", tokens[0])
        assertEquals("100 Main St, Suite 200", tokens[1])
        assertEquals("Client \"Big Corp\" HQ", tokens[2])
        assertEquals("24.5", tokens[3])
        assertEquals("Business", tokens[4])
    }

    @Test
    fun testDateNormalizationVariants() {
        // Standard ISO
        assertEquals("2026-05-12", CsvReportManager.normalizeDate("2026-05-12"))

        // Forward slash MM/DD/YYYY
        assertEquals("2026-05-12", CsvReportManager.normalizeDate("05/12/2026"))

        // Single digit M/D/YYYY
        assertEquals("2026-03-04", CsvReportManager.normalizeDate("3/4/2026"))

        // YYYY/MM/DD
        assertEquals("2026-08-20", CsvReportManager.normalizeDate("2026/08/20"))

        // Short 2-digit year MM/DD/YY
        assertEquals("2026-11-25", CsvReportManager.normalizeDate("11/25/26"))
    }

    @Test
    fun testCsvImportBatchAndDuplicateDeduplication() {
        val existingTrips = listOf(
            Trip(
                id = 1L,
                vehicleId = 1L,
                date = "2026-02-01",
                fromLoc = "Office",
                toLoc = "Client Site",
                purpose = "Consulting",
                category = TripCategory.BUSINESS,
                miles = 15.0
            )
        )

        // CSV contains:
        // 1. A duplicate of an existing trip
        // 2. A new unique trip
        // 3. A second occurrence of that new trip within the same CSV (intra-batch duplicate)
        // 4. A gig platform trip (DoorDash)
        val csv = """
Date,From,To,Purpose,Miles,Category,Platform,Tag
2026-02-01,Office,Client Site,Consulting,15.0,Business,,
2026-02-05,Airport,Hotel,Conference,18.4,Business,Lyft,TripTag
2026-02-05,Airport,Hotel,Conference,18.4,Business,Lyft,TripTag
2026-02-06,Restaurant,Customer House,Delivery,4.2,Business,DoorDash,LunchRush
        """.trimIndent()

        val stream = ByteArrayInputStream(csv.toByteArray())
        val result = CsvReportManager.parseCsv(stream, targetVehicleId = 1L, existingTrips = existingTrips)

        // 4 total parsed lines
        assertEquals(4, result.totalParsed)
        // 2 duplicates filtered (1 against existing DB, 1 intra-batch)
        assertEquals(2, result.duplicateCount)
        // 2 imported trips
        assertEquals(2, result.importedTrips.size)

        val firstImported = result.importedTrips[0]
        assertEquals("Airport", firstImported.fromLoc)
        assertEquals("Hotel", firstImported.toLoc)
        assertEquals(18.4, firstImported.miles, 0.001)
        assertEquals("Lyft", firstImported.platform)
        assertEquals("TripTag", firstImported.tag)

        val secondImported = result.importedTrips[1]
        assertEquals("DoorDash", secondImported.platform)
        assertEquals(4.2, secondImported.miles, 0.001)
    }

    @Test
    fun testCsvEscapingForExport() {
        val simple = CsvReportManager.escapeCsv("Simple Text")
        assertEquals("Simple Text", simple)

        val withComma = CsvReportManager.escapeCsv("123 Main St, Apt 4B")
        assertEquals("\"123 Main St, Apt 4B\"", withComma)

        val withQuotes = CsvReportManager.escapeCsv("Client \"Acme\"")
        assertEquals("\"Client \"\"Acme\"\"\"", withQuotes)
    }
}
