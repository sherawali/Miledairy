package com.example

import com.example.data.model.OdoBoundary
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.domain.backup.BackupManager
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BackupManagerTest {

    @Test
    fun testBackupJsonStructureValidation() {
        val jsonString = """
            {
                "appName": "MileDiary",
                "schemaVersion": 2,
                "exportedAt": 1727000000000,
                "vehicles": [
                    {
                        "id": 1,
                        "name": "Prius Prime",
                        "make": "Toyota",
                        "model": "Prius",
                        "year": "2024",
                        "isPrimary": true,
                        "createdAt": 1700000000000
                    }
                ],
                "trips": [
                    {
                        "id": 101,
                        "vehicleId": 1,
                        "date": "2026-03-15",
                        "fromLoc": "Home Office",
                        "toLoc": "Client Tech Park",
                        "miles": 22.4,
                        "purpose": "Site Architecture Review",
                        "category": "BUSINESS",
                        "isShift": false,
                        "isCommute": false,
                        "roundTrip": true,
                        "note": "Quarterly review"
                    }
                ],
                "templates": [
                    {
                        "id": 1,
                        "name": "Weekly Client Visit",
                        "fromLoc": "Home",
                        "toLoc": "Client Site",
                        "miles": 15.0,
                        "purpose": "Consulting",
                        "category": "BUSINESS"
                    }
                ],
                "boundaries": [
                    {
                        "id": 1,
                        "vehicleId": 1,
                        "year": 2026,
                        "jan1Odo": 45000.0,
                        "dec31Odo": 58500.0
                    }
                ],
                "settings": {
                    "user_name": "Jane Taxpayer",
                    "tax_bracket": "32"
                }
            }
        """.trimIndent()

        val root = JSONObject(jsonString)
        assertEquals("MileDiary", root.getString("appName"))
        assertEquals(2, root.getInt("schemaVersion"))

        val vehicles = root.getJSONArray("vehicles")
        assertEquals(1, vehicles.length())
        assertEquals("Prius Prime", vehicles.getJSONObject(0).getString("name"))

        val trips = root.getJSONArray("trips")
        assertEquals(1, trips.length())
        val trip0 = trips.getJSONObject(0)
        assertEquals("2026-03-15", trip0.getString("date"))
        assertEquals(22.4, trip0.getDouble("miles"), 0.001)
        assertTrue(trip0.getBoolean("roundTrip"))

        val boundaries = root.getJSONArray("boundaries")
        assertEquals(1, boundaries.length())
        assertEquals(45000.0, boundaries.getJSONObject(0).getDouble("jan1Odo"), 0.001)

        val settings = root.getJSONObject("settings")
        assertEquals("Jane Taxpayer", settings.getString("user_name"))
    }

    @Test
    fun testCorruptBackupInputStreamRejection() {
        // Not a JSON object
        val malformedStream = ByteArrayInputStream("This is plain text not JSON".toByteArray())
        
        // Simulating parsing corrupted stream
        val isJson = runCatching {
            val text = malformedStream.bufferedReader().readText()
            JSONObject(text)
        }.isSuccess

        assertFalse("Malformed non-JSON stream must not parse", isJson)
    }

    @Test
    fun testLegacyStartOfYearOdoCompatibility() {
        val legacyJson = """
            {
                "appName": "MileDiary",
                "schemaVersion": 1,
                "boundaries": [
                    {
                        "id": 1,
                        "vehicleId": 10,
                        "year": 2025,
                        "startOfYearOdo": 32000.0,
                        "endOfYearOdo": 44000.0
                    }
                ]
            }
        """.trimIndent()

        val root = JSONObject(legacyJson)
        val boundariesArray = root.getJSONArray("boundaries")
        val bObj = boundariesArray.getJSONObject(0)

        val startOdo = when {
            bObj.has("jan1Odo") -> bObj.getDouble("jan1Odo")
            bObj.has("startOfYearOdo") -> bObj.getDouble("startOfYearOdo")
            else -> null
        }
        val endOdo = when {
            bObj.has("dec31Odo") -> bObj.getDouble("dec31Odo")
            bObj.has("endOfYearOdo") -> bObj.getDouble("endOfYearOdo")
            else -> null
        }

        assertNotNull(startOdo)
        assertEquals(32000.0, startOdo!!, 0.001)
        assertNotNull(endOdo)
        assertEquals(44000.0, endOdo!!, 0.001)
    }
}
