package com.example

import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.domain.engine.MathEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MathEngineTest {

    private val sampleRates = listOf(
        RatePeriod(
            id = 1,
            year = 2025,
            category = TripCategory.BUSINESS,
            startDate = "2025-01-01",
            endDate = "2025-12-31",
            rateCents = 70.0,
            label = "IRS 2025 Business"
        ),
        RatePeriod(
            id = 2,
            year = 2026,
            category = TripCategory.BUSINESS,
            startDate = "2026-01-01",
            endDate = "2026-06-30",
            rateCents = 72.5,
            label = "IRS 2026 H1 Business"
        ),
        RatePeriod(
            id = 3,
            year = 2026,
            category = TripCategory.BUSINESS,
            startDate = "2026-07-01",
            endDate = "2026-12-31",
            rateCents = 76.0,
            label = "IRS 2026 H2 Business"
        ),
        RatePeriod(
            id = 4,
            year = 2026,
            category = TripCategory.CHARITY,
            startDate = "2026-01-01",
            endDate = "2026-12-31",
            rateCents = 14.0,
            label = "IRS 2026 Charity"
        ),
        RatePeriod(
            id = 5,
            year = 2026,
            category = TripCategory.MEDICAL,
            startDate = "2026-01-01",
            endDate = "2026-06-30",
            rateCents = 20.5,
            label = "IRS 2026 H1 Medical"
        ),
        RatePeriod(
            id = 6,
            year = 2026,
            category = TripCategory.MEDICAL,
            startDate = "2026-07-01",
            endDate = "2026-12-31",
            rateCents = 23.5,
            label = "IRS 2026 H2 Medical"
        )
    )

    @Test
    fun testRateResolutionByDate() {
        val rate2025 = MathEngine.getRateCentsForDate("2025-06-15", TripCategory.BUSINESS, false, sampleRates)
        assertEquals(70.0, rate2025, 0.001)

        // 2026 H1 vs H2 mid-year rate transition
        val rate2026H1 = MathEngine.getRateCentsForDate("2026-03-20", TripCategory.BUSINESS, false, sampleRates)
        assertEquals(72.5, rate2026H1, 0.001)

        val rate2026H2 = MathEngine.getRateCentsForDate("2026-08-15", TripCategory.BUSINESS, false, sampleRates)
        assertEquals(76.0, rate2026H2, 0.001)

        val charityRate = MathEngine.getRateCentsForDate("2026-05-10", TripCategory.CHARITY, false, sampleRates)
        assertEquals(14.0, charityRate, 0.001)

        // Commute is strictly non-deductible (0.0 cents)
        val commuteRate = MathEngine.getRateCentsForDate("2026-05-10", TripCategory.BUSINESS, true, sampleRates)
        assertEquals(0.0, commuteRate, 0.001)

        // Personal is strictly 0.0 cents
        val personalRate = MathEngine.getRateCentsForDate("2026-05-10", TripCategory.PERSONAL, false, sampleRates)
        assertEquals(0.0, personalRate, 0.001)
    }

    @Test
    fun testStatutoryFallbackRates() {
        // Test fallback when rate list is empty
        val emptyRates = emptyList<RatePeriod>()
        val fallback2026H1 = MathEngine.getRateCentsForDate("2026-02-01", TripCategory.BUSINESS, false, emptyRates)
        assertEquals(72.5, fallback2026H1, 0.001)

        val fallback2026H2 = MathEngine.getRateCentsForDate("2026-09-01", TripCategory.BUSINESS, false, emptyRates)
        assertEquals(76.0, fallback2026H2, 0.001)

        val fallbackCharity = MathEngine.getRateCentsForDate("2026-02-01", TripCategory.CHARITY, false, emptyRates)
        assertEquals(14.0, fallbackCharity, 0.001)
    }

    @Test
    fun testTripMilesCalculationAndRollover() {
        // Direct miles
        val direct = MathEngine.calculateTripMiles(24.5, null, null, false, false)
        assertEquals(24.5, direct, 0.001)

        // Round trip doubles
        val roundTrip = MathEngine.calculateTripMiles(24.5, null, null, false, true)
        assertEquals(49.0, roundTrip, 0.001)

        // Normal Odometer
        val normalOdo = MathEngine.calculateTripMiles(null, 15000.0, 15045.2, false, false)
        assertEquals(45.2, normalOdo, 0.001)

        // Odometer rollover (e.g., rolled from 999,950 to 50)
        val rolloverOdo = MathEngine.calculateTripMiles(null, 999950.0, 50.0, true, false)
        assertEquals(100.0, rolloverOdo, 0.001)
    }

    @Test
    fun testNegativeAndEdgeInputs() {
        // Negative direct miles should clamp to 0.0
        val negativeDirect = MathEngine.calculateTripMiles(-15.0, null, null, false, false)
        assertEquals(0.0, negativeDirect, 0.001)

        // Decreasing odometer without rollover selected should clamp to 0.0
        val invertedOdo = MathEngine.calculateTripMiles(null, 50000.0, 49950.0, false, false)
        assertEquals(0.0, invertedOdo, 0.001)

        // Zero values
        val zeroTrip = MathEngine.calculateTripMiles(0.0, null, null, false, false)
        assertEquals(0.0, zeroTrip, 0.001)
    }

    @Test
    fun testDeductionCalculation() {
        // 100 miles at 76¢ = $76.00
        val ded = MathEngine.calculateTripDeduction(100.0, 76.0)
        assertEquals(76.0, ded, 0.001)

        // 15.5 miles at 72.5¢ = $11.24
        val dedFraction = MathEngine.calculateTripDeduction(15.5, 72.5)
        assertEquals(11.24, dedFraction, 0.01)

        // 0 miles or 0 cents rate = 0.0 deduction
        val zeroDed = MathEngine.calculateTripDeduction(0.0, 76.0)
        assertEquals(0.0, zeroDed, 0.001)
        val zeroRateDed = MathEngine.calculateTripDeduction(100.0, 0.0)
        assertEquals(0.0, zeroRateDed, 0.001)
    }

    @Test
    fun testAggregatedStats() {
        val trips = listOf(
            Trip(
                id = 1,
                vehicleId = 1,
                date = "2026-08-10",
                fromLoc = "Office",
                toLoc = "Client A",
                purpose = "Consulting",
                category = TripCategory.BUSINESS,
                miles = 100.0
            ),
            Trip(
                id = 2,
                vehicleId = 1,
                date = "2026-08-11",
                fromLoc = "Home",
                toLoc = "Food Bank",
                purpose = "Charity work",
                category = TripCategory.CHARITY,
                miles = 50.0
            ),
            Trip(
                id = 3,
                vehicleId = 1,
                date = "2026-08-12",
                fromLoc = "Home",
                toLoc = "Clinic",
                purpose = "Therapy",
                category = TripCategory.MEDICAL,
                miles = 20.0
            ),
            Trip(
                id = 4,
                vehicleId = 1,
                date = "2026-08-13",
                fromLoc = "Home",
                toLoc = "Grocery Store",
                purpose = "Personal shopping",
                category = TripCategory.PERSONAL,
                miles = 30.0
            ),
            Trip(
                id = 5,
                vehicleId = 1,
                date = "2026-08-14",
                fromLoc = "Home",
                toLoc = "Regular Office",
                purpose = "Daily Commute",
                category = TripCategory.BUSINESS,
                isCommute = true,
                miles = 25.0
            )
        )

        // Total miles: 100 + 50 + 20 + 30 + 25 = 225.0
        // Deductions:
        // Business (100 @ 76c) = $76.00
        // Charity (50 @ 14c) = $7.00
        // Medical (20 @ 23.5c) = $4.70
        // Commute = 0.00
        // Personal = 0.00
        // Total deduction = $87.70
        val stats = MathEngine.calculateStats(trips, sampleRates, taxBracketPercent = 25.0)
        assertEquals(225.0, stats.totalMiles, 0.001)
        assertEquals(100.0, stats.businessMiles, 0.001)
        assertEquals(50.0, stats.charityMiles, 0.001)
        assertEquals(20.0, stats.medicalMiles, 0.001)
        assertEquals(30.0, stats.personalMiles, 0.001)
        assertEquals(25.0, stats.commuteMiles, 0.001)

        assertEquals(87.70, stats.totalDeduction, 0.01)
        // 25% tax bracket of 87.70 = 21.93
        assertEquals(21.93, stats.estimatedTaxSavings, 0.01)
    }

    @Test
    fun testAnnualBoundarySpanInStats() {
        val trips = listOf(
            Trip(
                id = 1,
                vehicleId = 1,
                date = "2026-05-01",
                fromLoc = "HQ",
                toLoc = "Client",
                purpose = "Sales",
                category = TripCategory.BUSINESS,
                miles = 5000.0
            )
        )

        // Vehicle odometer rolled 10,000 miles total in the year according to Jan 1 & Dec 31
        val stats = MathEngine.calculateStats(
            trips = trips,
            ratePeriods = sampleRates,
            odoAnnualSpan = 10000.0
        )

        // Business use should be 5,000 / 10,000 = 50.0%
        assertEquals(50.0, stats.businessPercentage, 0.001)
    }

    @Test
    fun testParkingTollsDeductionPub463() {
        // 100 business miles @ 70c = $70.00 + $15.50 bridge toll/parking = $85.50
        val deductWithToll = MathEngine.calculateTripDeduction(100.0, 70.0, 15.50)
        assertEquals(85.50, deductWithToll, 0.001)

        // Trip with zero miles but $8.00 parking receipt
        val deductZeroMiles = MathEngine.calculateTripDeduction(0.0, 70.0, 8.00)
        assertEquals(8.00, deductZeroMiles, 0.001)

        val trips = listOf(
            Trip(
                id = 1,
                vehicleId = 1,
                date = "2026-08-10",
                fromLoc = "Office",
                toLoc = "Court",
                purpose = "Filing",
                category = TripCategory.BUSINESS,
                miles = 20.0,
                parkingTolls = 12.50
            ),
            Trip(
                id = 2,
                vehicleId = 1,
                date = "2026-08-11",
                fromLoc = "Site A",
                toLoc = "Site B",
                purpose = "Inspection",
                category = TripCategory.BUSINESS,
                miles = 30.0,
                parkingTolls = 5.00
            )
        )
        // 20 mi @ 76c = $15.20 + 12.50 = 27.70
        // 30 mi @ 76c = $22.80 + 5.00 = 27.80
        // Total = 55.50, totalParkingTolls = 17.50
        val stats = MathEngine.calculateStats(trips, sampleRates)
        assertEquals(17.50, stats.totalParkingTolls, 0.001)
        assertEquals(55.50, stats.totalDeduction, 0.01)
    }
}
