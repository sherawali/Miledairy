package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OdoBoundary
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle

@Composable
fun VehiclesDialog(
    vehicles: List<Vehicle>,
    currentYear: Int,
    odoBoundaries: List<OdoBoundary> = emptyList(),
    trips: List<com.example.data.model.Trip> = emptyList(),
    isPro: Boolean = false,
    onOpenPaywall: () -> Unit = {},
    onSaveVehicle: (Vehicle) -> Unit,
    onSetPrimary: (Long) -> Unit,
    onDeleteVehicle: (Vehicle, Long?) -> Unit,
    onSaveOdoBoundary: (OdoBoundary) -> Unit,
    onDismiss: () -> Unit
) {
    var showAddVehicleForm by rememberSaveable { mutableStateOf(false) }
    var vehicleName by rememberSaveable { mutableStateOf("") }
    var vehicleMake by rememberSaveable { mutableStateOf("") }
    var vehicleModel by rememberSaveable { mutableStateOf("") }
    var vehicleYear by rememberSaveable { mutableStateOf("") }

    var vehicleToDelete by remember { mutableStateOf<Vehicle?>(null) }
    var odoVehicleTarget by remember { mutableStateOf<Vehicle?>(null) }
    var targetOdoYear by rememberSaveable { mutableIntStateOf(currentYear) }
    var jan1OdoInput by rememberSaveable { mutableStateOf("") }
    var dec31OdoInput by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Your Vehicles", fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (showAddVehicleForm) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Add Vehicle", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = vehicleName,
                                onValueChange = { vehicleName = it },
                                label = { Text("Nickname (e.g. Work Van)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = vehicleMake,
                                    onValueChange = { vehicleMake = it },
                                    label = { Text("Make") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = vehicleModel,
                                    onValueChange = { vehicleModel = it },
                                    label = { Text("Model") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { showAddVehicleForm = false }) {
                                    Text("Cancel")
                                }
                                Button(
                                    onClick = {
                                        if (vehicleName.isNotBlank()) {
                                            onSaveVehicle(
                                                Vehicle(
                                                    name = vehicleName.trim(),
                                                    make = vehicleMake.trim(),
                                                    model = vehicleModel.trim(),
                                                    year = vehicleYear.trim(),
                                                    isPrimary = vehicles.isEmpty()
                                                )
                                            )
                                            vehicleName = ""
                                            vehicleMake = ""
                                            vehicleModel = ""
                                            showAddVehicleForm = false
                                        }
                                    }
                                ) {
                                    Text("Add")
                                }
                            }
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(vehicles, key = { it.id }) { car ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(end = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DirectionsCar,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = car.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (car.make.isNotBlank() || car.model.isNotBlank()) {
                                                Text(
                                                    text = "${car.make} ${car.model}",
                                                    fontSize = 12.sp,
                                                    color = Color.Gray,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (car.isPrimary) {
                                            Text(
                                                "Primary",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier
                                                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        } else {
                                            TextButton(onClick = { onSetPrimary(car.id) }) {
                                                Text("Make Primary", fontSize = 11.sp)
                                            }
                                        }

                                        if (vehicles.size > 1) {
                                            IconButton(onClick = { vehicleToDelete = car }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                val boundary = odoBoundaries.find { it.vehicleId == car.id && it.year == currentYear }
                                if (boundary != null && (boundary.jan1Odo != null || boundary.dec31Odo != null)) {
                                    val totalAnnualMiles = if (boundary.dec31Odo != null && boundary.jan1Odo != null && boundary.dec31Odo > boundary.jan1Odo) {
                                        boundary.dec31Odo - boundary.jan1Odo
                                    } else null

                                    val bizMiles = trips.filter {
                                        it.vehicleId == car.id &&
                                                it.date.startsWith("$currentYear-") &&
                                                it.category == TripCategory.BUSINESS &&
                                                !it.isCommute
                                    }.sumOf { it.miles }

                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 8.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "$currentYear IRS Odometer Ledger:",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = "Jan 1: ${boundary.jan1Odo?.let { String.format("%.1f", it) } ?: "—"}  •  Dec 31: ${boundary.dec31Odo?.let { String.format("%.1f", it) } ?: "—"}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            if (totalAnnualMiles != null && totalAnnualMiles > 0) {
                                                val bizPercent = (bizMiles / totalAnnualMiles) * 100.0
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "Schedule C Part IV: ${String.format("%.1f", bizPercent)}% Business (${String.format("%.1f", bizMiles)} of ${String.format("%.1f", totalAnnualMiles)} mi)",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.secondary
                                                )
                                            }
                                        }
                                    }
                                }

                                // Button to enter Jan 1 / Dec 31 Odo
                                OutlinedButton(
                                    onClick = {
                                        targetOdoYear = currentYear
                                        val b = odoBoundaries.find { it.vehicleId == car.id && it.year == currentYear }
                                        jan1OdoInput = b?.jan1Odo?.toString() ?: ""
                                        dec31OdoInput = b?.dec31Odo?.toString() ?: ""
                                        odoVehicleTarget = car
                                    },
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Set $currentYear Jan 1 & Dec 31 Odometer", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!showAddVehicleForm) {
                Button(onClick = {
                    if (!isPro && vehicles.isNotEmpty()) {
                        onOpenPaywall()
                    } else {
                        showAddVehicleForm = true
                    }
                }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Another Car")
                    if (!isPro && vehicles.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    )

    // Odometer Boundaries Dialog
    if (odoVehicleTarget != null) {
        AlertDialog(
            onDismissRequest = { odoVehicleTarget = null },
            title = {
                Column {
                    Text("${odoVehicleTarget!!.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("IRS Annual Odometer Reconciliation", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
            },
            text = {
                Column {
                    Text(
                        "IRS Form 1040 Schedule C requires reporting starting (Jan 1) and ending (Dec 31) odometer numbers to establish annual business use percentage.",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Tax Year:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    val currentCalYear = remember { java.time.LocalDate.now().year }
                    val availableYears = remember(currentCalYear) {
                        listOf(currentCalYear - 2, currentCalYear - 1, currentCalYear, currentCalYear + 1)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        availableYears.forEach { yr ->
                            FilterChip(
                                selected = targetOdoYear == yr,
                                onClick = {
                                    targetOdoYear = yr
                                    val b = odoBoundaries.find { it.vehicleId == odoVehicleTarget!!.id && it.year == yr }
                                    jan1OdoInput = b?.jan1Odo?.toString() ?: ""
                                    dec31OdoInput = b?.dec31Odo?.toString() ?: ""
                                },
                                label = {
                                    val suffix = when {
                                        yr == currentCalYear -> " • Now"
                                        yr > currentCalYear -> " (Next)"
                                        else -> ""
                                    }
                                    Text("$yr$suffix", fontSize = 11.sp, fontWeight = if (targetOdoYear == yr) FontWeight.Bold else FontWeight.Normal)
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = jan1OdoInput,
                        onValueChange = { jan1OdoInput = it },
                        label = { Text("Jan 1 Odometer (Start of $targetOdoYear)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = dec31OdoInput,
                        onValueChange = { dec31OdoInput = it },
                        label = { Text("Dec 31 Odometer (End of $targetOdoYear)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val jOdo = jan1OdoInput.toDoubleOrNull()
                        val dOdo = dec31OdoInput.toDoubleOrNull()
                        onSaveOdoBoundary(
                            OdoBoundary(
                                vehicleId = odoVehicleTarget!!.id,
                                year = targetOdoYear,
                                jan1Odo = jOdo,
                                dec31Odo = dOdo
                            )
                        )
                        odoVehicleTarget = null
                        jan1OdoInput = ""
                        dec31OdoInput = ""
                    }
                ) {
                    Text("Save Readings")
                }
            },
            dismissButton = {
                TextButton(onClick = { odoVehicleTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Vehicle Delete Guard Dialog
    if (vehicleToDelete != null) {
        val otherVehicles = vehicles.filter { it.id != vehicleToDelete!!.id }
        AlertDialog(
            onDismissRequest = { vehicleToDelete = null },
            title = { Text("Delete ${vehicleToDelete!!.name}?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Any logged trips assigned to this vehicle will be safely transferred to ${otherVehicles.firstOrNull()?.name ?: "another car"}.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reassignId = otherVehicles.firstOrNull()?.id
                        onDeleteVehicle(vehicleToDelete!!, reassignId)
                        vehicleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Confirm Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { vehicleToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
