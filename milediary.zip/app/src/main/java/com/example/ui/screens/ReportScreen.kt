package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.Vehicle
import com.example.domain.engine.MathEngine
import com.example.ui.theme.DarkGreen
import com.example.ui.theme.TertiaryAmber
import com.example.util.FormatUtils
import com.example.util.PrintHelper
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    trips: List<Trip>,
    vehicles: List<Vehicle>,
    ratePeriods: List<RatePeriod>,
    selectedYear: Int,
    taxpayerName: String,
    businessName: String = "",
    taxId: String = "",
    signerName: String = "",
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    isPro: Boolean,
    onSelectYear: (Int) -> Unit,
    onUpdateSignerName: (String) -> Unit = {},
    onGeneratePdf: suspend (Int, Long?) -> File?,
    onGenerateCsv: suspend (Int, Long?) -> File?,
    onOpenPaywall: () -> Unit,
    onOpenImport: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedVehicleId by rememberSaveable { mutableStateOf<Long?>(null) }
    var isExporting by rememberSaveable { mutableStateOf(false) }
    var isPrinting by rememberSaveable { mutableStateOf(false) }
    var showSignatureDialog by rememberSaveable { mutableStateOf(false) }
    var signatureInput by rememberSaveable { mutableStateOf(signerName.ifBlank { taxpayerName }) }

    val yearTrips = remember(trips, selectedYear, selectedVehicleId) {
        trips.filter {
            it.date.startsWith("$selectedYear-") &&
                    (selectedVehicleId == null || it.vehicleId == selectedVehicleId)
        }
    }

    val stats = remember(yearTrips, ratePeriods) {
        MathEngine.calculateStats(yearTrips, ratePeriods)
    }

    val currentCalYear = remember { LocalDate.now().year }
    val availableYears = remember(currentCalYear) {
        listOf(currentCalYear - 2, currentCalYear - 1, currentCalYear, currentCalYear + 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tax Reports", fontWeight = FontWeight.Bold, maxLines = 1) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Year Selector Row
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                items(availableYears.size) { idx ->
                    val yr = availableYears[idx]
                    FilterChip(
                        selected = selectedYear == yr,
                        onClick = { onSelectYear(yr) },
                        label = {
                            val suffix = when {
                                yr == currentCalYear -> " • Current"
                                yr > currentCalYear -> " • Upcoming"
                                else -> ""
                            }
                            Text(
                                text = "$yr$suffix",
                                fontWeight = if (selectedYear == yr) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    )
                }
            }

            // Vehicle filter & import button row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                var showCarMenu by remember { mutableStateOf(false) }
                val carLabel = vehicles.find { it.id == selectedVehicleId }?.name ?: "All Vehicles"

                Box(modifier = Modifier.weight(1f, fill = false)) {
                    OutlinedButton(
                        onClick = { showCarMenu = true },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Car: $carLabel ▾",
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    DropdownMenu(expanded = showCarMenu, onDismissRequest = { showCarMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("All Vehicles") },
                            onClick = {
                                selectedVehicleId = null
                                showCarMenu = false
                            }
                        )
                        vehicles.forEach { v ->
                            DropdownMenuItem(
                                text = { Text(v.name) },
                                onClick = {
                                    selectedVehicleId = v.id
                                    showCarMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onOpenImport,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import CSV", fontSize = 13.sp, maxLines = 1)
                }
            }

            // Export Actions Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Audit-Ready Tax Export & Print",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1
                    )
                    Text(
                        text = "Generates IRS Pub 463 & IRC §274 compliant logs with dates, routes, business purposes, and statutory rates.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                    )

                    // Action buttons: Two primary buttons in Row 1, CSV in Row 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // PDF Export Button
                        Button(
                            onClick = {
                                if (!isPro) {
                                    onOpenPaywall()
                                } else {
                                    coroutineScope.launch {
                                        isExporting = true
                                        val file = onGeneratePdf(selectedYear, selectedVehicleId)
                                        isExporting = false
                                        if (file != null) shareFile(context, file, "application/pdf")
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("export_pdf_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            if (isExporting) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export PDF", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                            }
                        }

                        // Direct Print Button
                        OutlinedButton(
                            onClick = {
                                if (!isPro) {
                                    onOpenPaywall()
                                } else {
                                    coroutineScope.launch {
                                        isPrinting = true
                                        val file = onGeneratePdf(selectedYear, selectedVehicleId)
                                        isPrinting = false
                                        if (file != null) {
                                            PrintHelper.printPdf(context, file, "MileDiary_Tax_Report_$selectedYear")
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("print_pdf_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isPrinting) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp))
                            } else {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print PDF", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // CSV Export Button (Full Width, clear and distinct)
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val file = onGenerateCsv(selectedYear, selectedVehicleId)
                                if (file != null) shareFile(context, file, "text/csv")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("export_csv_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TertiaryAmber)
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export CSV Spreadsheet (Excel / Tax Software)", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                    }

                    if (!isPro) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEF3C7))
                                .padding(10.dp)
                                .clickable(onClick = onOpenPaywall),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = TertiaryAmber, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "IRS Audit-Certified PDF with Digital Signature unlocked with Pro.",
                                fontSize = 12.sp,
                                color = Color(0xFF78350F),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Digital Signature & Auditor Verification Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showSignatureDialog = true }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DarkGreen, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Digital Signature & Audit Certification",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val currentSigner = signerName.ifBlank { taxpayerName.ifBlank { "Unsigned (Tap to set)" } }
                            Text(
                                text = "Certified by: $currentSigner",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Icon(Icons.Default.Create, contentDescription = "Edit Signature", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
            }

            // Live Ledger Preview (Simulating the printed page)
            Text("Report Preview (${yearTrips.size} trips)", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Report Header
                    Text(
                        text = "AUDIT-READY MILEAGE & EXPENSE RECORD",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Tax Year: $selectedYear   |   Taxpayer: ${taxpayerName.ifBlank { "Taxpayer / Driver" }}${if (businessName.isNotBlank()) " | Business: $businessName" else ""}",
                        fontSize = 11.5.sp,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    val tollInfo = if (stats.totalParkingTolls > 0.0) "   |   Tolls: ${FormatUtils.formatMoney(stats.totalParkingTolls, currencySymbol)}" else ""
                    Text(
                        text = "Total Logged: ${FormatUtils.formatDistance(stats.totalMiles, distanceUnit)}   |   Business: ${FormatUtils.formatDistance(stats.businessMiles, distanceUnit)}$tollInfo   |   Deduction: ${FormatUtils.formatMoney(stats.totalDeduction, currencySymbol)}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Table preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("Date", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            Text("Route", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(2.5f))
                            Text("Purpose", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(2f))
                            Text("Distance", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            Text("Amount", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(1.2f))
                        }
                    }

                    if (yearTrips.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No drives found for $selectedYear.", color = Color.Gray, fontSize = 13.sp)
                        }
                    } else {
                        yearTrips.take(15).forEachIndexed { idx, trip ->
                            val r = MathEngine.getRateCentsForDate(trip.date, trip.category, trip.isCommute, ratePeriods)
                            val d = MathEngine.calculateTripDeduction(trip.miles, r, trip.parkingTolls)

                            val bg = if (idx % 2 == 1) Color(0xFFF8FAF8) else Color.White
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(bg)
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(trip.date.substring(5), fontSize = 10.sp, color = Color.Black, modifier = Modifier.weight(1f))
                                Text("${trip.fromLoc} → ${trip.toLoc}", fontSize = 10.sp, color = Color.Black, maxLines = 1, modifier = Modifier.weight(2.5f))
                                Text(trip.purpose, fontSize = 10.sp, color = Color.DarkGray, maxLines = 1, modifier = Modifier.weight(2f))
                                Text(FormatUtils.formatDistance(trip.miles, distanceUnit), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.weight(1f))
                                Text(FormatUtils.formatMoney(d, currencySymbol), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.weight(1.2f))
                            }
                        }

                        if (yearTrips.size > 15) {
                            Text(
                                text = "... + ${yearTrips.size - 15} more trips included in final exported PDF & CSV",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Signature Edit Dialog
    if (showSignatureDialog) {
        AlertDialog(
            onDismissRequest = { showSignatureDialog = false },
            title = { Text("Taxpayer Signature", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Enter the full legal name of the taxpayer or authorized driver to print on the IRS compliance certification statement.",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = signatureInput,
                        onValueChange = { signatureInput = it },
                        label = { Text("Signer Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateSignerName(signatureInput)
                        showSignatureDialog = false
                    }
                ) {
                    Text("Save Signature")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignatureDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun shareFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "IRS Mileage Log - ${file.name}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Share Tax Mileage Log").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Share failed: ${e.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
    }
}
