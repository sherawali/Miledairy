package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.domain.engine.MathEngine
import com.example.domain.storage.ReceiptStorageManager
import com.example.ui.theme.TertiaryAmber
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTripSheet(
    initialTrip: Trip? = null,
    prefilledFrom: String? = null,
    prefilledTo: String? = null,
    prefilledMiles: Double? = null,
    prefilledCategory: TripCategory? = null,
    prefilledPurpose: String? = null,
    vehicles: List<Vehicle>,
    ratePeriods: List<RatePeriod>,
    recentLocations: List<String>,
    homeAddress: String,
    officeAddress: String,
    onGetLastOdo: suspend (Long) -> Double?,
    onCheckDuplicate: suspend (Long, String, String, String) -> Boolean,
    onSaveTrip: (Trip) -> Unit,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableIntStateOf(if (initialTrip?.isShift == true) 1 else 0) }

    // Form Fields (persisting across rotation)
    val defaultVehicleId = remember(vehicles, initialTrip) {
        initialTrip?.vehicleId ?: vehicles.find { it.isPrimary }?.id ?: vehicles.firstOrNull()?.id ?: 1L
    }
    var selectedVehicleId by rememberSaveable { mutableStateOf(defaultVehicleId) }
    val selectedVehicle = remember(vehicles, selectedVehicleId) {
        vehicles.find { it.id == selectedVehicleId }
            ?: vehicles.find { it.isPrimary }
            ?: vehicles.firstOrNull()
    }

    var dateStr by rememberSaveable { mutableStateOf(initialTrip?.date ?: LocalDate.now().toString()) }
    var fromLoc by rememberSaveable { mutableStateOf(initialTrip?.fromLoc ?: prefilledFrom ?: "") }
    var toLoc by rememberSaveable { mutableStateOf(initialTrip?.toLoc ?: prefilledTo ?: "") }
    var purpose by rememberSaveable { mutableStateOf(initialTrip?.purpose ?: prefilledPurpose ?: "Client visit") }
    var category by rememberSaveable { mutableStateOf(initialTrip?.category ?: prefilledCategory ?: TripCategory.BUSINESS) }
    var isCommute by rememberSaveable { mutableStateOf(initialTrip?.isCommute ?: false) }
    var platform by rememberSaveable { mutableStateOf(initialTrip?.platform ?: "") }
    var tag by rememberSaveable { mutableStateOf(initialTrip?.tag ?: "") }
    var note by rememberSaveable { mutableStateOf(initialTrip?.note ?: "") }

    // Input mode: 0 = Miles, 1 = Odometer
    var inputMode by rememberSaveable {
        mutableIntStateOf(if (initialTrip?.odoStart != null || initialTrip?.odoEnd != null) 1 else 0)
    }
    var directMilesStr by rememberSaveable {
        mutableStateOf(if (initialTrip != null) initialTrip.miles.toString() else prefilledMiles?.toString() ?: "")
    }
    var roundTrip by rememberSaveable { mutableStateOf(initialTrip?.roundTrip ?: false) }

    var odoStartStr by rememberSaveable { mutableStateOf(initialTrip?.odoStart?.toString() ?: "") }
    var odoEndStr by rememberSaveable { mutableStateOf(initialTrip?.odoEnd?.toString() ?: "") }
    var isRollover by rememberSaveable { mutableStateOf(false) }
    var parkingTollsStr by rememberSaveable {
        mutableStateOf(if (initialTrip?.parkingTolls != null && initialTrip.parkingTolls > 0.0) initialTrip.parkingTolls.toString() else "")
    }
    var receiptPath by rememberSaveable { mutableStateOf(initialTrip?.receiptPath) }
    var showReceiptPreviewDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val savedPath = ReceiptStorageManager.saveReceiptImage(context, uri)
                if (savedPath != null) {
                    receiptPath = savedPath
                }
            }
        }
    }

    // Validation & Warning state
    var errorMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var isDuplicateWarning by rememberSaveable { mutableStateOf(false) }
    var isHighMileageConfirmed by rememberSaveable { mutableStateOf(false) }
    var isSavingLocked by remember { mutableStateOf(false) }
    var lastKnownOdoEnd by remember { mutableStateOf<Double?>(null) }

    // Auto prefill start odo from last trip when switching to meter mode or changing vehicle
    LaunchedEffect(selectedVehicle, inputMode) {
        if (selectedVehicle != null) {
            val lastOdo = onGetLastOdo(selectedVehicle!!.id)
            lastKnownOdoEnd = lastOdo
            if (inputMode == 1 && odoStartStr.isBlank() && lastOdo != null) {
                odoStartStr = lastOdo.toString()
            }
        }
    }

    // Auto commute detection
    val homeNorm = homeAddress.trim().lowercase()
    val officeNorm = officeAddress.trim().lowercase()
    val isCommuteDetected = remember(fromLoc, toLoc, homeNorm, officeNorm) {
        if (homeNorm.isNotBlank() && officeNorm.isNotBlank()) {
            val f = fromLoc.trim().lowercase()
            val t = toLoc.trim().lowercase()
            (f.contains(homeNorm) && t.contains(officeNorm)) || (f.contains(officeNorm) && t.contains(homeNorm))
        } else false
    }

    // Computed Miles
    val computedMiles = remember(inputMode, directMilesStr, roundTrip, odoStartStr, odoEndStr, isRollover) {
        if (inputMode == 0) {
            val d = directMilesStr.toDoubleOrNull() ?: 0.0
            MathEngine.calculateTripMiles(d, null, null, isRollover, roundTrip)
        } else {
            val s = odoStartStr.toDoubleOrNull()
            val e = odoEndStr.toDoubleOrNull()
            MathEngine.calculateTripMiles(null, s, e, isRollover, false)
        }
    }

    // Live Deduction
    val currentRate = MathEngine.getRateCentsForDate(dateStr, category, isCommute, ratePeriods)
    val parkingTollsVal = parkingTollsStr.toDoubleOrNull() ?: 0.0
    val liveDeduction = MathEngine.calculateTripDeduction(computedMiles, currentRate, parkingTollsVal)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (initialTrip == null) "Log Drive" else "Edit Drive",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("dismiss_add_trip")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Close")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Mode Tabs: Trip vs Shift
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Trip Mode", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        inputMode = 1
                        if (purpose.isBlank() || purpose == "Client visit") purpose = "Delivery Shift"
                    },
                    text = { Text("◐ Shift Mode", fontWeight = FontWeight.Bold) }
                )
            }

            // Live Deduction Hero Banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$computedMiles miles",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "${currentRate}¢ / mi (${category.displayName})",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isCommute) "COMMUTE: $0.00" else "+$${String.format("%.2f", liveDeduction)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isCommute) Color.Gray else TertiaryAmber
                        )
                        Text(
                            text = "Tax Deduction",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Commute Suggestion Strip
            if (isCommuteDetected && !isCommute) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = TertiaryAmber)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Home ↔ Office commute detected. IRS disallows personal commute deduction.",
                            fontSize = 12.sp,
                            color = Color(0xFF78350F),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = { isCommute = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TertiaryAmber),
                            modifier = Modifier.padding(start = 6.dp)
                        ) {
                            Text("Set Commute", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Vehicle Selector & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Vehicle Dropdown
                var expandedVehicle by remember { mutableStateOf(false) }
                Box(modifier = Modifier.weight(1.2f)) {
                    ExposedDropdownMenuBox(
                        expanded = expandedVehicle,
                        onExpandedChange = { expandedVehicle = !expandedVehicle }
                    ) {
                        OutlinedTextField(
                            value = selectedVehicle?.name ?: "Select Car",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Vehicle") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedVehicle) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedVehicle,
                            onDismissRequest = { expandedVehicle = false }
                        ) {
                            vehicles.forEach { v ->
                                DropdownMenuItem(
                                    text = { Text(v.name) },
                                    onClick = {
                                        selectedVehicleId = v.id
                                        expandedVehicle = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Date input
                OutlinedTextField(
                    value = dateStr,
                    onValueChange = { dateStr = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Locations (Trip Mode)
            if (selectedTab == 0) {
                OutlinedTextField(
                    value = fromLoc,
                    onValueChange = { fromLoc = it },
                    label = { Text("From Location *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("from_loc_input")
                )

                // Quick recent from suggestions
                if (recentLocations.isNotEmpty() && fromLoc.isBlank()) {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        recentLocations.take(3).forEach { loc ->
                            FilterChip(
                                selected = false,
                                onClick = { fromLoc = loc },
                                label = { Text(loc, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = toLoc,
                    onValueChange = { toLoc = it },
                    label = { Text("To Location *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("to_loc_input")
                )

                if (recentLocations.isNotEmpty() && toLoc.isBlank()) {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        recentLocations.take(3).forEach { loc ->
                            FilterChip(
                                selected = false,
                                onClick = { toLoc = loc },
                                label = { Text(loc, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            } else {
                // Shift Mode preset fields
                OutlinedTextField(
                    value = fromLoc.ifBlank { "Shift Origin" },
                    onValueChange = { fromLoc = it },
                    label = { Text("Shift Base / Area") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Mileage Input Section (Miles vs Meter)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Entry Method:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                        Row {
                            FilterChip(
                                selected = inputMode == 0,
                                onClick = { inputMode = 0 },
                                label = { Text("Direct Miles") }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            FilterChip(
                                selected = inputMode == 1,
                                onClick = { inputMode = 1 },
                                label = { Text("Odometer Readings") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (inputMode == 0) {
                        // Direct Miles
                        OutlinedTextField(
                            value = directMilesStr,
                            onValueChange = { directMilesStr = it },
                            label = { Text("Miles Driven *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("direct_miles_input")
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { roundTrip = !roundTrip }
                        ) {
                            Checkbox(checked = roundTrip, onCheckedChange = { roundTrip = it })
                            Text("Round Trip (doubles miles)", fontSize = 13.sp)
                        }
                    } else {
                        // Odometer Mode
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = odoStartStr,
                                onValueChange = { odoStartStr = it },
                                label = { Text("Start Odo") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = odoEndStr,
                                onValueChange = { odoEndStr = it },
                                label = { Text("End Odo") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Odometer Gap & Continuity Notice
                        val sVal = odoStartStr.toDoubleOrNull()
                        if (sVal != null && lastKnownOdoEnd != null) {
                            if (sVal > lastKnownOdoEnd!! + 0.1) {
                                val gap = Math.round((sVal - lastKnownOdoEnd!!) * 10.0) / 10.0
                                Surface(
                                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Info,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                "Odometer Gap: ${gap} mi since last logged drive",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onTertiaryContainer
                                            )
                                            Text(
                                                "Recorded as unlogged personal/commute driving per IRS continuity rules.",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                                            )
                                        }
                                    }
                                }
                            } else if (sVal < lastKnownOdoEnd!! - 0.1) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "Start reading is less than previous end (${lastKnownOdoEnd} mi)",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(
                                            onClick = { odoStartStr = lastKnownOdoEnd.toString() },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                        ) {
                                            Text("Reset", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { isRollover = !isRollover }
                        ) {
                            Checkbox(checked = isRollover, onCheckedChange = { isRollover = it })
                            Text("Odometer Rolled Over (e.g. 999,999 -> 000,050)", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Purpose & Quick Chips
            OutlinedTextField(
                value = purpose,
                onValueChange = { purpose = it },
                label = { Text("Business Purpose / Client *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            val purposePresets = listOf("Client Meeting", "Delivery Dropoff", "Supply Purchase", "Job Site", "Notary Signing", "Inspection")
            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                purposePresets.forEach { preset ->
                    FilterChip(
                        selected = purpose == preset,
                        onClick = { purpose = preset },
                        label = { Text(preset, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Chips
            Text("Tax Category:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TripCategory.values().forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat.displayName, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }

            // Gig Platform Chips
            Spacer(modifier = Modifier.height(6.dp))
            Text("Gig Platform (Optional):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            val platforms = listOf("DoorDash", "Uber", "Lyft", "Instacart", "Amazon Flex", "Spark")
            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                platforms.forEach { plat ->
                    FilterChip(
                        selected = platform == plat,
                        onClick = { platform = if (platform == plat) "" else plat },
                        label = { Text(plat, fontSize = 11.sp) }
                    )
                }
            }

            // Tag & Note
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it },
                    label = { Text("Tag (Client/Property)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (optional)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            // Parking & Tolls (IRS Pub 463 Non-Mileage Expense Add-on)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = parkingTollsStr,
                onValueChange = { parkingTollsStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Parking & Tolls ($) — Optional") },
                placeholder = { Text("e.g. 8.50 (IRS Pub 463 deductible add-on)") },
                leadingIcon = { Text("$", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trip_parking_tolls_input")
            )

            // Receipt / Parking Slip Attachment (IRS Pub 463 Proof)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Receipt / Parking Slip (IRS Pub 463 Proof)",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Text(
                        "Documentary evidence (receipt, parking ticket, toll transponder record) is legally required by the IRS for expense deductions.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                    )

                    if (receiptPath.isNullOrBlank()) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("attach_receipt_button")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Attach Receipt Photo", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { showReceiptPreviewDialog = true }
                                    .weight(1f)
                            ) {
                                AsyncImage(
                                    model = File(receiptPath!!),
                                    contentDescription = "Receipt thumbnail",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "Receipt attached ✓",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        "Tap to view full receipt",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row {
                                TextButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("Replace", fontSize = 12.sp)
                                }
                                IconButton(
                                    onClick = { receiptPath = null }
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Remove receipt",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showReceiptPreviewDialog && !receiptPath.isNullOrBlank()) {
                Dialog(onDismissRequest = { showReceiptPreviewDialog = false }) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Attached Receipt Proof",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                IconButton(onClick = { showReceiptPreviewDialog = false }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close")
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            AsyncImage(
                                model = File(receiptPath!!),
                                contentDescription = "Full receipt preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 420.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }
                    }
                }
            }

            // Error & Duplicate Warnings
            AnimatedVisibility(visible = errorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(errorMessage ?: "", color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save Button
            Button(
                onClick = {
                    if (isSavingLocked) return@Button
                    val vehicleId = selectedVehicle?.id ?: 1L
                    val finalFrom = if (selectedTab == 1 && fromLoc.isBlank()) "Shift Area" else fromLoc.trim()
                    val finalTo = if (selectedTab == 1 && toLoc.isBlank()) "Various Locations" else toLoc.trim()

                    if (finalFrom.isBlank() || finalTo.isBlank()) {
                        errorMessage = "Please enter From and To locations."
                        return@Button
                    }
                    if (purpose.trim().length < 3) {
                        errorMessage = "Please enter a specific business purpose (IRS Pub 463 requirement)."
                        return@Button
                    }
                    if (computedMiles <= 0.0) {
                        errorMessage = "Trip miles must be greater than zero."
                        return@Button
                    }
                    if (computedMiles > 1200.0 && !isHighMileageConfirmed) {
                        isHighMileageConfirmed = true
                        errorMessage = "Notice: Drives over 1,200 miles in one day are flagged by IRS auditors. Tap Save again if this is accurate."
                        return@Button
                    }

                    // Check duplicate in background
                    coroutineScope.launch {
                        isSavingLocked = true
                        val isDup = onCheckDuplicate(vehicleId, dateStr, finalFrom, finalTo)
                        if (isDup && !isDuplicateWarning) {
                            isDuplicateWarning = true
                            errorMessage = "Notice: A trip with the same route was already logged today. Tap Save again to confirm."
                            isSavingLocked = false
                            return@launch
                        }

                        val sOdo = odoStartStr.toDoubleOrNull()
                        val eOdo = odoEndStr.toDoubleOrNull()

                        val newTrip = Trip(
                            id = initialTrip?.id ?: 0L,
                            vehicleId = vehicleId,
                            date = dateStr,
                            fromLoc = finalFrom,
                            toLoc = finalTo,
                            purpose = purpose.trim(),
                            category = category,
                            isCommute = isCommute,
                            isShift = selectedTab == 1,
                            platform = platform.ifBlank { null },
                            tag = tag.ifBlank { null },
                            miles = computedMiles,
                            odoStart = sOdo,
                            odoEnd = eOdo,
                            roundTrip = roundTrip && inputMode == 0,
                            parkingTolls = if (parkingTollsVal > 0.0) parkingTollsVal else null,
                            receiptPath = receiptPath,
                            note = note.trim(),
                            createdAt = initialTrip?.createdAt ?: System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis(),
                            edited = initialTrip != null
                        )

                        onSaveTrip(newTrip)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_trip_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    if (initialTrip == null) "Save Drive Record" else "Update Drive Record",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
