package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Vehicle
import com.example.domain.report.CsvReportManager
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream

@Composable
fun CsvImportDialog(
    vehicles: List<Vehicle>,
    onImportCsvStream: suspend (java.io.InputStream, Long) -> CsvReportManager.ImportResult,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedVehicle by remember { mutableStateOf(vehicles.firstOrNull()) }
    var csvText by remember { mutableStateOf("") }
    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var importResult by remember { mutableStateOf<CsvReportManager.ImportResult?>(null) }

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val text = stream.bufferedReader(Charsets.UTF_8).readText()
                    csvText = text
                    selectedFileName = uri.lastPathSegment ?: "selected.csv"
                }
            }
        }
    }

    val sampleCsv = """
Date,From,To,Purpose,Miles,Category
2026-01-15,100 Main St,450 Broad Ave,Client Meeting,14.5,Business
2026-01-18,Home,Supply Depot,Materials pickup,8.2,Business
2026-01-20,Warehouse,Food Bank,Food delivery,12.0,Charity
    """.trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Import CSV Logbook",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Seamlessly import drives from MileIQ, Everlance, TripLog, or Excel spreadsheets. Auto-detects columns: Date, From, To, Miles, Purpose, Category.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Vehicle Selector
                var showCarMenu by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = { showCarMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Target Vehicle: ${selectedVehicle?.name ?: "Select Vehicle"} ▾",
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                DropdownMenu(expanded = showCarMenu, onDismissRequest = { showCarMenu = false }) {
                    vehicles.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(v.name) },
                            onClick = {
                                selectedVehicle = v
                                showCarMenu = false
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // File Picker Action Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                        .clickable { filePickerLauncher.launch("*/*") }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.FolderOpen,
                        contentDescription = "Browse file",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedFileName ?: "Select CSV File from Device",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Supports .csv files from Downloads, Drive, or Files",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = csvText,
                    onValueChange = {
                        csvText = it
                        selectedFileName = null
                    },
                    label = { Text("Or Paste CSV Text") },
                    placeholder = { Text("Date,From,To,Purpose,Miles,Category...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = {
                        csvText = sampleCsv
                        selectedFileName = "sample_drives.csv"
                    }) {
                        Text("Paste Sample Data", fontSize = 11.sp)
                    }
                }

                if (importResult != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "✅ Imported ${importResult!!.importedTrips.size} drives! (${importResult!!.duplicateCount} duplicates skipped)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val vId = selectedVehicle?.id ?: 1L
                    if (csvText.isNotBlank()) {
                        coroutineScope.launch {
                            isImporting = true
                            val stream = ByteArrayInputStream(csvText.toByteArray(Charsets.UTF_8))
                            val result = onImportCsvStream(stream, vId)
                            importResult = result
                            isImporting = false
                        }
                    }
                },
                enabled = csvText.isNotBlank() && !isImporting
            ) {
                if (isImporting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                } else {
                    Icon(Icons.Default.FileUpload, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import Drives")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (importResult != null) "Done" else "Cancel")
            }
        }
    )
}

