package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RatePeriod
import com.example.data.model.TripCategory
import com.example.ui.theme.BadgeBusiness
import com.example.ui.theme.BadgeCharity
import com.example.ui.theme.BadgeMedical
import com.example.ui.theme.BadgePersonal
import com.example.ui.theme.PrimaryForestGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RatePeriodsDialog(
    ratePeriods: List<RatePeriod>,
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    onUpdateRatePeriod: (RatePeriod) -> Unit,
    onAddRatePeriod: (RatePeriod) -> Unit,
    onDeleteRatePeriod: (Long) -> Unit,
    onResetRatesToDefault: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedYearFilter by rememberSaveable { mutableStateOf("All") }
    var editingPeriod by remember { mutableStateOf<RatePeriod?>(null) }
    var showAddForm by rememberSaveable { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var periodToDelete by remember { mutableStateOf<RatePeriod?>(null) }

    // Form fields for Add / Edit
    var formYear by rememberSaveable { mutableStateOf("2026") }
    var formCategory by rememberSaveable { mutableStateOf(TripCategory.BUSINESS.name) }
    var formRateCents by rememberSaveable { mutableStateOf("70.5") }
    var formStartDate by rememberSaveable { mutableStateOf("2026-01-01") }
    var formEndDate by rememberSaveable { mutableStateOf("2026-12-31") }
    var formLabel by rememberSaveable { mutableStateOf("IRS Standard Business Rate") }
    var formError by rememberSaveable { mutableStateOf<String?>(null) }

    val distinctYears = remember(ratePeriods) {
        listOf("All") + ratePeriods.map { it.year.toString() }.distinct().sortedDescending()
    }

    val filteredPeriods = remember(ratePeriods, selectedYearFilter) {
        if (selectedYearFilter == "All") {
            ratePeriods.sortedWith(compareByDescending<RatePeriod> { it.year }.thenBy { it.startDate })
        } else {
            val y = selectedYearFilter.toIntOrNull() ?: 2026
            ratePeriods.filter { it.year == y }.sortedBy { it.startDate }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.PriceChange,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Mileage & Tax Rates",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                // Info Banner
                Text(
                    text = "Deductions are calculated by trip date using historical rate periods. Edit or add custom rates below; past years stay fully audit-compliant.",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Year Filter Chips & Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Filter Chips (Scrollable Row)
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        distinctYears.take(4).forEach { yr ->
                            FilterChip(
                                selected = selectedYearFilter == yr,
                                onClick = { selectedYearFilter = yr },
                                label = { Text(yr, fontSize = 11.5.sp) },
                                modifier = Modifier.height(30.dp)
                            )
                        }
                    }

                    // Reset to IRS button
                    TextButton(
                        onClick = { showResetConfirmDialog = true },
                        modifier = Modifier.testTag("reset_rates_defaults_btn")
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset IRS", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Add Rate / Edit Rate Form
                AnimatedVisibility(visible = showAddForm || editingPeriod != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (editingPeriod != null) "Edit Rate Period" else "Add Custom Rate Period",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Label
                            OutlinedTextField(
                                value = formLabel,
                                onValueChange = { formLabel = it },
                                label = { Text("Label (e.g. IRS Standard / Company Reimbursement)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                // Rate (cents or unit value)
                                OutlinedTextField(
                                    value = formRateCents,
                                    onValueChange = { formRateCents = it },
                                    label = { Text("Rate ($distanceUnit)") },
                                    placeholder = { Text("70.5") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )

                                // Year
                                OutlinedTextField(
                                    value = formYear,
                                    onValueChange = { formYear = it },
                                    label = { Text("Year") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(0.7f)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))

                            // Date Range
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = formStartDate,
                                    onValueChange = { formStartDate = it },
                                    label = { Text("Start Date") },
                                    placeholder = { Text("YYYY-MM-DD") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = formEndDate,
                                    onValueChange = { formEndDate = it },
                                    label = { Text("End Date") },
                                    placeholder = { Text("YYYY-MM-DD") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))

                            // Category Selector Chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf(
                                    TripCategory.BUSINESS,
                                    TripCategory.CHARITY,
                                    TripCategory.MEDICAL
                                ).forEach { cat ->
                                    FilterChip(
                                        selected = formCategory == cat.name,
                                        onClick = { formCategory = cat.name },
                                        label = { Text(cat.name, fontSize = 10.sp) },
                                        modifier = Modifier.height(28.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Error Message Banner
                            AnimatedVisibility(visible = formError != null) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            formError ?: "",
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                    }
                                }
                            }

                            // Form Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = {
                                        showAddForm = false
                                        editingPeriod = null
                                        formError = null
                                    }
                                ) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        val yr = formYear.toIntOrNull()
                                        if (yr == null || yr < 1900 || yr > 2100) {
                                            formError = "Please enter a valid year (e.g. 2026)."
                                            return@Button
                                        }

                                        val rate = formRateCents.toDoubleOrNull()
                                        if (rate == null || rate <= 0.0) {
                                            formError = "Rate must be a positive number greater than 0."
                                            return@Button
                                        }

                                        val start = formStartDate.trim()
                                        val end = formEndDate.trim()
                                        if (start.length != 10 || end.length != 10) {
                                            formError = "Dates must be in YYYY-MM-DD format (e.g. 2026-01-01)."
                                            return@Button
                                        }

                                        if (start > end) {
                                            formError = "Start date cannot be after end date."
                                            return@Button
                                        }

                                        val cat = try {
                                            TripCategory.valueOf(formCategory)
                                        } catch (_: Exception) {
                                            TripCategory.BUSINESS
                                        }

                                        formError = null
                                        val currentEditing = editingPeriod
                                        if (currentEditing != null) {
                                            onUpdateRatePeriod(
                                                currentEditing.copy(
                                                    year = yr,
                                                    category = cat,
                                                    startDate = start,
                                                    endDate = end,
                                                    rateCents = rate,
                                                    label = formLabel.trim().ifEmpty { "${yr} ${cat.name} Rate" }
                                                )
                                            )
                                        } else {
                                            onAddRatePeriod(
                                                RatePeriod(
                                                    year = yr,
                                                    category = cat,
                                                    startDate = start,
                                                    endDate = end,
                                                    rateCents = rate,
                                                    label = formLabel.trim().ifEmpty { "${yr} ${cat.name} Rate" }
                                                )
                                            )
                                        }
                                        showAddForm = false
                                        editingPeriod = null
                                    }
                                ) {
                                    Text(if (editingPeriod != null) "Update Rate" else "Save Rate")
                                }
                            }
                        }
                    }
                }

                // If not currently adding, show "Add Custom Rate" button
                if (!showAddForm && editingPeriod == null) {
                    OutlinedButton(
                        onClick = {
                            val activeYr = selectedYearFilter.toIntOrNull() ?: 2026
                            formYear = activeYr.toString()
                            formStartDate = "$activeYr-01-01"
                            formEndDate = "$activeYr-12-31"
                            formCategory = TripCategory.BUSINESS.name
                            formRateCents = "70.5"
                            formLabel = "Custom Reimbursement Rate"
                            showAddForm = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("add_custom_rate_btn"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Custom Rate Period", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Rate Periods List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredPeriods, key = { it.id }) { period ->
                        RatePeriodCard(
                            period = period,
                            currencySymbol = currencySymbol,
                            distanceUnit = distanceUnit,
                            onEdit = {
                                editingPeriod = period
                                formYear = period.year.toString()
                                formCategory = period.category.name
                                formRateCents = period.rateCents.toString()
                                formStartDate = period.startDate
                                formEndDate = period.endDate
                                formLabel = period.label
                                showAddForm = false
                            },
                            onDelete = {
                                periodToDelete = period
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )

    // Delete Confirmation Dialog
    if (periodToDelete != null) {
        val target = periodToDelete!!
        AlertDialog(
            onDismissRequest = { periodToDelete = null },
            title = { Text("Delete Rate Period?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove '${target.label}' (${target.startDate} to ${target.endDate})?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteRatePeriod(target.id)
                        periodToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { periodToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Reset Confirmation Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("Reset to Official IRS Rates?", fontWeight = FontWeight.Bold) },
            text = { Text("This will restore official statutory IRS rates (2023–2027: 65.5¢, 67¢, 70¢, 70.5¢ business; 14¢ charity; 21–22¢ medical). Any custom user rates will be replaced.") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirmDialog = false
                        onResetRatesToDefault()
                    }
                ) {
                    Text("Reset Rates")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun RatePeriodCard(
    period: RatePeriod,
    currencySymbol: String,
    distanceUnit: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val badgeColor = when (period.category) {
        TripCategory.BUSINESS -> BadgeBusiness
        TripCategory.CHARITY -> BadgeCharity
        TripCategory.MEDICAL -> BadgeMedical
        TripCategory.PERSONAL -> BadgePersonal
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Category Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(badgeColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = period.category.name,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${period.year}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = period.label,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.DateRange,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${period.startDate} → ${period.endDate}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Rate Display & Actions
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.padding(start = 6.dp)
            ) {
                // Rate value
                val formattedRatePerUnit = "%.3f".format(period.rateCents / 100.0)
                Text(
                    text = "${period.rateCents}¢",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.5.sp,
                    color = PrimaryForestGreen
                )
                Text(
                    text = "$currencySymbol$formattedRatePerUnit / $distanceUnit",
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Rate",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete Rate",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}
