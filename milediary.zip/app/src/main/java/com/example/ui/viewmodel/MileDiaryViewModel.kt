package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.MileDiaryDatabase
import com.example.data.model.OdoBoundary
import com.example.data.model.RatePeriod
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.data.repository.MileDiaryRepository
import com.example.domain.engine.MathEngine
import com.example.domain.report.CsvReportManager
import com.example.domain.report.PdfReportGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.time.LocalDate

class MileDiaryViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MileDiaryDatabase.getDatabase(application, viewModelScope)
    val repository = MileDiaryRepository(
        vehicleDao = database.vehicleDao(),
        odoBoundaryDao = database.odoBoundaryDao(),
        tripDao = database.tripDao(),
        templateDao = database.templateDao(),
        ratePeriodDao = database.ratePeriodDao(),
        appSettingDao = database.appSettingDao()
    )

    // Filter & Selection State
    val currentYear = LocalDate.now().year
    private val _selectedYear = MutableStateFlow(if (currentYear < 2026) 2026 else currentYear)
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(LocalDate.now().monthValue) // 1..12 or 0 for All
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<TripCategory?>(null)
    val selectedCategoryFilter: StateFlow<TripCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _filterOnlyShifts = MutableStateFlow(false)
    val filterOnlyShifts: StateFlow<Boolean> = _filterOnlyShifts.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedVehicleId = MutableStateFlow<Long?>(null)
    val selectedVehicleId: StateFlow<Long?> = _selectedVehicleId.asStateFlow()

    // Database Flows
    val vehicles: StateFlow<List<Vehicle>> = repository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val templates: StateFlow<List<Template>> = repository.allTemplates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ratePeriods: StateFlow<List<RatePeriod>> = repository.allRatePeriods
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val odoBoundaries: StateFlow<List<OdoBoundary>> = repository.allOdoBoundaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTripsRaw: StateFlow<List<Trip>> = repository.allTrips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Settings with instantaneous in-memory StateFlows for zero UI lag
    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _homeAddress = MutableStateFlow("")
    val homeAddress: StateFlow<String> = _homeAddress.asStateFlow()

    private val _officeAddress = MutableStateFlow("")
    val officeAddress: StateFlow<String> = _officeAddress.asStateFlow()

    private val _taxBracket = MutableStateFlow("25")
    val taxBracket: StateFlow<String> = _taxBracket.asStateFlow()

    private val _isPro = MutableStateFlow("false")
    val isPro: StateFlow<String> = _isPro.asStateFlow()

    private val _lastBackupTime = MutableStateFlow(0L)
    val lastBackupTime: StateFlow<Long> = _lastBackupTime.asStateFlow()

    private val _hasSeenOnboarding = MutableStateFlow("false")
    val hasSeenOnboarding: StateFlow<String> = _hasSeenOnboarding.asStateFlow()

    private val _currencySymbol = MutableStateFlow("$")
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    private val _distanceUnit = MutableStateFlow("mi")
    val distanceUnit: StateFlow<String> = _distanceUnit.asStateFlow()

    private val _businessName = MutableStateFlow("")
    val businessName: StateFlow<String> = _businessName.asStateFlow()

    private val _taxId = MutableStateFlow("")
    val taxId: StateFlow<String> = _taxId.asStateFlow()

    private val _signerName = MutableStateFlow("")
    val signerName: StateFlow<String> = _signerName.asStateFlow()

    private val _autoBackupEnabled = MutableStateFlow(true)
    val autoBackupEnabled: StateFlow<Boolean> = _autoBackupEnabled.asStateFlow()

    // Undo capability
    private var lastDeletedTrip: Trip? = null

    // UI Events (e.g. Snackbars, Export complete)
    private val _uiEvents = MutableSharedFlow<String>()
    val uiEvents: SharedFlow<String> = _uiEvents.asSharedFlow()

    // Filter Parameters Data Holder
    data class FilterParams(
        val year: Int,
        val month: Int,
        val category: TripCategory?,
        val onlyShifts: Boolean,
        val query: String,
        val vehicleId: Long?
    )

    private val filterParams: Flow<FilterParams> = combine(
        combine(_selectedYear, _selectedMonth, _selectedCategoryFilter) { y, m, c -> Triple(y, m, c) },
        combine(_filterOnlyShifts, _searchQuery, _selectedVehicleId) { s, q, v -> Triple(s, q, v) }
    ) { (y, m, c), (s, q, v) ->
        FilterParams(y, m, c, s, q, v)
    }

    // Filtered Trips Flow
    val filteredTrips: StateFlow<List<Trip>> = combine(
        allTripsRaw,
        filterParams
    ) { trips, filter ->
        trips.filter { trip ->
            val dateMatches = if (filter.month == 0) {
                trip.date.startsWith("${filter.year}-")
            } else {
                val monthPrefix = String.format("%04d-%02d", filter.year, filter.month)
                trip.date.startsWith(monthPrefix)
            }

            val categoryMatches = filter.category == null || trip.category == filter.category
            val shiftMatches = !filter.onlyShifts || trip.isShift
            val vehicleMatches = filter.vehicleId == null || trip.vehicleId == filter.vehicleId

            val queryMatches = if (filter.query.isBlank()) true else {
                val q = filter.query.trim().lowercase()
                trip.fromLoc.lowercase().contains(q) ||
                        trip.toLoc.lowercase().contains(q) ||
                        trip.purpose.lowercase().contains(q) ||
                        (trip.platform?.lowercase()?.contains(q) == true) ||
                        (trip.tag?.lowercase()?.contains(q) == true) ||
                        trip.note.lowercase().contains(q)
            }

            dateMatches && categoryMatches && shiftMatches && vehicleMatches && queryMatches
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Aggregated Stats
    val currentStats: StateFlow<MathEngine.AggregatedStats> = combine(
        filteredTrips,
        ratePeriods,
        taxBracket
    ) { trips, rates, bracket ->
        val bracketDouble = bracket.toDoubleOrNull() ?: 25.0
        MathEngine.calculateStats(trips, rates, bracketDouble)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MathEngine.AggregatedStats.EMPTY
    )

    // Year-wide Stats for Annual Dashboard & PDF
    val yearStats: StateFlow<MathEngine.AggregatedStats> = combine(
        allTripsRaw,
        _selectedYear,
        ratePeriods,
        taxBracket
    ) { trips, year, rates, bracket ->
        val yearTrips = trips.filter { it.date.startsWith("$year-") }
        val bracketDouble = bracket.toDoubleOrNull() ?: 25.0
        MathEngine.calculateStats(yearTrips, rates, bracketDouble)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MathEngine.AggregatedStats.EMPTY
    )

    init {
        // Automatically check if initial vehicle and rates are needed
        viewModelScope.launch(Dispatchers.IO) {
            val count = repository.getVehicleCount()
            if (count == 0) {
                repository.insertVehicle(
                    Vehicle(
                        name = "Primary Car",
                        make = "Toyota",
                        model = "Corolla",
                        year = "2022",
                        isPrimary = true
                    )
                )
            }
            if (repository.getRatePeriodCount() == 0) {
                repository.populateDefaultRates()
            }

            // Hydrate in-memory state from database for zero-latency UI
            _userName.value = repository.getSettingSync("user_name", "")
            _businessName.value = repository.getSettingSync("business_name", "")
            _taxId.value = repository.getSettingSync("tax_id", "")
            _signerName.value = repository.getSettingSync("signer_name", "")
            _homeAddress.value = repository.getSettingSync("home_address", "")
            _officeAddress.value = repository.getSettingSync("office_address", "")
            _taxBracket.value = repository.getSettingSync("tax_bracket", "25")
            _currencySymbol.value = repository.getSettingSync("currency_symbol", "$")
            _distanceUnit.value = repository.getSettingSync("distance_unit", "mi")
            _isPro.value = repository.getSettingSync("pro_unlocked", "false")
            _lastBackupTime.value = repository.getSettingSync("last_backup_time", "0").toLongOrNull() ?: 0L
            _hasSeenOnboarding.value = repository.getSettingSync("has_seen_onboarding", "false")
            _autoBackupEnabled.value = repository.getSettingSync("auto_backup_enabled", "true").toBoolean()

            // Initial auto-backup safety check if trips exist
            if (_autoBackupEnabled.value && repository.getAllTripsSync().isNotEmpty()) {
                try {
                    com.example.domain.backup.BackupManager.performAutoBackup(getApplication(), repository)
                } catch (_: Exception) {}
            }
        }
    }

    // --- Navigation & Filter Controls ---
    fun selectYear(year: Int) {
        _selectedYear.value = year
    }

    fun selectMonth(month: Int) {
        _selectedMonth.value = month
    }

    fun setCategoryFilter(category: TripCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun toggleOnlyShifts() {
        _filterOnlyShifts.value = !_filterOnlyShifts.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedVehicleId(id: Long?) {
        _selectedVehicleId.value = id
    }

    // --- Trip Operations ---
    fun saveTrip(trip: Trip, onSuccess: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            if (trip.id == 0L) {
                repository.insertTrip(trip)
                _uiEvents.emit("Trip logged successfully")
            } else {
                repository.updateTrip(trip.copy(updatedAt = System.currentTimeMillis(), edited = true))
                _uiEvents.emit("Trip updated")
            }
            triggerAutoBackupIfNeeded()
            withContext(Dispatchers.Main) { onSuccess() }
        }
    }

    fun deleteTrip(trip: Trip) {
        viewModelScope.launch(Dispatchers.IO) {
            lastDeletedTrip = trip
            repository.deleteTrip(trip)
            _uiEvents.emit("Trip deleted")
            triggerAutoBackupIfNeeded()
        }
    }

    fun undoDeleteTrip() {
        val trip = lastDeletedTrip ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertTrip(trip)
            lastDeletedTrip = null
            _uiEvents.emit("Trip restored")
            triggerAutoBackupIfNeeded()
        }
    }

    suspend fun getLastOdoForVehicle(vehicleId: Long): Double? {
        return repository.getLastTripWithOdo(vehicleId)?.odoEnd
    }

    suspend fun checkDuplicate(vehicleId: Long, date: String, fromLoc: String, toLoc: String): Boolean {
        return repository.findRecentDuplicate(vehicleId, date, fromLoc, toLoc) != null
    }

    // --- Templates ---
    fun saveTemplate(template: Template) {
        viewModelScope.launch(Dispatchers.IO) {
            if (template.id == 0L) {
                repository.insertTemplate(template)
                _uiEvents.emit("Template saved")
            } else {
                repository.updateTemplate(template)
                _uiEvents.emit("Template updated")
            }
            triggerAutoBackupIfNeeded()
        }
    }

    fun deleteTemplate(template: Template) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTemplate(template)
            _uiEvents.emit("Template removed")
            triggerAutoBackupIfNeeded()
        }
    }

    fun recordTemplateUsage(templateId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordTemplateUse(templateId)
        }
    }

    // --- Vehicles & Odometer Boundaries ---
    fun saveVehicle(vehicle: Vehicle) {
        viewModelScope.launch(Dispatchers.IO) {
            if (vehicle.id == 0L) {
                repository.insertVehicle(vehicle)
                _uiEvents.emit("Vehicle added")
            } else {
                repository.updateVehicle(vehicle)
                _uiEvents.emit("Vehicle updated")
            }
        }
    }

    fun deleteVehicle(vehicle: Vehicle, targetReassignId: Long?) {
        viewModelScope.launch(Dispatchers.IO) {
            if (targetReassignId != null) {
                repository.reassignVehicleTrips(vehicle.id, targetReassignId)
                if (vehicle.isPrimary) {
                    repository.setPrimaryVehicle(targetReassignId)
                }
            }
            repository.deleteVehicle(vehicle)
            _uiEvents.emit("Vehicle deleted")
        }
    }

    fun completeOnboarding(carName: String, jan1Odo: Double?, taxpayerName: String, year: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setSetting("has_seen_onboarding", "true")
            if (taxpayerName.isNotBlank()) {
                repository.setSetting("user_name", taxpayerName.trim())
            }
            val existingVehicles = repository.getAllVehiclesSync()
            val vehicleId = if (existingVehicles.isNotEmpty()) {
                val primaryCar = existingVehicles.first()
                val updated = primaryCar.copy(name = carName.trim(), isPrimary = true)
                repository.updateVehicle(updated)
                primaryCar.id
            } else {
                repository.insertVehicle(Vehicle(name = carName.trim(), isPrimary = true))
            }
            if (jan1Odo != null) {
                repository.saveOdoBoundary(
                    OdoBoundary(
                        vehicleId = vehicleId,
                        year = year,
                        jan1Odo = jan1Odo
                    )
                )
            }
            _uiEvents.emit("Welcome to MileDiary!")
        }
    }

    fun setPrimaryVehicle(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setPrimaryVehicle(id)
            _uiEvents.emit("Primary vehicle updated")
        }
    }

    fun saveOdoBoundary(boundary: OdoBoundary) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveOdoBoundary(boundary)
            _uiEvents.emit("Odometer reading saved")
        }
    }

    // --- Settings & Pro ---
    fun updateSetting(key: String, value: String) {
        // Immediate in-memory update for 0ms UI response without frame drops
        when (key) {
            "user_name" -> _userName.value = value
            "business_name" -> _businessName.value = value
            "tax_id" -> _taxId.value = value
            "signer_name" -> _signerName.value = value
            "home_address" -> _homeAddress.value = value
            "office_address" -> _officeAddress.value = value
            "tax_bracket" -> _taxBracket.value = value
            "currency_symbol" -> _currencySymbol.value = value
            "distance_unit" -> _distanceUnit.value = value
            "pro_unlocked" -> _isPro.value = value
            "has_seen_onboarding" -> _hasSeenOnboarding.value = value
            "auto_backup_enabled" -> _autoBackupEnabled.value = value.toBoolean()
            "last_backup_time" -> _lastBackupTime.value = value.toLongOrNull() ?: 0L
        }
        viewModelScope.launch(Dispatchers.IO) {
            repository.setSetting(key, value)
        }
    }

    fun toggleAutoBackup(enabled: Boolean) {
        updateSetting("auto_backup_enabled", enabled.toString())
        if (enabled) {
            triggerAutoBackupIfNeeded()
            viewModelScope.launch {
                _uiEvents.emit("✅ Automatic logbook backup enabled")
            }
        } else {
            viewModelScope.launch {
                _uiEvents.emit("Automatic backup paused")
            }
        }
    }

    fun triggerAutoBackupIfNeeded() {
        if (!_autoBackupEnabled.value) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                com.example.domain.backup.BackupManager.performAutoBackup(getApplication(), repository)
                val now = System.currentTimeMillis()
                _lastBackupTime.value = now
                repository.setSetting("last_backup_time", now.toString())
            } catch (_: Exception) {}
        }
    }

    fun restoreFromLatestAutoBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            val result = com.example.domain.backup.BackupManager.restoreAutoBackup(getApplication(), repository)
            if (result.success) {
                val now = System.currentTimeMillis()
                _lastBackupTime.value = now
                repository.setSetting("last_backup_time", now.toString())
                // Re-hydrate settings in memory
                _userName.value = repository.getSettingSync("user_name", "")
                _businessName.value = repository.getSettingSync("business_name", "")
                _taxId.value = repository.getSettingSync("tax_id", "")
                _signerName.value = repository.getSettingSync("signer_name", "")
                _homeAddress.value = repository.getSettingSync("home_address", "")
                _officeAddress.value = repository.getSettingSync("office_address", "")
                _taxBracket.value = repository.getSettingSync("tax_bracket", "25")
                _currencySymbol.value = repository.getSettingSync("currency_symbol", "$")
                _distanceUnit.value = repository.getSettingSync("distance_unit", "mi")
                _isPro.value = repository.getSettingSync("pro_unlocked", "false")
                _uiEvents.emit("✅ Restored from latest auto-backup snapshot!")
            } else {
                _uiEvents.emit("❌ ${result.message}")
            }
        }
    }

    fun unlockPro() {
        _isPro.value = "true"
        viewModelScope.launch(Dispatchers.IO) {
            repository.setProUnlocked(true)
            _uiEvents.emit("🎉 MileDiary Pro Lifetime unlocked!")
        }
    }

    fun markBackupCompleted() {
        val now = System.currentTimeMillis()
        _lastBackupTime.value = now
        viewModelScope.launch(Dispatchers.IO) {
            repository.setSetting("last_backup_time", now.toString())
            _uiEvents.emit("Backup saved successfully")
        }
    }

    suspend fun exportFullBackup(): File? {
        return withContext(Dispatchers.IO) {
            try {
                val file = com.example.domain.backup.BackupManager.exportBackupToFile(getApplication(), repository)
                val now = System.currentTimeMillis()
                _lastBackupTime.value = now
                repository.setSetting("last_backup_time", now.toString())
                _uiEvents.emit("✅ Full backup generated: ${file.name}")
                file
            } catch (e: Exception) {
                _uiEvents.emit("❌ Export failed: ${e.localizedMessage}")
                null
            }
        }
    }

    suspend fun restoreFullBackup(stream: InputStream): com.example.domain.backup.BackupManager.RestoreResult {
        return withContext(Dispatchers.IO) {
            val res = com.example.domain.backup.BackupManager.restoreBackupFromStream(stream, repository)
            if (res.success) {
                val now = System.currentTimeMillis()
                _lastBackupTime.value = now
                repository.setSetting("last_backup_time", now.toString())
                // Re-hydrate settings in memory
                _userName.value = repository.getSettingSync("user_name", "")
                _businessName.value = repository.getSettingSync("business_name", "")
                _taxId.value = repository.getSettingSync("tax_id", "")
                _signerName.value = repository.getSettingSync("signer_name", "")
                _homeAddress.value = repository.getSettingSync("home_address", "")
                _officeAddress.value = repository.getSettingSync("office_address", "")
                _taxBracket.value = repository.getSettingSync("tax_bracket", "25")
                _currencySymbol.value = repository.getSettingSync("currency_symbol", "$")
                _distanceUnit.value = repository.getSettingSync("distance_unit", "mi")
                _isPro.value = repository.getSettingSync("pro_unlocked", "false")
                _uiEvents.emit("✅ ${res.message}")
            } else {
                _uiEvents.emit("❌ ${res.message}")
            }
            res
        }
    }

    // --- Sample & Diagnostic Test Data ---
    fun loadSampleData() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.domain.sample.SampleDataManager.populateSampleData(repository)
            _selectedYear.value = 2026
            _selectedMonth.value = 0 // Show all drives
            _uiEvents.emit("✅ Loaded 120+ full-year daily drives across 2024, 2025, 2026, and 2027!")
            triggerAutoBackupIfNeeded()
        }
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.domain.sample.SampleDataManager.clearAllData(repository)
            _uiEvents.emit("All trips, templates, and odometer boundaries cleared.")
            triggerAutoBackupIfNeeded()
        }
    }

    // --- Export / Import ---
    suspend fun generatePdfReport(year: Int, vehicleId: Long?): File? {
        return withContext(Dispatchers.IO) {
            val trips = repository.getAllTripsSync().filter {
                it.date.startsWith("$year-") && (vehicleId == null || it.vehicleId == vehicleId)
            }
            val rates = repository.getAllRatePeriodsSync()
            val vehicle = vehicleId?.let { vId -> vehicles.value.find { it.id == vId } }
            val boundary = vehicleId?.let { vId ->
                database.odoBoundaryDao().getBoundarySync(vId, year)
            }
            val name = repository.getSettingSync("user_name", "")
            val biz = repository.getSettingSync("business_name", "")
            val tId = repository.getSettingSync("tax_id", "")
            val sName = repository.getSettingSync("signer_name", "")
            val curr = repository.getSettingSync("currency_symbol", "$")
            val dist = repository.getSettingSync("distance_unit", "mi")

            PdfReportGenerator.generateIrsPdfReport(
                context = getApplication(),
                taxpayerName = name,
                year = year,
                vehicle = vehicle,
                boundary = boundary,
                trips = trips,
                ratePeriods = rates,
                businessName = biz,
                taxId = tId,
                signerName = sName,
                currencySymbol = curr,
                distanceUnit = dist
            )
        }
    }

    suspend fun generateCsvReport(year: Int, vehicleId: Long?): File? {
        return withContext(Dispatchers.IO) {
            val trips = repository.getAllTripsSync().filter {
                it.date.startsWith("$year-") && (vehicleId == null || it.vehicleId == vehicleId)
            }
            val rates = repository.getAllRatePeriodsSync()
            CsvReportManager.generateCsvReport(
                context = getApplication(),
                year = year,
                trips = trips,
                ratePeriods = rates
            )
        }
    }

    suspend fun importCsvStream(stream: InputStream, vehicleId: Long): CsvReportManager.ImportResult {
        return withContext(Dispatchers.IO) {
            val existing = repository.getAllTripsSync()
            val result = CsvReportManager.parseCsv(stream, vehicleId, existing)
            if (result.importedTrips.isNotEmpty()) {
                repository.insertTrips(result.importedTrips)
                triggerAutoBackupIfNeeded()
            }
            result
        }
    }

    // --- Rate Period Management ---
    fun updateRatePeriod(ratePeriod: RatePeriod) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateRatePeriod(ratePeriod)
            triggerAutoBackupIfNeeded()
            _uiEvents.emit("✅ Rate updated: ${ratePeriod.label} (${ratePeriod.rateCents}¢)")
        }
    }

    fun addRatePeriod(ratePeriod: RatePeriod) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertRatePeriod(ratePeriod)
            triggerAutoBackupIfNeeded()
            _uiEvents.emit("✅ Added rate: ${ratePeriod.label} (${ratePeriod.rateCents}¢)")
        }
    }

    fun deleteRatePeriod(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteRatePeriod(id)
            triggerAutoBackupIfNeeded()
            _uiEvents.emit("Rate period deleted")
        }
    }

    fun resetRatesToDefault() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.resetRatesToDefault()
            triggerAutoBackupIfNeeded()
            _uiEvents.emit("✅ Reset to official IRS statutory rates!")
        }
    }
}
