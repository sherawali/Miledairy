package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TripCategory
import com.example.ui.theme.BadgeBusiness
import com.example.ui.theme.BadgeCharity
import com.example.ui.theme.BadgeMedical
import com.example.ui.theme.BadgePersonal

@Composable
fun CategoryBadge(
    category: TripCategory,
    isCommute: Boolean = false,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when {
        isCommute -> Triple(Color(0xFFE2E8F0), Color(0xFF475569), "Commute ($0)")
        category == TripCategory.BUSINESS -> Triple(BadgeBusiness.copy(alpha = 0.15f), BadgeBusiness, "Business")
        category == TripCategory.CHARITY -> Triple(BadgeCharity.copy(alpha = 0.15f), BadgeCharity, "Charity")
        category == TripCategory.MEDICAL -> Triple(BadgeMedical.copy(alpha = 0.15f), BadgeMedical, "Medical")
        category == TripCategory.PERSONAL -> Triple(BadgePersonal.copy(alpha = 0.15f), BadgePersonal, "Personal")
        else -> Triple(Color.LightGray, Color.DarkGray, category.displayName)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
