package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.domain.engine.MathEngine
import com.example.ui.theme.BadgeBusiness
import com.example.ui.theme.BadgeCharity
import com.example.ui.theme.BadgeMedical
import com.example.ui.theme.TertiaryAmber
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    trips: List<Trip>,
    yearStats: MathEngine.AggregatedStats,
    ratePeriods: List<RatePeriod>,
    selectedYear: Int,
    taxBracketPercent: Double,
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    onSelectYear: (Int) -> Unit
) {
    // Filter trips for selected year
    val yearTrips = remember(trips, selectedYear) {
        trips.filter { it.date.startsWith("$selectedYear-") }
    }

    // Monthly breakdown data
    val monthlyData = remember(yearTrips, ratePeriods) {
        (1..12).map { month ->
            val monthPrefix = String.format("%04d-%02d", selectedYear, month)
            val mTrips = yearTrips.filter { it.date.startsWith(monthPrefix) }
            val stats = MathEngine.calculateStats(mTrips, ratePeriods)
            Pair(Month.of(month).getDisplayName(TextStyle.SHORT, Locale.getDefault()), stats)
        }
    }

    // Platform subtotals
    val platformSubtotals = remember(yearTrips) {
        yearTrips.filter { it.platform != null && it.platform.isNotBlank() }
            .groupBy { it.platform!! }
            .mapValues { (_, pTrips) -> pTrips.sumOf { it.miles } }
            .toList()
            .sortedByDescending { it.second }
    }

    // Tag subtotals
    val tagSubtotals = remember(yearTrips) {
        yearTrips.filter { it.tag != null && it.tag.isNotBlank() }
            .groupBy { it.tag!! }
            .mapValues { (_, tTrips) -> tTrips.sumOf { it.miles } }
            .toList()
            .sortedByDescending { it.second }
    }

    val currentCalYear = remember { LocalDate.now().year }
    val availableYears = remember(currentCalYear) {
        listOf(currentCalYear - 2, currentCalYear - 1, currentCalYear, currentCalYear + 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Tax Analytics", fontWeight = FontWeight.Bold, maxLines = 1)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Year Selector Bar
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                items(availableYears.size) { idx ->
                    val yr = availableYears[idx]
                    FilterChip(
                        selected = selectedYear == yr,
                        onClick = { onSelectYear(yr) },
                        label = {
                            val suffix = when {
                                yr == currentCalYear -> " • Current"
                                yr > currentCalYear -> " • Upcoming"
                                else -> ""
                            }
                            Text(
                                text = "$yr$suffix",
                                fontWeight = if (selectedYear == yr) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    )
                }
            }
            // Hero Deduction Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$selectedYear TOTAL TAX DEDUCTION",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "$currencySymbol${String.format("%.2f", yearStats.totalDeduction)}",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        color = TertiaryAmber
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "≈ $currencySymbol${String.format("%.2f", yearStats.estimatedTaxSavings)} saved in actual taxes (${taxBracketPercent.toInt()}% tax bracket)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Business $distanceUnit", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                            Text("${yearStats.businessMiles} $distanceUnit", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Business Use %", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                            Text("${yearStats.businessPercentage}%", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Total Drives", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                            Text("${yearStats.tripCount}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Category Breakdown Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "IRS Category Breakdown",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Business row
                    val bizRatio = if (yearStats.totalMiles > 0) (yearStats.businessMiles / yearStats.totalMiles).toFloat() else 0f
                    CategoryProgressRow(
                        label = "Business",
                        miles = yearStats.businessMiles,
                        deduction = yearStats.businessDeduction,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        color = BadgeBusiness,
                        progress = bizRatio
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Charity row
                    val charRatio = if (yearStats.totalMiles > 0) (yearStats.charityMiles / yearStats.totalMiles).toFloat() else 0f
                    CategoryProgressRow(
                        label = "Charity (14¢)",
                        miles = yearStats.charityMiles,
                        deduction = yearStats.charityDeduction,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        color = BadgeCharity,
                        progress = charRatio
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Medical row
                    val medRatio = if (yearStats.totalMiles > 0) (yearStats.medicalMiles / yearStats.totalMiles).toFloat() else 0f
                    CategoryProgressRow(
                        label = "Medical / Move",
                        miles = yearStats.medicalMiles,
                        deduction = yearStats.medicalDeduction,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        color = BadgeMedical,
                        progress = medRatio
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Personal row
                    val persRatio = if (yearStats.totalMiles > 0) (yearStats.personalMiles / yearStats.totalMiles).toFloat() else 0f
                    CategoryProgressRow(
                        label = "Personal (Non-deductible)",
                        miles = yearStats.personalMiles,
                        deduction = 0.0,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        color = Color.Gray,
                        progress = persRatio
                    )
                }
            }

            // Monthly Activity Bar Grid
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Monthly Mileage ($selectedYear)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val maxMonthMiles = maxOf(10.0, monthlyData.maxOf { it.second.businessMiles })

                    monthlyData.forEach { (mLabel, mStats) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mLabel,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(36.dp)
                            )

                            val barFraction = (mStats.businessMiles / maxMonthMiles).toFloat().coerceIn(0f, 1f)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(14.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                if (barFraction > 0.001f) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(barFraction)
                                            .height(14.dp)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${mStats.businessMiles} $distanceUnit",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.width(60.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                        }
                    }
                }
            }

            // Gig Platforms Subtotals (DoorDash / Uber / Lyft / etc.)
            if (platformSubtotals.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Gig Platforms & Services",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        platformSubtotals.forEach { (plat, mi) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(plat, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("${String.format("%.1f", mi)} $distanceUnit", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // Tags Subtotals (Clients, Projects)
            if (tagSubtotals.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Top Client / Property Tags",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        tagSubtotals.take(10).forEach { (t, mi) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("#$t", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("${String.format("%.1f", mi)} miles", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Statutory IRS compliance note
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Calculations use standard IRS mileage rates per IRC §274(d). Unreimbursed W-2 employee deductions were repealed under TCJA. Consult your tax preparer for filing Schedule C or Form 1040.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
private fun CategoryProgressRow(
    label: String,
    miles: Double,
    deduction: Double,
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    color: Color,
    progress: Float
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .padding(end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Text(
                text = "${miles} $distanceUnit ($currencySymbol${String.format("%.2f", deduction)})",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}
