package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Forest Green & Sand Palette
val PrimaryForestGreen = Color(0xFF166534)
val PrimaryForestGreenDark = Color(0xFF22C55E)
val DarkGreen = Color(0xFF15803D)
val SecondaryGreen = Color(0xFF1E3A2B)
val TertiaryAmber = Color(0xFFB45309)
val TertiaryAmberDark = Color(0xFFFBBF24)

val PaperLightBackground = Color(0xFFFAFAF7)
val PaperLightSurface = Color(0xFFFFFFFF)
val PaperLightSurfaceVariant = Color(0xFFF1F1EC)
val TextDark = Color(0xFF1A1C19)
val TextSecondaryLight = Color(0xFF5A6058)

val DarkBackground = Color(0xFF111411)
val DarkSurface = Color(0xFF181C18)
val DarkSurfaceVariant = Color(0xFF232823)
val TextLight = Color(0xFFE2E3DF)
val TextSecondaryDark = Color(0xFF9EABA0)

val ErrorRed = Color(0xFFB3261E)
val ErrorRedDark = Color(0xFFF2B8B5)

val BadgeBusiness = Color(0xFF166534)
val BadgeCharity = Color(0xFF7C3AED)
val BadgeMedical = Color(0xFF0284C7)
val BadgePersonal = Color(0xFF64748B)
