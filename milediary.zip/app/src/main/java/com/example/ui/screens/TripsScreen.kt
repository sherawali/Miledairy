package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.domain.engine.MathEngine
import com.example.ui.components.BackupHealthDot
import com.example.ui.components.TripCard
import com.example.ui.theme.TertiaryAmber
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.Month
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripsScreen(
    trips: List<Trip>,
    allTrips: List<Trip> = emptyList(),
    stats: MathEngine.AggregatedStats,
    ratePeriods: List<RatePeriod>,
    vehicles: List<Vehicle>,
    selectedYear: Int,
    selectedMonth: Int,
    selectedCategory: TripCategory?,
    onlyShifts: Boolean,
    searchQuery: String,
    lastBackupTime: Long,
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    snackbarHostState: SnackbarHostState,
    onSelectYear: (Int) -> Unit,
    onSelectMonth: (Int) -> Unit,
    onSelectCategory: (TripCategory?) -> Unit,
    onToggleShifts: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenBackup: () -> Unit,
    onAddTrip: () -> Unit,
    onEditTrip: (Trip) -> Unit,
    onDuplicateTrip: (Trip) -> Unit,
    onSaveAsTemplate: (Trip) -> Unit,
    onDeleteTrip: (Trip) -> Unit
) {
    var showSearchRow by rememberSaveable { mutableStateOf(false) }
    var showMonthMenu by remember { mutableStateOf(false) }
    var showYearMenu by remember { mutableStateOf(false) }
    var filterThisWeek by rememberSaveable { mutableStateOf(false) }

    val today = remember { LocalDate.now() }
    val mondayOfWeek = remember(today) { today.with(DayOfWeek.MONDAY) }
    val sundayOfWeek = remember(today) { today.with(DayOfWeek.SUNDAY) }
    val weekFormatter = remember { DateTimeFormatter.ofPattern("MMM d") }
    val weekLabel = remember(mondayOfWeek, sundayOfWeek) {
        if (mondayOfWeek.month == sundayOfWeek.month) {
            "${mondayOfWeek.format(weekFormatter)}–${sundayOfWeek.dayOfMonth}"
        } else {
            "${mondayOfWeek.format(weekFormatter)} – ${sundayOfWeek.format(weekFormatter)}"
        }
    }

    val currentCalYear = remember { LocalDate.now().year }
    val availableYears = remember(currentCalYear) {
        listOf(currentCalYear + 1, currentCalYear, currentCalYear - 1, currentCalYear - 2)
    }

    val weekSource = if (filterThisWeek && allTrips.isNotEmpty()) allTrips else trips
    val displayedTrips = remember(weekSource, filterThisWeek, mondayOfWeek, sundayOfWeek) {
        if (!filterThisWeek) weekSource
        else weekSource.filter { t ->
            runCatching {
                val d = LocalDate.parse(t.date)
                !d.isBefore(mondayOfWeek) && !d.isAfter(sundayOfWeek)
            }.getOrDefault(false)
        }
    }

    val displayedStats = remember(displayedTrips, ratePeriods, stats, filterThisWeek) {
        if (!filterThisWeek) stats
        else MathEngine.calculateStats(displayedTrips, ratePeriods)
    }

    val monthName = if (selectedMonth in 1..12) {
        Month.of(selectedMonth).getDisplayName(TextStyle.SHORT, Locale.getDefault())
    } else "All Year"

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "MileDiary",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1
                    )
                },
                actions = {
                    BackupHealthDot(
                        lastBackupTimestamp = lastBackupTime,
                        onClick = onOpenBackup
                    )
                    IconButton(onClick = onOpenTemplates, modifier = Modifier.testTag("open_templates_button")) {
                        Icon(Icons.Default.Bookmark, contentDescription = "Templates")
                    }
                    IconButton(onClick = { showSearchRow = !showSearchRow }, modifier = Modifier.testTag("toggle_search_button")) {
                        Icon(Icons.Default.Search, contentDescription = "Search drives")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddTrip,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_trip")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Drive")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search Input Row
            AnimatedVisibility(visible = showSearchRow) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search location, client, note...") },
                        singleLine = true,
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_text_input")
                    )
                }
            }

            // Summary Strip for selected range
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (filterThisWeek) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 10.dp)
                    ) {
                        val headerLabel = if (filterThisWeek) "This Week ($weekLabel)" else if (selectedMonth == 0) "$selectedYear Overview" else "$monthName $selectedYear"

                        Text(
                            text = headerLabel,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (filterThisWeek) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        val tollsSuffix = if (displayedStats.totalParkingTolls > 0.0) " • +$currencySymbol${String.format("%.2f", displayedStats.totalParkingTolls)} tolls" else ""
                        Text(
                            text = "${displayedStats.businessMiles} biz $distanceUnit • ${displayedStats.totalMiles} total • ${displayedStats.tripCount} drives$tollsSuffix",
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (filterThisWeek) MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "+$currencySymbol${String.format("%.2f", displayedStats.totalDeduction)}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            maxLines = 1,
                            color = TertiaryAmber
                        )
                        Text(
                            text = "Est. deduction",
                            fontSize = 11.sp,
                            maxLines = 1,
                            color = if (filterThisWeek) MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Filter Chips Bar (Including Year & Month Dropdown Selectors)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Year Selector Chip
                item {
                    Box {
                        FilterChip(
                            selected = true,
                            onClick = { showYearMenu = true },
                            label = { Text("$selectedYear ▾", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.testTag("year_filter_chip")
                        )
                        DropdownMenu(
                            expanded = showYearMenu,
                            onDismissRequest = { showYearMenu = false }
                        ) {
                            availableYears.forEach { yr ->
                                val yrLabel = when {
                                    yr == currentCalYear -> "$yr (Current)"
                                    yr > currentCalYear -> "$yr (Upcoming)"
                                    else -> yr.toString()
                                }
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = yrLabel,
                                            fontWeight = if (yr == selectedYear) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        onSelectYear(yr)
                                        showYearMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Month Selector Chip
                item {
                    Box {
                        FilterChip(
                            selected = selectedMonth != 0,
                            onClick = { showMonthMenu = true },
                            label = { Text("$monthName ▾", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.testTag("month_filter_chip")
                        )
                        DropdownMenu(
                            expanded = showMonthMenu,
                            onDismissRequest = { showMonthMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Entire Year ($selectedYear)") },
                                onClick = {
                                    onSelectMonth(0)
                                    showMonthMenu = false
                                }
                            )
                            (1..12).forEach { m ->
                                val mName = Month.of(m).getDisplayName(TextStyle.FULL, Locale.getDefault())
                                DropdownMenuItem(
                                    text = { Text(mName) },
                                    onClick = {
                                        onSelectMonth(m)
                                        showMonthMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    FilterChip(
                        selected = filterThisWeek,
                        onClick = { filterThisWeek = !filterThisWeek },
                        label = { Text("📅 This Week") },
                        modifier = Modifier.testTag("filter_this_week_chip")
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == null && !onlyShifts && !filterThisWeek,
                        onClick = {
                            filterThisWeek = false
                            onSelectCategory(null)
                            if (onlyShifts) onToggleShifts()
                        },
                        label = { Text("All") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == TripCategory.BUSINESS,
                        onClick = { onSelectCategory(if (selectedCategory == TripCategory.BUSINESS) null else TripCategory.BUSINESS) },
                        label = { Text("Business") }
                    )
                }
                item {
                    FilterChip(
                        selected = onlyShifts,
                        onClick = onToggleShifts,
                        label = { Text("◐ Shifts") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == TripCategory.CHARITY,
                        onClick = { onSelectCategory(if (selectedCategory == TripCategory.CHARITY) null else TripCategory.CHARITY) },
                        label = { Text("Charity") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == TripCategory.MEDICAL,
                        onClick = { onSelectCategory(if (selectedCategory == TripCategory.MEDICAL) null else TripCategory.MEDICAL) },
                        label = { Text("Medical") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == TripCategory.PERSONAL,
                        onClick = { onSelectCategory(if (selectedCategory == TripCategory.PERSONAL) null else TripCategory.PERSONAL) },
                        label = { Text("Personal") }
                    )
                }
            }

            // Trips List or Empty State
            if (displayedTrips.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (filterThisWeek) "No drives logged this week ($weekLabel)"
                            else "No drives logged in $monthName $selectedYear",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "IRS regulations require contemporaneous logging near the time of drive. Takes just 10 seconds!",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = onAddTrip,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("empty_state_add_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Log Drive Now")
                        }
                    }
                }
            } else {
                // Group trips by date for clean IRS ledger scanning
                val groupedTrips = remember(displayedTrips) {
                    displayedTrips.groupBy { it.date }
                }

                // Compute untracked gaps between consecutive odometer readings for each vehicle
                val odoGapsMap = remember(displayedTrips) {
                    val gaps = mutableMapOf<Long, Double>()
                    val byVehicle = displayedTrips.groupBy { it.vehicleId }
                    byVehicle.forEach { (_, vehicleTrips) ->
                        val sortedAsc = vehicleTrips.sortedWith(compareBy({ it.date }, { it.id }))
                        var lastOdoEnd: Double? = null
                        sortedAsc.forEach { trip ->
                            if (trip.odoStart != null && lastOdoEnd != null) {
                                val gap = trip.odoStart - lastOdoEnd!!
                                if (gap > 0.5) {
                                    gaps[trip.id] = gap
                                }
                            }
                            if (trip.odoEnd != null) {
                                lastOdoEnd = trip.odoEnd
                            }
                        }
                    }
                    gaps
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groupedTrips.forEach { (date, tripsOnDate) ->
                        item(key = "header_$date") {
                            Text(
                                text = date,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 10.dp, bottom = 2.dp)
                            )
                        }

                        items(tripsOnDate, key = { it.id }) { trip ->
                            TripCard(
                                trip = trip,
                                ratePeriods = ratePeriods,
                                currencySymbol = currencySymbol,
                                distanceUnit = distanceUnit,
                                odoGapBefore = odoGapsMap[trip.id],
                                onEdit = { onEditTrip(trip) },
                                onDuplicate = { onDuplicateTrip(trip) },
                                onSaveAsTemplate = { onSaveAsTemplate(trip) },
                                onDelete = { onDeleteTrip(trip) }
                            )
                        }
                    }
                }
            }
        }
    }
}
