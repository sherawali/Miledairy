package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkGreen
import com.example.ui.theme.TertiaryAmber
import com.example.util.FormatUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    taxpayerName: String,
    businessName: String = "",
    taxId: String = "",
    signerName: String = "",
    homeAddress: String,
    officeAddress: String,
    taxBracket: String,
    currencySymbol: String = "$",
    distanceUnit: String = "mi",
    isPro: Boolean,
    lastBackupTime: Long,
    autoBackupEnabled: Boolean = true,
    ratePeriods: List<com.example.data.model.RatePeriod> = emptyList(),
    onUpdateName: (String) -> Unit,
    onUpdateBusinessName: (String) -> Unit = {},
    onUpdateTaxId: (String) -> Unit = {},
    onUpdateSignerName: (String) -> Unit = {},
    onUpdateHomeAddress: (String) -> Unit,
    onUpdateOfficeAddress: (String) -> Unit,
    onUpdateTaxBracket: (String) -> Unit,
    onUpdateCurrencySymbol: (String) -> Unit = {},
    onUpdateDistanceUnit: (String) -> Unit = {},
    onToggleAutoBackup: (Boolean) -> Unit = {},
    onRestoreAutoBackup: () -> Unit = {},
    onOpenVehicles: () -> Unit,
    onOpenRates: () -> Unit = {},
    onOpenPaywall: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onLoadSampleData: () -> Unit = {},
    onClearAllData: () -> Unit = {}
) {
    val context = LocalContext.current
    var editingProfile by rememberSaveable { mutableStateOf(false) }
    var nameField by rememberSaveable { mutableStateOf(taxpayerName) }
    var businessField by rememberSaveable { mutableStateOf(businessName) }
    var taxIdField by rememberSaveable { mutableStateOf(taxId) }
    var signerField by rememberSaveable { mutableStateOf(signerName) }
    var homeField by rememberSaveable { mutableStateOf(homeAddress) }
    var officeField by rememberSaveable { mutableStateOf(officeAddress) }
    var bracketField by rememberSaveable { mutableStateOf(taxBracket) }

    LaunchedEffect(taxpayerName, businessName, taxId, signerName, homeAddress, officeAddress, taxBracket) {
        if (!editingProfile) {
            nameField = taxpayerName
            businessField = businessName
            taxIdField = taxId
            signerField = signerName
            homeField = homeAddress
            officeField = officeAddress
            bracketField = taxBracket
        }
    }

    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showRestoreAutoConfirmDialog by remember { mutableStateOf(false) }
    var expandedFaqIndex by rememberSaveable { mutableStateOf<Int?>(null) }
    var showCompetitorMatrix by rememberSaveable { mutableStateOf(false) }

    val lastBackupFormatted = if (lastBackupTime > 0) {
        SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(lastBackupTime))
    } else "Never"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Customization", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Pro Status Banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isPro) MaterialTheme.colorScheme.primaryContainer else Color(0xFFFEF3C7)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenPaywall() }
                    .testTag("pro_status_banner")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (isPro) MaterialTheme.colorScheme.primary else TertiaryAmber, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPro) Icons.Default.LockOpen else Icons.Default.Star,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isPro) "MileDiary Pro Active" else "Upgrade to MileDiary Pro",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isPro) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFF78350F)
                        )
                        Text(
                            text = if (isPro) "All features unlocked: Unlimited PDF/CSV, fleet vehicles, digital signatures." else "No subscription. Zero GPS battery drain. Tap to view plans.",
                            fontSize = 12.sp,
                            color = if (isPro) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else Color(0xFF92400E)
                        )
                    }

                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TertiaryAmber)
                }
            }

            // Regional & Currency Customization Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Currency & Distance Units", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Select Currency:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    // Currency Chips
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val popularCurrencies = listOf(
                            "$" to "USD ($)",
                            "€" to "EUR (€)",
                            "£" to "GBP (£)",
                            "CA$" to "CAD (CA$)",
                            "₹" to "INR (₹)",
                            "AU$" to "AUD (AU$)"
                        )
                        items(popularCurrencies.size) { idx ->
                            val (sym, label) = popularCurrencies[idx]
                            FilterChip(
                                selected = currencySymbol == sym,
                                onClick = { onUpdateCurrencySymbol(sym) },
                                label = { Text(label, fontSize = 12.sp, maxLines = 1) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Distance Unit:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = distanceUnit == "mi",
                            onClick = { onUpdateDistanceUnit("mi") },
                            label = { Text("Miles (mi)", fontSize = 12.sp, maxLines = 1) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = distanceUnit == "km",
                            onClick = { onUpdateDistanceUnit("km") },
                            label = { Text("Kilometers (km)", fontSize = 12.sp, maxLines = 1) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Used for odometer calculations and reports (USA/UK: mi, Global: km)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Taxpayer Profile & Commute Detection Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Taxpayer & Business Profile", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            text = if (editingProfile) "Save" else "Edit",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable {
                                if (editingProfile) {
                                    onUpdateName(nameField)
                                    onUpdateBusinessName(businessField)
                                    onUpdateTaxId(taxIdField)
                                    onUpdateSignerName(signerField)
                                    onUpdateHomeAddress(homeField)
                                    onUpdateOfficeAddress(officeField)
                                    onUpdateTaxBracket(bracketField)
                                }
                                editingProfile = !editingProfile
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!editingProfile) {
                        Text("Taxpayer Name: ${taxpayerName.ifBlank { "Not set" }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Business Name: ${businessName.ifBlank { "Self-Employed / Freelancer" }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Tax ID / EIN: ${taxId.ifBlank { "Optional (will print on PDF if set)" }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Authorized Signer: ${signerName.ifBlank { taxpayerName.ifBlank { "Not set" } }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Home Base: ${homeAddress.ifBlank { "Not set" }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Primary Office: ${officeAddress.ifBlank { "Not set" }}", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("Tax Bracket: $taxBracket%", fontSize = 13.sp)
                    } else {
                        OutlinedTextField(
                            value = nameField,
                            onValueChange = {
                                nameField = it
                                onUpdateName(it)
                            },
                            label = { Text("Taxpayer Legal Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = businessField,
                            onValueChange = {
                                businessField = it
                                onUpdateBusinessName(it)
                            },
                            label = { Text("Business / Trade / Employer Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = taxIdField,
                            onValueChange = {
                                taxIdField = it
                                onUpdateTaxId(it)
                            },
                            label = { Text("Tax ID / Masked EIN (e.g. XX-XXX1234)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = signerField,
                            onValueChange = {
                                signerField = it
                                onUpdateSignerName(it)
                            },
                            label = { Text("Digital Signer Full Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = homeField,
                            onValueChange = {
                                homeField = it
                                onUpdateHomeAddress(it)
                            },
                            label = { Text("Home Base (for commute detection)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = officeField,
                            onValueChange = {
                                officeField = it
                                onUpdateOfficeAddress(it)
                            },
                            label = { Text("Primary Office Location") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = bracketField,
                            onValueChange = {
                                bracketField = it
                                onUpdateTaxBracket(it)
                            },
                            label = { Text("Estimated Tax Bracket %") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Vehicles Management Option
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenVehicles)
                    .testTag("manage_vehicles_row")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Manage Vehicles & Odometer", fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Annual Jan 1 & Dec 31 odometer ledger", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                }
            }

            // Mileage & Tax Deduction Rates Option
            val currentYearRate = remember(ratePeriods) {
                ratePeriods.firstOrNull { it.year == 2026 && it.category == com.example.data.model.TripCategory.BUSINESS }
                    ?: ratePeriods.firstOrNull { it.category == com.example.data.model.TripCategory.BUSINESS }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenRates)
                    .testTag("manage_rates_row")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PriceChange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Mileage & Tax Rates", fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val rateSubtitle = if (currentYearRate != null) {
                                "${currentYearRate.year} Business: ${currentYearRate.rateCents}¢ ($currencySymbol${"%.3f".format(currentYearRate.rateCents / 100.0)}/$distanceUnit) • ${ratePeriods.size} periods"
                            } else {
                                "IRS 2023–2027 statutory & custom rates"
                            }
                            Text(rateSubtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                }
            }

            // Offline Backup & Disaster Recovery Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Data Protection & Backups", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Auto Backup Toggle Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Automatic Logbook Backup",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (autoBackupEnabled)
                                    "Active • Real-time snapshots on every drive & edit"
                                else
                                    "Paused • Manual backups only",
                                fontSize = 11.5.sp,
                                color = if (autoBackupEnabled) DarkGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = autoBackupEnabled,
                            onCheckedChange = { onToggleAutoBackup(it) },
                            modifier = Modifier.testTag("auto_backup_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Last backup: $lastBackupFormatted\nSQLite Write-Ahead Logging (WAL) is active for atomic durability. Never lose a logged drive during sudden restarts or crashes.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onExportBackup,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Export Backup", fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = onImportBackup,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Restore File", fontSize = 13.sp)
                        }
                    }

                    if (lastBackupTime > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showRestoreAutoConfirmDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("restore_auto_backup_btn")
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restore From Latest Auto-Backup Snapshot", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Competitor Comparison Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCompetitorMatrix = !showCompetitorMatrix },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = TertiaryAmber)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Compare MileDiary vs Top Apps", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Icon(
                            imageVector = if (showCompetitorMatrix) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = showCompetitorMatrix) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                "See how MileDiary outperforms expensive competitors like MileIQ, Everlance, and TripLog:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            CompetitorFeatureRow(
                                title = "Battery Consumption",
                                milediary = "0% battery drain (No GPS draining)",
                                competitors = "15% - 25% daily battery drain"
                            )
                            HorizontalDivider()

                            CompetitorFeatureRow(
                                title = "Location Privacy",
                                milediary = "100% on-device offline storage",
                                competitors = "Uploaded to remote corporate clouds"
                            )
                            HorizontalDivider()

                            CompetitorFeatureRow(
                                title = "Price & Subscription",
                                milediary = "$39.99/yr or $79.99 Lifetime",
                                competitors = "$60 to $140 every year forever"
                            )
                            HorizontalDivider()

                            CompetitorFeatureRow(
                                title = "IRS Pub 463 & Form 2106",
                                milediary = "Built-in with digital taxpayer signature",
                                competitors = "Basic CSV or costly enterprise tier"
                            )
                        }
                    }
                }
            }

            // Realistic Multi-Year Sample Data & Diagnostics
            Text("Realistic Data & Diagnostics", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("audit_simulation_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text("Full Multi-Year Daily Drives", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("2024, 2025, 2026, 2027 Realistic Data", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Populates 120+ realistic daily drives with continuous odometer continuity, DoorDash/Uber shifts, medical, charity, and client consulting trips to verify tax calculations and PDF exports.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onLoadSampleData,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("load_sample_data_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkGreen)
                        ) {
                            Text("Load 2024–2027 Drives", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showClearConfirmDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clear_data_button"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear All", fontSize = 12.5.sp)
                        }
                    }
                }
            }

            // FAQ & Legal Compliance Guide
            Text("Tax Compliance FAQ", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            val faqs = listOf(
                "What is IRS Publication 463?" to "IRS Pub 463 governs deductible travel, gift, and transportation expenses. It mandates that drivers maintain a timely (contemporaneous) record showing the date, destination, business purpose, and mileage for each trip.",
                "Why is manual logging better than automatic GPS?" to "Automatic GPS mileage trackers constantly run location services in the background, consuming 15-25% of your phone battery daily and uploading your exact movements to third-party servers. MileDiary gives you 1-tap logging with 0% battery drain and 100% privacy.",
                "Can I deduct standard daily commutes?" to "No. Under IRS IRC §262, daily commuting travel between your personal residence and your main or regular place of work is personal and nondeductible. MileDiary automatically flags commutes as personal.",
                "What are the 2025 and 2026 IRS standard mileage rates?" to "For 2025, the rate is 70¢/mile for business, 21¢ for medical, and 14¢ for charity. For 2026, the statutory rate is 72.5¢/mile (H1) and 76.0¢/mile (H2). MileDiary automatically applies these statutory rates based on the trip date."
            )

            faqs.forEachIndexed { index, (question, answer) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            expandedFaqIndex = if (expandedFaqIndex == index) null else index
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.HelpOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(question, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                            Icon(
                                imageVector = if (expandedFaqIndex == index) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = Color.Gray
                            )
                        }

                        AnimatedVisibility(visible = expandedFaqIndex == index) {
                            Text(
                                text = answer,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 10.dp, start = 26.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Confirmation dialog for clearing data
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Clear All Records?") },
            text = { Text("Are you sure you want to delete all trips, odometer boundaries, and templates? This action cannot be undone unless you have exported a backup.") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllData()
                        showClearConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Confirmation dialog for restoring auto-backup
    if (showRestoreAutoConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreAutoConfirmDialog = false },
            title = { Text("Restore Auto-Backup Snapshot?", fontWeight = FontWeight.Bold) },
            text = { Text("This will restore your complete logbook state from the most recent automatic background snapshot ($lastBackupFormatted). Any unsaved changes made since then will be replaced.") },
            confirmButton = {
                Button(
                    onClick = {
                        showRestoreAutoConfirmDialog = false
                        onRestoreAutoBackup()
                    }
                ) {
                    Text("Restore Snapshot")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreAutoConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CompetitorFeatureRow(
    title: String,
    milediary: String,
    competitors: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = DarkGreen,
                modifier = Modifier
                    .size(16.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "MileDiary: $milediary",
                fontSize = 11.5.sp,
                color = DarkGreen,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "• Competitors: $competitors",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
