package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkGreen
import com.example.ui.theme.TertiaryAmber

enum class PlanTier(
    val title: String,
    val price: String,
    val billingDetail: String,
    val badge: String? = null
) {
    ANNUAL("Annual Pro", "$39.99 / yr", "$3.33/mo • 3-Day Free Trial", "BEST VALUE (SAVE 35%)"),
    LIFETIME("Lifetime Pass", "$79.99", "One-time payment • Never pay again", "MOST POPULAR"),
    MONTHLY("Monthly Pro", "$4.99 / mo", "Billed monthly • Cancel anytime", null)
}

@Composable
fun PaywallDialog(
    onUnlockPro: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedPlanIndex by remember { mutableIntStateOf(0) } // Default to Annual
    val currentPlan = PlanTier.values()[selectedPlanIndex]

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(TertiaryAmber, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("MileDiary Pro", fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("Tax Deduction & Logbook Supercharged", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Plan Options
                PlanTier.values().forEachIndexed { index, plan ->
                    val isSelected = selectedPlanIndex == index
                    val borderColor by animateColorAsState(
                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        label = "plan_border"
                    )
                    val bgColor by animateColorAsState(
                        if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface,
                        label = "plan_bg"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
                            .background(bgColor)
                            .clickable { selectedPlanIndex = index }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedPlanIndex = index }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = plan.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (plan.badge != null) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(DarkGreen, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(plan.badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                            }
                                        }
                                    }
                                    Text(
                                        text = plan.billingDetail,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Text(
                                text = plan.price,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Competitor Comparison Matrix
                Text("How MileDiary Beats Other Apps", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ComparisonRow(
                            metric = "Battery Drain",
                            ourValue = "0% (Zero background GPS)",
                            otherValue = "Up to 25% daily drain (MileIQ/Everlance)"
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        ComparisonRow(
                            metric = "Location Privacy",
                            ourValue = "100% Offline & On-Device",
                            otherValue = "Server-tracked & cloud stored"
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        ComparisonRow(
                            metric = "Cost per Year",
                            ourValue = "$39.99/yr or $79.99 once",
                            otherValue = "$60 to $140 / year recurring"
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        ComparisonRow(
                            metric = "Audit Certification",
                            ourValue = "IRS Pub 463 + Digital Sign",
                            otherValue = "Generic summaries or paid add-on"
                        )
                    }
                }

                // Features Checklist
                Text("Everything Included in Pro:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                val benefits = listOf(
                    "IRS Form 2106 / Pub 463 PDF exports with digital certification",
                    "Unlimited vehicle fleet & annual odometer boundaries",
                    "Multi-year archives (2024, 2025, 2026, 2027+)",
                    "Direct native printing & one-tap accountant email sharing",
                    "Multi-currency support ($, €, £, CA$, AU$, ₹, ¥) & km/mi",
                    "Automated JSON backup & restore data-loss proofing",
                    "Family Library sharing enabled across your Google devices"
                )

                benefits.forEach { benefit ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = DarkGreen,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = benefit,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onUnlockPro()
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("paywall_unlock_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.LockOpen, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                val ctaText = if (currentPlan == PlanTier.ANNUAL) "Start 3-Day Free Trial" else "Unlock Pro (${currentPlan.price})"
                Text(ctaText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        },
        dismissButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                TextButton(
                    onClick = {
                        onUnlockPro()
                        onDismiss()
                    }
                ) {
                    Text("Restore Existing Purchase", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    )
}

@Composable
private fun ComparisonRow(
    metric: String,
    ourValue: String,
    otherValue: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(metric, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("★ MileDiary: $ourValue", fontSize = 10.5.sp, color = DarkGreen, fontWeight = FontWeight.SemiBold)
        }
        Text("• Competitors: $otherValue", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
