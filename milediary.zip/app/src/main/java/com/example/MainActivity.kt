package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.OdoBoundary
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.Vehicle
import com.example.ui.screens.AddEditTripSheet
import com.example.ui.screens.CsvImportDialog
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PaywallDialog
import com.example.ui.screens.RatePeriodsDialog
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.TemplatesDialog
import com.example.ui.screens.TripsScreen
import com.example.ui.screens.VehiclesDialog
import com.example.ui.theme.MileDiaryTheme
import com.example.ui.viewmodel.MileDiaryViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MileDiaryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MileDiaryTheme {
                MileDiaryApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MileDiaryApp(viewModel: MileDiaryViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // State collections from ViewModel
    val trips by viewModel.filteredTrips.collectAsStateWithLifecycle()
    val allTrips by viewModel.allTripsRaw.collectAsStateWithLifecycle()
    val vehicles by viewModel.vehicles.collectAsStateWithLifecycle()
    val templates by viewModel.templates.collectAsStateWithLifecycle()
    val ratePeriods by viewModel.ratePeriods.collectAsStateWithLifecycle()
    val odoBoundaries by viewModel.odoBoundaries.collectAsStateWithLifecycle()
    val stats by viewModel.currentStats.collectAsStateWithLifecycle()
    val yearStats by viewModel.yearStats.collectAsStateWithLifecycle()

    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val onlyShifts by viewModel.filterOnlyShifts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val businessName by viewModel.businessName.collectAsStateWithLifecycle()
    val taxId by viewModel.taxId.collectAsStateWithLifecycle()
    val signerName by viewModel.signerName.collectAsStateWithLifecycle()
    val homeAddress by viewModel.homeAddress.collectAsStateWithLifecycle()
    val officeAddress by viewModel.officeAddress.collectAsStateWithLifecycle()
    val taxBracket by viewModel.taxBracket.collectAsStateWithLifecycle()
    val currencySymbol by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val distanceUnit by viewModel.distanceUnit.collectAsStateWithLifecycle()
    val isProStr by viewModel.isPro.collectAsStateWithLifecycle()
    val isPro = isProStr.toBoolean()
    val lastBackupTime by viewModel.lastBackupTime.collectAsStateWithLifecycle()
    val autoBackupEnabled by viewModel.autoBackupEnabled.collectAsStateWithLifecycle()
    val hasSeenOnboardingStr by viewModel.hasSeenOnboarding.collectAsStateWithLifecycle()
    val hasSeenOnboarding = hasSeenOnboardingStr.toBoolean()

    val context = LocalContext.current

    val backupRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        val result = viewModel.restoreFullBackup(stream)
                        snackbarHostState.showSnackbar(result.message)
                    }
                }.onFailure { err ->
                    snackbarHostState.showSnackbar("Restore failed: ${err.localizedMessage}")
                }
            }
        }
    }

    // Navigation and Dialog States (persisting across rotation)
    var currentTab by rememberSaveable { mutableIntStateOf(0) } // 0: Trips, 1: Stats, 2: Reports, 3: Settings
    var showAddTripSheet by rememberSaveable { mutableStateOf(false) }
    var editingTripId by rememberSaveable { mutableStateOf<Long?>(null) }
    val tripToEdit = remember(allTrips, editingTripId) { allTrips.find { it.id == editingTripId } }
    var prefillTemplate by remember { mutableStateOf<Template?>(null) }

    var showTemplatesDialog by rememberSaveable { mutableStateOf(false) }
    var showVehiclesDialog by rememberSaveable { mutableStateOf(false) }
    var showRatesDialog by rememberSaveable { mutableStateOf(false) }
    var showPaywallDialog by rememberSaveable { mutableStateOf(false) }
    var showCsvImportDialog by rememberSaveable { mutableStateOf(false) }

    // Intercept back presses to dismiss sheets/dialogs or return to Home tab instead of quitting app
    BackHandler(
        enabled = showAddTripSheet || editingTripId != null || showTemplatesDialog ||
                showVehiclesDialog || showRatesDialog || showPaywallDialog || showCsvImportDialog || currentTab != 0
    ) {
        when {
            showAddTripSheet || editingTripId != null -> {
                showAddTripSheet = false
                editingTripId = null
                prefillTemplate = null
            }
            showTemplatesDialog -> showTemplatesDialog = false
            showVehiclesDialog -> showVehiclesDialog = false
            showRatesDialog -> showRatesDialog = false
            showPaywallDialog -> showPaywallDialog = false
            showCsvImportDialog -> showCsvImportDialog = false
            currentTab != 0 -> currentTab = 0
        }
    }

    // Collect UI Events (e.g. snackbar)
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collectLatest { msg ->
            if (msg == "Trip deleted") {
                val res = snackbarHostState.showSnackbar(
                    message = "Trip deleted",
                    actionLabel = "Undo",
                    duration = SnackbarDuration.Short
                )
                if (res == SnackbarResult.ActionPerformed) {
                    viewModel.undoDeleteTrip()
                }
            } else {
                snackbarHostState.showSnackbar(
                    message = msg,
                    duration = SnackbarDuration.Short
                )
            }
        }
    }

    // Rank recent locations for autocomplete suggestions
    val recentLocations = remember(allTrips) {
        val freq = mutableMapOf<String, Int>()
        allTrips.forEach {
            freq[it.fromLoc] = (freq[it.fromLoc] ?: 0) + 1
            freq[it.toLoc] = (freq[it.toLoc] ?: 0) + 1
        }
        freq.entries.sortedByDescending { it.value }.map { it.key }.filter { it.isNotBlank() }
    }

    if (!hasSeenOnboarding) {
        OnboardingScreen(
            onCompleteOnboarding = { carName, jan1Odo, taxpayer ->
                viewModel.completeOnboarding(carName, jan1Odo, taxpayer, selectedYear)
            }
        )
    } else {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "Drives") },
                        label = { Text("Drives", fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_drives")
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.BarChart, contentDescription = "Stats") },
                        label = { Text("Stats", fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_stats")
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = { Icon(Icons.Default.Description, contentDescription = "Reports") },
                        label = { Text("Reports", fontWeight = if (currentTab == 2) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_reports")
                    )
                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { currentTab = 3 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontWeight = if (currentTab == 3) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    0 -> TripsScreen(
                        trips = trips,
                        allTrips = allTrips,
                        stats = stats,
                        ratePeriods = ratePeriods,
                        vehicles = vehicles,
                        selectedYear = selectedYear,
                        selectedMonth = selectedMonth,
                        selectedCategory = selectedCategory,
                        onlyShifts = onlyShifts,
                        searchQuery = searchQuery,
                        lastBackupTime = lastBackupTime,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        snackbarHostState = snackbarHostState,
                        onSelectYear = { viewModel.selectYear(it) },
                        onSelectMonth = { viewModel.selectMonth(it) },
                        onSelectCategory = { viewModel.setCategoryFilter(it) },
                        onToggleShifts = { viewModel.toggleOnlyShifts() },
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        onOpenTemplates = { showTemplatesDialog = true },
                        onOpenBackup = { viewModel.markBackupCompleted() },
                        onAddTrip = {
                            editingTripId = null
                            prefillTemplate = null
                            showAddTripSheet = true
                        },
                        onEditTrip = { trip ->
                            editingTripId = trip.id
                            prefillTemplate = null
                            showAddTripSheet = true
                        },
                        onDuplicateTrip = { trip ->
                            editingTripId = null
                            prefillTemplate = null
                            viewModel.saveTrip(
                                trip.copy(
                                    id = 0L,
                                    createdAt = System.currentTimeMillis(),
                                    updatedAt = System.currentTimeMillis(),
                                    edited = false
                                )
                            )
                        },
                        onSaveAsTemplate = { trip ->
                            viewModel.saveTemplate(
                                Template(
                                    name = "${trip.fromLoc} to ${trip.toLoc}",
                                    fromLoc = trip.fromLoc,
                                    toLoc = trip.toLoc,
                                    miles = trip.miles,
                                    purpose = trip.purpose,
                                    category = trip.category
                                )
                            )
                        },
                        onDeleteTrip = { trip ->
                            viewModel.deleteTrip(trip)
                        }
                    )
                    1 -> StatsScreen(
                        trips = allTrips,
                        yearStats = yearStats,
                        ratePeriods = ratePeriods,
                        selectedYear = selectedYear,
                        taxBracketPercent = taxBracket.toDoubleOrNull() ?: 25.0,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        onSelectYear = { viewModel.selectYear(it) }
                    )
                    2 -> ReportScreen(
                        trips = allTrips,
                        vehicles = vehicles,
                        ratePeriods = ratePeriods,
                        selectedYear = selectedYear,
                        taxpayerName = userName,
                        businessName = businessName,
                        taxId = taxId,
                        signerName = signerName,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        isPro = isPro,
                        onSelectYear = { viewModel.selectYear(it) },
                        onUpdateSignerName = { viewModel.updateSetting("signer_name", it) },
                        onGeneratePdf = { yr, vId -> viewModel.generatePdfReport(yr, vId) },
                        onGenerateCsv = { yr, vId -> viewModel.generateCsvReport(yr, vId) },
                        onOpenPaywall = { showPaywallDialog = true },
                        onOpenImport = { showCsvImportDialog = true }
                    )
                    3 -> SettingsScreen(
                        taxpayerName = userName,
                        businessName = businessName,
                        taxId = taxId,
                        signerName = signerName,
                        homeAddress = homeAddress,
                        officeAddress = officeAddress,
                        taxBracket = taxBracket,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        isPro = isPro,
                        lastBackupTime = lastBackupTime,
                        autoBackupEnabled = autoBackupEnabled,
                        onUpdateName = { viewModel.updateSetting("user_name", it) },
                        onUpdateBusinessName = { viewModel.updateSetting("business_name", it) },
                        onUpdateTaxId = { viewModel.updateSetting("tax_id", it) },
                        onUpdateSignerName = { viewModel.updateSetting("signer_name", it) },
                        onUpdateHomeAddress = { viewModel.updateSetting("home_address", it) },
                        onUpdateOfficeAddress = { viewModel.updateSetting("office_address", it) },
                        onUpdateTaxBracket = { viewModel.updateSetting("tax_bracket", it) },
                        onUpdateCurrencySymbol = { viewModel.updateSetting("currency_symbol", it) },
                        onUpdateDistanceUnit = { viewModel.updateSetting("distance_unit", it) },
                        onToggleAutoBackup = { viewModel.toggleAutoBackup(it) },
                        onRestoreAutoBackup = { viewModel.restoreFromLatestAutoBackup() },
                        ratePeriods = ratePeriods,
                        onOpenVehicles = { showVehiclesDialog = true },
                        onOpenRates = { showRatesDialog = true },
                        onOpenPaywall = { showPaywallDialog = true },
                        onExportBackup = {
                            coroutineScope.launch {
                                val file = viewModel.exportFullBackup()
                                if (file != null && file.exists()) {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/json"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_SUBJECT, "MileDiary Backup ${file.name}")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Save or Share Backup"))
                                }
                            }
                        },
                        onImportBackup = {
                            backupRestoreLauncher.launch("*/*")
                        },
                        onLoadSampleData = { viewModel.loadSampleData() },
                        onClearAllData = { viewModel.clearAllData() }
                    )
                }

                // Add / Edit Trip Sheet
                if (showAddTripSheet) {
                    AddEditTripSheet(
                        initialTrip = tripToEdit,
                        prefilledFrom = prefillTemplate?.fromLoc,
                        prefilledTo = prefillTemplate?.toLoc,
                        prefilledMiles = prefillTemplate?.miles,
                        prefilledCategory = prefillTemplate?.category,
                        prefilledPurpose = prefillTemplate?.purpose,
                        vehicles = vehicles,
                        ratePeriods = ratePeriods,
                        recentLocations = recentLocations,
                        homeAddress = homeAddress,
                        officeAddress = officeAddress,
                        onGetLastOdo = { vId -> viewModel.getLastOdoForVehicle(vId) },
                        onCheckDuplicate = { vId, d, f, t -> viewModel.checkDuplicate(vId, d, f, t) },
                        onSaveTrip = { trip ->
                            viewModel.saveTrip(trip) {
                                showAddTripSheet = false
                                editingTripId = null
                                prefillTemplate = null
                            }
                        },
                        onDismiss = {
                            showAddTripSheet = false
                            editingTripId = null
                            prefillTemplate = null
                        }
                    )
                }

                // Templates Dialog
                if (showTemplatesDialog) {
                    TemplatesDialog(
                        templates = templates,
                        onSelectTemplate = { t ->
                            prefillTemplate = t
                            editingTripId = null
                            showTemplatesDialog = false
                            showAddTripSheet = true
                            viewModel.recordTemplateUsage(t.id)
                        },
                        onSaveTemplate = { t -> viewModel.saveTemplate(t) },
                        onDeleteTemplate = { t -> viewModel.deleteTemplate(t) },
                        onDismiss = { showTemplatesDialog = false }
                    )
                }

                // Vehicles Dialog
                if (showVehiclesDialog) {
                    VehiclesDialog(
                        vehicles = vehicles,
                        currentYear = selectedYear,
                        odoBoundaries = odoBoundaries,
                        trips = allTrips,
                        isPro = isPro,
                        onOpenPaywall = { showPaywallDialog = true },
                        onSaveVehicle = { v -> viewModel.saveVehicle(v) },
                        onSetPrimary = { id -> viewModel.setPrimaryVehicle(id) },
                        onDeleteVehicle = { v, reassignId -> viewModel.deleteVehicle(v, reassignId) },
                        onSaveOdoBoundary = { b -> viewModel.saveOdoBoundary(b) },
                        onDismiss = { showVehiclesDialog = false }
                    )
                }

                // Rate Periods Dialog
                if (showRatesDialog) {
                    RatePeriodsDialog(
                        ratePeriods = ratePeriods,
                        currencySymbol = currencySymbol,
                        distanceUnit = distanceUnit,
                        onUpdateRatePeriod = { r -> viewModel.updateRatePeriod(r) },
                        onAddRatePeriod = { r -> viewModel.addRatePeriod(r) },
                        onDeleteRatePeriod = { id -> viewModel.deleteRatePeriod(id) },
                        onResetRatesToDefault = { viewModel.resetRatesToDefault() },
                        onDismiss = { showRatesDialog = false }
                    )
                }

                // Paywall Dialog
                if (showPaywallDialog) {
                    PaywallDialog(
                        onUnlockPro = { viewModel.unlockPro() },
                        onDismiss = { showPaywallDialog = false }
                    )
                }

                // CSV Import Dialog
                if (showCsvImportDialog) {
                    CsvImportDialog(
                        vehicles = vehicles,
                        onImportCsvStream = { stream, vId -> viewModel.importCsvStream(stream, vId) },
                        onDismiss = { showCsvImportDialog = false }
                    )
                }
            }
        }
    }
}
