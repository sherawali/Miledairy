package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "templates")
data class Template(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val vehicleId: Long? = null,
    val fromLoc: String,
    val toLoc: String,
    val miles: Double,
    val category: TripCategory = TripCategory.BUSINESS,
    val purpose: String,
    val platform: String? = null,
    val tag: String? = null,
    val useCount: Int = 1,
    val lastUsed: Long = System.currentTimeMillis()
)
