package com.example.data.model

enum class TripCategory(val displayName: String, val irsDeductible: Boolean) {
    BUSINESS("Business", true),
    PERSONAL("Personal", false),
    CHARITY("Charity", true),
    MEDICAL("Medical", true);

    companion object {
        fun fromString(value: String): TripCategory {
            return try {
                valueOf(value.uppercase())
            } catch (e: Exception) {
                BUSINESS
            }
        }
    }
}
