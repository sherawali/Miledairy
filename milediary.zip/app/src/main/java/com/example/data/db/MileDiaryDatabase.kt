package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AppSettingEntity
import com.example.data.model.OdoBoundary
import com.example.data.model.RatePeriod
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Vehicle::class,
        OdoBoundary::class,
        Trip::class,
        Template::class,
        RatePeriod::class,
        AppSettingEntity::class
    ],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class MileDiaryDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun odoBoundaryDao(): OdoBoundaryDao
    abstract fun tripDao(): TripDao
    abstract fun templateDao(): TemplateDao
    abstract fun ratePeriodDao(): RatePeriodDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        @Volatile
        private var INSTANCE: MileDiaryDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE trips ADD COLUMN parkingTolls REAL DEFAULT NULL")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE trips ADD COLUMN receiptPath TEXT DEFAULT NULL")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): MileDiaryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MileDiaryDatabase::class.java,
                    "milediary.db"
                )
                    .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
                    .enableMultiInstanceInvalidation()
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Pre-populate verified IRS Standard Mileage Rates on background thread
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialRates(database.ratePeriodDao())
                        populateInitialVehicle(database.vehicleDao())
                    }
                }
            }

            private suspend fun populateInitialRates(ratePeriodDao: RatePeriodDao) {
                val initialRates = listOf(
                    // 2026 Rates (verified with mid-year hike)
                    RatePeriod(
                        year = 2026,
                        category = TripCategory.BUSINESS,
                        startDate = "2026-01-01",
                        endDate = "2026-06-30",
                        rateCents = 72.5,
                        label = "IRS 2026 H1 Rate"
                    ),
                    RatePeriod(
                        year = 2026,
                        category = TripCategory.BUSINESS,
                        startDate = "2026-07-01",
                        endDate = "2026-12-31",
                        rateCents = 76.0,
                        label = "IRS 2026 H2 Rate"
                    ),
                    RatePeriod(
                        year = 2026,
                        category = TripCategory.CHARITY,
                        startDate = "2026-01-01",
                        endDate = "2026-12-31",
                        rateCents = 14.0,
                        label = "IRS Charity Standard (Statutory)"
                    ),
                    RatePeriod(
                        year = 2026,
                        category = TripCategory.MEDICAL,
                        startDate = "2026-01-01",
                        endDate = "2026-06-30",
                        rateCents = 20.5,
                        label = "IRS 2026 H1 Medical"
                    ),
                    RatePeriod(
                        year = 2026,
                        category = TripCategory.MEDICAL,
                        startDate = "2026-07-01",
                        endDate = "2026-12-31",
                        rateCents = 23.5,
                        label = "IRS 2026 H2 Medical"
                    ),

                    // 2025 Rates
                    RatePeriod(
                        year = 2025,
                        category = TripCategory.BUSINESS,
                        startDate = "2025-01-01",
                        endDate = "2025-12-31",
                        rateCents = 70.0,
                        label = "IRS 2025 Standard Rate"
                    ),
                    RatePeriod(
                        year = 2025,
                        category = TripCategory.CHARITY,
                        startDate = "2025-01-01",
                        endDate = "2025-12-31",
                        rateCents = 14.0,
                        label = "IRS Charity Standard (Statutory)"
                    ),
                    RatePeriod(
                        year = 2025,
                        category = TripCategory.MEDICAL,
                        startDate = "2025-01-01",
                        endDate = "2025-12-31",
                        rateCents = 21.0,
                        label = "IRS 2025 Medical Rate"
                    )
                )
                ratePeriodDao.insertRatePeriods(initialRates)
            }

            private suspend fun populateInitialVehicle(vehicleDao: VehicleDao) {
                if (vehicleDao.getVehicleCount() == 0) {
                    vehicleDao.insertVehicle(
                        Vehicle(
                            name = "Primary Car",
                            make = "Toyota",
                            model = "Corolla",
                            year = "2022",
                            isPrimary = true
                        )
                    )
                }
            }
        }
    }
}
