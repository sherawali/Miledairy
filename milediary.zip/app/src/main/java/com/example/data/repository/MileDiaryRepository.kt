package com.example.data.repository

import com.example.data.db.AppSettingDao
import com.example.data.db.OdoBoundaryDao
import com.example.data.db.RatePeriodDao
import com.example.data.db.TemplateDao
import com.example.data.db.TripDao
import com.example.data.db.VehicleDao
import com.example.data.model.AppSettingEntity
import com.example.data.model.OdoBoundary
import com.example.data.model.RatePeriod
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MileDiaryRepository(
    private val vehicleDao: VehicleDao,
    private val odoBoundaryDao: OdoBoundaryDao,
    private val tripDao: TripDao,
    private val templateDao: TemplateDao,
    private val ratePeriodDao: RatePeriodDao,
    private val appSettingDao: AppSettingDao
) {
    // --- Vehicles ---
    val allVehicles: Flow<List<Vehicle>> = vehicleDao.getAllVehicles()

    suspend fun getAllVehiclesSync(): List<Vehicle> = vehicleDao.getAllVehiclesSync()

    suspend fun getVehicleCount(): Int = vehicleDao.getVehicleCount()

    suspend fun insertVehicle(vehicle: Vehicle): Long = vehicleDao.insertVehicle(vehicle)

    suspend fun updateVehicle(vehicle: Vehicle) = vehicleDao.updateVehicle(vehicle)

    suspend fun deleteVehicle(vehicle: Vehicle) {
        odoBoundaryDao.deleteForVehicle(vehicle.id)
        vehicleDao.deleteVehicle(vehicle)
    }

    suspend fun setPrimaryVehicle(id: Long) {
        vehicleDao.clearPrimaryFlags()
        vehicleDao.setPrimaryVehicle(id)
    }

    suspend fun reassignVehicleTrips(oldVehicleId: Long, newVehicleId: Long) {
        tripDao.reassignVehicle(oldVehicleId, newVehicleId)
    }

    // --- Odometer Boundaries ---
    val allOdoBoundaries: Flow<List<OdoBoundary>> = odoBoundaryDao.getAllBoundaries()

    fun getOdoBoundary(vehicleId: Long, year: Int): Flow<OdoBoundary?> =
        odoBoundaryDao.getBoundary(vehicleId, year)

    fun getOdoBoundariesForYear(year: Int): Flow<List<OdoBoundary>> =
        odoBoundaryDao.getBoundariesForYear(year)

    suspend fun saveOdoBoundary(boundary: OdoBoundary): Long =
        odoBoundaryDao.insertOrUpdate(boundary)

    suspend fun getAllBoundariesSync(): List<OdoBoundary> = odoBoundaryDao.getAllBoundariesSync()

    suspend fun deleteAllBoundaries() = odoBoundaryDao.deleteAllBoundaries()

    // --- Trips ---
    val allTrips: Flow<List<Trip>> = tripDao.getAllTrips()

    fun getTripsForYear(year: Int): Flow<List<Trip>> =
        tripDao.getTripsForYear(year.toString())

    fun getTripsForMonth(yearMonth: String): Flow<List<Trip>> =
        tripDao.getTripsForMonth(yearMonth)

    suspend fun getTripById(id: Long): Trip? = tripDao.getTripById(id)

    suspend fun getLastTripWithOdo(vehicleId: Long): Trip? =
        tripDao.getLastTripWithOdo(vehicleId)

    suspend fun getLastTripForVehicle(vehicleId: Long): Trip? =
        tripDao.getLastTripForVehicle(vehicleId)

    suspend fun insertTrip(trip: Trip): Long = tripDao.insertTrip(trip)

    suspend fun insertTrips(trips: List<Trip>): List<Long> = tripDao.insertTrips(trips)

    suspend fun updateTrip(trip: Trip) = tripDao.updateTrip(trip)

    suspend fun deleteTrip(trip: Trip) = tripDao.deleteTrip(trip)

    suspend fun deleteTripById(id: Long) = tripDao.deleteTripById(id)

    suspend fun getTripCountForVehicle(vehicleId: Long): Int =
        tripDao.getTripCountForVehicle(vehicleId)

    suspend fun getAllLocations(): List<String> = tripDao.getAllLocations()

    suspend fun getTopPurposes(): List<String> = tripDao.getTopPurposes()

    suspend fun findRecentDuplicate(
        vehicleId: Long,
        date: String,
        fromLoc: String,
        toLoc: String
    ): Trip? = tripDao.findRecentDuplicate(vehicleId, date, fromLoc, toLoc, System.currentTimeMillis())

    suspend fun getAllMiles(): List<Double> = tripDao.getAllMilesList()

    suspend fun getAllTripsSync(): List<Trip> = tripDao.getAllTripsSync()

    suspend fun deleteAllTrips() = tripDao.deleteAllTrips()

    // --- Templates ---
    val allTemplates: Flow<List<Template>> = templateDao.getAllTemplates()

    suspend fun insertTemplate(template: Template): Long = templateDao.insertTemplate(template)

    suspend fun getAllTemplatesSync(): List<Template> = templateDao.getAllTemplatesSync()

    suspend fun updateTemplate(template: Template) = templateDao.updateTemplate(template)

    suspend fun deleteTemplate(template: Template) = templateDao.deleteTemplate(template)

    suspend fun deleteAllTemplates() = templateDao.deleteAllTemplates()

    suspend fun recordTemplateUse(id: Long) = templateDao.recordUsage(id)

    // --- Rate Periods ---
    val allRatePeriods: Flow<List<RatePeriod>> = ratePeriodDao.getAllRatePeriods()

    fun getRatePeriodsForYear(year: Int): Flow<List<RatePeriod>> =
        ratePeriodDao.getRatePeriodsForYear(year)

    suspend fun getRatePeriodsForYearSync(year: Int): List<RatePeriod> =
        ratePeriodDao.getRatePeriodsForYearSync(year)

    suspend fun getRateForDate(year: Int, category: TripCategory, date: String): RatePeriod? =
        ratePeriodDao.getRateForDate(year, category, date)

    suspend fun insertRatePeriod(ratePeriod: RatePeriod): Long =
        ratePeriodDao.insertRatePeriod(ratePeriod)

    suspend fun updateRatePeriod(ratePeriod: RatePeriod) =
        ratePeriodDao.updateRatePeriod(ratePeriod)

    suspend fun deleteRatePeriod(id: Long) =
        ratePeriodDao.deleteRatePeriod(id)

    suspend fun getAllRatePeriodsSync(): List<RatePeriod> =
        ratePeriodDao.getAllRatePeriodsSync()

    suspend fun getRatePeriodCount(): Int = ratePeriodDao.getRatePeriodCount()

    suspend fun resetRatesToDefault() {
        ratePeriodDao.deleteAllRatePeriods()
        populateDefaultRates()
    }

    suspend fun populateDefaultRates() {
        val initialRates = listOf(
            RatePeriod(
                year = 2026,
                category = TripCategory.BUSINESS,
                startDate = "2026-01-01",
                endDate = "2026-06-30",
                rateCents = 72.5,
                label = "IRS 2026 H1 Rate"
            ),
            RatePeriod(
                year = 2026,
                category = TripCategory.BUSINESS,
                startDate = "2026-07-01",
                endDate = "2026-12-31",
                rateCents = 76.0,
                label = "IRS 2026 H2 Rate"
            ),
            RatePeriod(
                year = 2026,
                category = TripCategory.CHARITY,
                startDate = "2026-01-01",
                endDate = "2026-12-31",
                rateCents = 14.0,
                label = "IRS Charity Standard (Statutory)"
            ),
            RatePeriod(
                year = 2026,
                category = TripCategory.MEDICAL,
                startDate = "2026-01-01",
                endDate = "2026-06-30",
                rateCents = 20.5,
                label = "IRS 2026 H1 Medical"
            ),
            RatePeriod(
                year = 2026,
                category = TripCategory.MEDICAL,
                startDate = "2026-07-01",
                endDate = "2026-12-31",
                rateCents = 23.5,
                label = "IRS 2026 H2 Medical"
            ),
            RatePeriod(
                year = 2025,
                category = TripCategory.BUSINESS,
                startDate = "2025-01-01",
                endDate = "2025-12-31",
                rateCents = 70.0,
                label = "IRS 2025 Standard Rate"
            ),
            RatePeriod(
                year = 2025,
                category = TripCategory.CHARITY,
                startDate = "2025-01-01",
                endDate = "2025-12-31",
                rateCents = 14.0,
                label = "IRS Charity Standard (Statutory)"
            ),
            RatePeriod(
                year = 2025,
                category = TripCategory.MEDICAL,
                startDate = "2025-01-01",
                endDate = "2025-12-31",
                rateCents = 21.0,
                label = "IRS 2025 Medical Rate"
            )
        )
        ratePeriodDao.insertRatePeriods(initialRates)
    }

    // --- Settings ---
    fun getSetting(key: String, defaultValue: String = ""): Flow<String> =
        appSettingDao.getSetting(key).map { it ?: defaultValue }

    suspend fun getSettingSync(key: String, defaultValue: String = ""): String =
        appSettingDao.getSettingSync(key) ?: defaultValue

    suspend fun setSetting(key: String, value: String) {
        appSettingDao.setSetting(AppSettingEntity(key, value))
    }

    suspend fun getAllSettingsSync(): List<AppSettingEntity> =
        appSettingDao.getAllSettingsSync()

    suspend fun isProUnlocked(): Boolean {
        return (appSettingDao.getSettingSync("pro_unlocked") ?: "false").toBoolean()
    }

    suspend fun setProUnlocked(unlocked: Boolean) {
        appSettingDao.setSetting(AppSettingEntity("pro_unlocked", unlocked.toString()))
    }
}
