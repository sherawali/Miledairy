package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.TripCategory

class Converters {
    @TypeConverter
    fun fromCategory(category: TripCategory): String {
        return category.name
    }

    @TypeConverter
    fun toCategory(value: String): TripCategory {
        return TripCategory.fromString(value)
    }
}
