package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.OdoBoundary
import kotlinx.coroutines.flow.Flow

@Dao
interface OdoBoundaryDao {
    @Query("SELECT * FROM odo_boundaries WHERE vehicleId = :vehicleId AND year = :year LIMIT 1")
    fun getBoundary(vehicleId: Long, year: Int): Flow<OdoBoundary?>

    @Query("SELECT * FROM odo_boundaries WHERE vehicleId = :vehicleId AND year = :year LIMIT 1")
    suspend fun getBoundarySync(vehicleId: Long, year: Int): OdoBoundary?

    @Query("SELECT * FROM odo_boundaries WHERE year = :year")
    fun getBoundariesForYear(year: Int): Flow<List<OdoBoundary>>

    @Query("SELECT * FROM odo_boundaries")
    fun getAllBoundaries(): Flow<List<OdoBoundary>>

    @Query("SELECT * FROM odo_boundaries")
    suspend fun getAllBoundariesSync(): List<OdoBoundary>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(boundary: OdoBoundary): Long

    @Query("DELETE FROM odo_boundaries WHERE vehicleId = :vehicleId")
    suspend fun deleteForVehicle(vehicleId: Long)

    @Query("DELETE FROM odo_boundaries")
    suspend fun deleteAllBoundaries()
}
