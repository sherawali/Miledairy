package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Trip
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY date DESC, createdAt DESC")
    fun getAllTrips(): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE date LIKE :yearPrefix || '%' ORDER BY date DESC, createdAt DESC")
    fun getTripsForYear(yearPrefix: String): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE date LIKE :yearMonthPrefix || '%' ORDER BY date DESC, createdAt DESC")
    fun getTripsForMonth(yearMonthPrefix: String): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE id = :id LIMIT 1")
    suspend fun getTripById(id: Long): Trip?

    @Query("SELECT * FROM trips WHERE vehicleId = :vehicleId AND odoEnd IS NOT NULL ORDER BY date DESC, createdAt DESC LIMIT 1")
    suspend fun getLastTripWithOdo(vehicleId: Long): Trip?

    @Query("SELECT * FROM trips WHERE vehicleId = :vehicleId ORDER BY date DESC, createdAt DESC LIMIT 1")
    suspend fun getLastTripForVehicle(vehicleId: Long): Trip?

    @Query("SELECT COUNT(*) FROM trips WHERE vehicleId = :vehicleId")
    suspend fun getTripCountForVehicle(vehicleId: Long): Int

    @Query("SELECT fromLoc FROM trips WHERE fromLoc != '' UNION SELECT toLoc FROM trips WHERE toLoc != ''")
    suspend fun getAllLocations(): List<String>

    @Query("SELECT purpose FROM trips WHERE purpose != '' GROUP BY purpose ORDER BY COUNT(*) DESC LIMIT 10")
    suspend fun getTopPurposes(): List<String>

    @Query("""
        SELECT * FROM trips 
        WHERE vehicleId = :vehicleId 
          AND date = :date 
          AND fromLoc = :fromLoc 
          AND toLoc = :toLoc 
          AND ABS(createdAt - :currentTime) < 1800000 
        LIMIT 1
    """)
    suspend fun findRecentDuplicate(
        vehicleId: Long,
        date: String,
        fromLoc: String,
        toLoc: String,
        currentTime: Long
    ): Trip?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: Trip): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrips(trips: List<Trip>): List<Long>

    @Update
    suspend fun updateTrip(trip: Trip)

    @Delete
    suspend fun deleteTrip(trip: Trip)

    @Query("DELETE FROM trips WHERE id = :id")
    suspend fun deleteTripById(id: Long)

    @Query("UPDATE trips SET vehicleId = :newVehicleId WHERE vehicleId = :oldVehicleId")
    suspend fun reassignVehicle(oldVehicleId: Long, newVehicleId: Long)

    @Query("SELECT miles FROM trips WHERE miles > 0 ORDER BY miles ASC")
    suspend fun getAllMilesList(): List<Double>

    @Query("SELECT * FROM trips")
    suspend fun getAllTripsSync(): List<Trip>

    @Query("DELETE FROM trips")
    suspend fun deleteAllTrips()
}
