package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Template
import kotlinx.coroutines.flow.Flow

@Dao
interface TemplateDao {
    @Query("SELECT * FROM templates ORDER BY useCount DESC, lastUsed DESC")
    fun getAllTemplates(): Flow<List<Template>>

    @Query("SELECT * FROM templates ORDER BY useCount DESC, lastUsed DESC")
    suspend fun getAllTemplatesSync(): List<Template>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: Template): Long

    @Update
    suspend fun updateTemplate(template: Template)

    @Delete
    suspend fun deleteTemplate(template: Template)

    @Query("UPDATE templates SET useCount = useCount + 1, lastUsed = :timestamp WHERE id = :id")
    suspend fun recordUsage(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT * FROM templates WHERE fromLoc = :fromLoc AND toLoc = :toLoc LIMIT 1")
    suspend fun findMatching(fromLoc: String, toLoc: String): Template?

    @Query("DELETE FROM templates")
    suspend fun deleteAllTemplates()
}
