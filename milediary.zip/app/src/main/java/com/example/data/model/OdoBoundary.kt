package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "odo_boundaries",
    indices = [Index(value = ["vehicleId", "year"], unique = true)]
)
data class OdoBoundary(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vehicleId: Long,
    val year: Int,
    val jan1Odo: Double? = null,
    val dec31Odo: Double? = null
)
