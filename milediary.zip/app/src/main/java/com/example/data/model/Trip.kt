package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "trips",
    indices = [
        Index(value = ["date"]),
        Index(value = ["vehicleId"]),
        Index(value = ["category"])
    ]
)
data class Trip(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vehicleId: Long,
    val date: String, // YYYY-MM-DD
    val endDate: String? = null,
    val fromLoc: String,
    val toLoc: String,
    val purpose: String,
    val category: TripCategory = TripCategory.BUSINESS,
    val isCommute: Boolean = false,
    val isShift: Boolean = false,
    val platform: String? = null,
    val tag: String? = null,
    val miles: Double,
    val odoStart: Double? = null,
    val odoEnd: Double? = null,
    val roundTrip: Boolean = false,
    val parkingTolls: Double? = null,
    val receiptPath: String? = null,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val edited: Boolean = false
)
