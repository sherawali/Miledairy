package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "rate_periods",
    indices = [Index(value = ["year", "category", "startDate"], unique = true)]
)
data class RatePeriod(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val year: Int,
    val category: TripCategory,
    val startDate: String, // YYYY-MM-DD
    val endDate: String,   // YYYY-MM-DD
    val rateCents: Double,  // e.g. 76.0 for 76¢/mi
    val label: String = ""
)
