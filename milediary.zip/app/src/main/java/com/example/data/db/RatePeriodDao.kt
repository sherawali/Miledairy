package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.RatePeriod
import com.example.data.model.TripCategory
import kotlinx.coroutines.flow.Flow

@Dao
interface RatePeriodDao {
    @Query("SELECT * FROM rate_periods ORDER BY year DESC, startDate ASC")
    fun getAllRatePeriods(): Flow<List<RatePeriod>>

    @Query("SELECT COUNT(*) FROM rate_periods")
    suspend fun getRatePeriodCount(): Int

    @Query("SELECT * FROM rate_periods WHERE year = :year ORDER BY startDate ASC")
    fun getRatePeriodsForYear(year: Int): Flow<List<RatePeriod>>

    @Query("SELECT * FROM rate_periods WHERE year = :year ORDER BY startDate ASC")
    suspend fun getRatePeriodsForYearSync(year: Int): List<RatePeriod>

    @Query("""
        SELECT * FROM rate_periods 
        WHERE year = :year 
          AND category = :category 
          AND startDate <= :date 
          AND endDate >= :date 
        LIMIT 1
    """)
    suspend fun getRateForDate(year: Int, category: TripCategory, date: String): RatePeriod?

    @Query("SELECT * FROM rate_periods")
    suspend fun getAllRatePeriodsSync(): List<RatePeriod>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRatePeriod(ratePeriod: RatePeriod): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRatePeriods(ratePeriods: List<RatePeriod>)

    @Update
    suspend fun updateRatePeriod(ratePeriod: RatePeriod)

    @Query("DELETE FROM rate_periods WHERE id = :id")
    suspend fun deleteRatePeriod(id: Long)

    @Query("DELETE FROM rate_periods")
    suspend fun deleteAllRatePeriods()
}
