package com.example.domain.sample

import com.example.data.model.OdoBoundary
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.data.repository.MileDiaryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SampleDataManager {

    suspend fun populateSampleData(repository: MileDiaryRepository) = withContext(Dispatchers.IO) {
        // 1. Setup Vehicles
        val existingVehicles = repository.getAllVehiclesSync()
        val v1Id: Long
        val v2Id: Long

        if (existingVehicles.isNotEmpty()) {
            val v1 = existingVehicles.first()
            val updatedV1 = v1.copy(
                name = "2024 Toyota RAV4 Hybrid",
                make = "Toyota",
                model = "RAV4 Hybrid",
                year = "2024",
                isPrimary = true
            )
            repository.updateVehicle(updatedV1)
            v1Id = v1.id

            if (existingVehicles.size > 1) {
                val v2 = existingVehicles[1]
                val updatedV2 = v2.copy(
                    name = "2023 Ford Transit Cargo",
                    make = "Ford",
                    model = "Transit 250",
                    year = "2023",
                    isPrimary = false
                )
                repository.updateVehicle(updatedV2)
                v2Id = v2.id
            } else {
                v2Id = repository.insertVehicle(
                    Vehicle(
                        name = "2023 Ford Transit Cargo",
                        make = "Ford",
                        model = "Transit 250",
                        year = "2023",
                        isPrimary = false
                    )
                )
            }
        } else {
            v1Id = repository.insertVehicle(
                Vehicle(
                    name = "2024 Toyota RAV4 Hybrid",
                    make = "Toyota",
                    model = "RAV4 Hybrid",
                    year = "2024",
                    isPrimary = true
                )
            )
            v2Id = repository.insertVehicle(
                Vehicle(
                    name = "2023 Ford Transit Cargo",
                    make = "Ford",
                    model = "Transit 250",
                    year = "2023",
                    isPrimary = false
                )
            )
        }

        // 2. Clear old demo data
        repository.deleteAllTrips()
        repository.deleteAllBoundaries()
        repository.deleteAllTemplates()

        // 3. Odometer Boundaries across all years (2024, 2025, 2026, 2027)
        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v1Id, year = 2024, jan1Odo = 12400.0, dec31Odo = 27850.0)
        )
        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v1Id, year = 2025, jan1Odo = 27850.0, dec31Odo = 44920.0)
        )
        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v1Id, year = 2026, jan1Odo = 44920.0, dec31Odo = 61500.0)
        )
        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v1Id, year = 2027, jan1Odo = 61500.0, dec31Odo = null)
        )

        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v2Id, year = 2025, jan1Odo = 10500.0, dec31Odo = 24800.0)
        )
        repository.saveOdoBoundary(
            OdoBoundary(vehicleId = v2Id, year = 2026, jan1Odo = 24800.0, dec31Odo = null)
        )

        // 4. Quick Entry Templates
        val templates = listOf(
            Template(
                name = "Client Site Visit (Apex)",
                fromLoc = "Main Office HQ",
                toLoc = "Apex Industrial Park",
                miles = 24.5,
                purpose = "Client Quarterly Project Review",
                category = TripCategory.BUSINESS,
                useCount = 38
            ),
            Template(
                name = "DoorDash Evening Rush",
                fromLoc = "Downtown Metro Hub",
                toLoc = "Westside Neighborhoods",
                miles = 42.0,
                purpose = "Dinner Delivery Shift",
                category = TripCategory.BUSINESS,
                useCount = 52
            ),
            Template(
                name = "Supply Depot & Warehouse",
                fromLoc = "Main Office HQ",
                toLoc = "Commercial Hardware Depot",
                miles = 16.5,
                purpose = "Job Equipment & Material Restock",
                category = TripCategory.BUSINESS,
                useCount = 19
            ),
            Template(
                name = "Airport VIP Transfer",
                fromLoc = "Airport Terminal 2",
                toLoc = "Hyatt Regency Downtown",
                miles = 28.0,
                purpose = "Executive Client Airport Pickup",
                category = TripCategory.BUSINESS,
                useCount = 14
            ),
            Template(
                name = "Daily Office Commute",
                fromLoc = "Home Residence",
                toLoc = "Main Office HQ",
                miles = 13.5,
                purpose = "Regular Daily Commute",
                category = TripCategory.PERSONAL,
                useCount = 85
            )
        )
        templates.forEach { repository.insertTemplate(it) }

        // 5. Generate daily contemporaneous drives across 2024, 2025, 2026, 2027
        val tripsToInsert = mutableListOf<Trip>()

        // Helper generators
        fun addYearTrips(year: Int, odoBase: Double) {
            var currentOdo = odoBase

            // Monthly routine for all 12 months
            val monthsToGenerate = if (year == 2027) (1..4) else (1..12)

            for (month in monthsToGenerate) {
                val mStr = String.format("%02d", month)

                // Week 1 - Client Consulting & Office Supplies
                val d1 = "$year-$mStr-03"
                val m1 = 24.5
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d1,
                        fromLoc = "Main Office HQ",
                        toLoc = "Apex Industrial Park",
                        purpose = "Client Onsite Architecture & Contract Review",
                        category = TripCategory.BUSINESS,
                        tag = "Apex Real Estate",
                        miles = m1,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m1,
                        parkingTolls = 12.00,
                        note = "Met with Senior Engineering Team. Paid municipal garage parking."
                    )
                )
                currentOdo += m1

                val d2 = "$year-$mStr-05"
                val m2 = 14.8
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d2,
                        fromLoc = "Main Office HQ",
                        toLoc = "Office Max / Commercial Hub",
                        purpose = "Office Printers & IT Hardware Restock",
                        category = TripCategory.BUSINESS,
                        tag = "Operations",
                        miles = m2,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m2,
                        note = "Purchased backup toner and USB-C adapters"
                    )
                )
                currentOdo += m2

                // Week 1 - Daily Commute
                val dComm = "$year-$mStr-06"
                val mComm = 13.5
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = dComm,
                        fromLoc = "Home Residence",
                        toLoc = "Main Office HQ",
                        purpose = "Daily Commute",
                        category = TripCategory.PERSONAL,
                        isCommute = true,
                        miles = mComm,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + mComm,
                        note = "Home to office travel (statutory non-deductible)"
                    )
                )
                currentOdo += mComm

                // Week 2 - Delivery / Gig Shift
                val d3 = "$year-$mStr-10"
                val m3 = 45.2
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d3,
                        fromLoc = "Metro City Center",
                        toLoc = "Suburban Dropoffs (14 deliveries)",
                        purpose = "Dinner Delivery Courier Shift",
                        category = TripCategory.BUSINESS,
                        isShift = true,
                        platform = "DoorDash",
                        tag = "Delivery",
                        miles = m3,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m3,
                        parkingTolls = 3.50,
                        note = "Peak hours dinner surge in commercial & residential zones"
                    )
                )
                currentOdo += m3

                // Week 2 - Medical Appointment
                val dMed = "$year-$mStr-12"
                val mMed = 19.0
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = dMed,
                        fromLoc = "Home Residence",
                        toLoc = "Regional Medical Center & Pharmacy",
                        purpose = "Prescription Refill & Specialist Follow-up",
                        category = TripCategory.MEDICAL,
                        miles = mMed,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + mMed,
                        parkingTolls = 5.00,
                        note = "Doctor visit and lab testing travel"
                    )
                )
                currentOdo += mMed

                // Week 3 - Rideshare / Airport Run
                val d4 = "$year-$mStr-17"
                val m4 = 36.8
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d4,
                        fromLoc = "International Airport",
                        toLoc = "Financial District Hotels",
                        purpose = "Rideshare Executive Airport Transfers",
                        category = TripCategory.BUSINESS,
                        isShift = true,
                        platform = "Uber",
                        tag = "Rideshare",
                        miles = m4,
                        roundTrip = true,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m4,
                        parkingTolls = 9.00,
                        note = "Airport express toll tag applied"
                    )
                )
                currentOdo += m4

                // Week 3 - Client Strategy Session
                val d5 = "$year-$mStr-20"
                val m5 = 28.4
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d5,
                        fromLoc = "Main Office HQ",
                        toLoc = "Skyline Towers (Suite 1400)",
                        purpose = "Quarterly Tax Strategy & Financial Audit",
                        category = TripCategory.BUSINESS,
                        tag = "CPA Advisory",
                        miles = m5,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m5,
                        parkingTolls = 16.00,
                        note = "Consultation with financial advisory board"
                    )
                )
                currentOdo += m5

                // Week 4 - Charity Volunteer Transport
                val dChar = "$year-$mStr-24"
                val mChar = 22.0
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = dChar,
                        fromLoc = "Central Community Food Bank",
                        toLoc = "West Valley Community Shelters",
                        purpose = "Meals on Wheels & Emergency Pantry Delivery",
                        category = TripCategory.CHARITY,
                        miles = mChar,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + mChar,
                        note = "Volunteer driver delivery route"
                    )
                )
                currentOdo += mChar

                // Week 4 - Client Emergency Site Call
                val d6 = "$year-$mStr-27"
                val m6 = 31.6
                tripsToInsert.add(
                    Trip(
                        vehicleId = v1Id,
                        date = d6,
                        fromLoc = "Main Office HQ",
                        toLoc = "Bayside Logistics Center",
                        purpose = "Emergency Server Inspection & Deployment",
                        category = TripCategory.BUSINESS,
                        tag = "Logistics Corp",
                        miles = m6,
                        odoStart = currentOdo,
                        odoEnd = currentOdo + m6,
                        parkingTolls = 8.50,
                        note = "Onsite hardware repair completed"
                    )
                )
                currentOdo += m6

                // Secondary Vehicle Delivery Trips for 2025 & 2026
                if (year in 2025..2026) {
                    val dTransit = "$year-$mStr-15"
                    val mTransit = 54.0
                    tripsToInsert.add(
                        Trip(
                            vehicleId = v2Id,
                            date = dTransit,
                            fromLoc = "Northside Distribution Hub",
                            toLoc = "Commercial Delivery Route",
                            purpose = "Bulk Commercial Package Deliveries",
                            category = TripCategory.BUSINESS,
                            isShift = true,
                            platform = "Amazon Flex",
                            tag = "Cargo Route",
                            miles = mTransit,
                            parkingTolls = 4.00,
                            note = "Heavy cargo deliveries across commercial sector"
                        )
                    )
                }
            }
        }

        // Generate data for 2024, 2025, 2026, and upcoming 2027
        addYearTrips(2024, 12400.0)
        addYearTrips(2025, 27850.0)
        addYearTrips(2026, 44920.0)
        addYearTrips(2027, 61500.0)

        repository.insertTrips(tripsToInsert)
    }

    suspend fun clearAllData(repository: MileDiaryRepository) = withContext(Dispatchers.IO) {
        repository.deleteAllTrips()
        repository.deleteAllBoundaries()
        repository.deleteAllTemplates()
    }
}
