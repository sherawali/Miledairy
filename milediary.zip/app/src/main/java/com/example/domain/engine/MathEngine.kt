package com.example.domain.engine

import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

object MathEngine {

    /**
     * Computes trip miles considering odometer mode, direct miles mode, and odometer rollover.
     */
    fun calculateTripMiles(
        directMiles: Double?,
        odoStart: Double?,
        odoEnd: Double?,
        isRollover: Boolean = false,
        isRoundTrip: Boolean = false
    ): Double {
        val miles = if (odoStart != null && odoEnd != null) {
            if (isRollover) {
                // Meter rollover e.g. 999,950 -> 000,080 on a 1,000,000 max meter
                maxOf(0.0, (1_000_000.0 - odoStart) + odoEnd)
            } else {
                maxOf(0.0, odoEnd - odoStart)
            }
        } else {
            val base = maxOf(0.0, directMiles ?: 0.0)
            if (isRoundTrip) base * 2.0 else base
        }
        return roundToOneDecimal(miles)
    }

    /**
     * Resolves the IRS standard rate in cents for a given category and date.
     */
    fun getRateCentsForDate(
        dateStr: String,
        category: TripCategory,
        isCommute: Boolean,
        ratePeriods: List<RatePeriod>
    ): Double {
        if (!category.irsDeductible || isCommute) return 0.0

        val year = try {
            LocalDate.parse(dateStr).year
        } catch (e: Exception) {
            dateStr.take(4).toIntOrNull() ?: 2026
        }

        // Try to find matching rate period from database
        val matchingPeriod = ratePeriods.firstOrNull { period ->
            period.year == year &&
                    period.category == category &&
                    dateStr >= period.startDate &&
                    dateStr <= period.endDate
        }

        if (matchingPeriod != null) {
            return matchingPeriod.rateCents
        }

        // Hardened statutory fallback if user hasn't added custom rate
        return when (category) {
            TripCategory.BUSINESS -> {
                when {
                    year >= 2026 && dateStr >= "2026-07-01" -> 76.0
                    year >= 2026 -> 72.5
                    year == 2025 -> 70.0
                    else -> 67.0
                }
            }
            TripCategory.CHARITY -> 14.0 // Fixed statutory rate
            TripCategory.MEDICAL -> {
                when {
                    year >= 2026 && dateStr >= "2026-07-01" -> 23.5
                    year >= 2026 -> 20.5
                    year == 2025 -> 21.0
                    else -> 21.0
                }
            }
            TripCategory.PERSONAL -> 0.0
        }
    }

    /**
     * Computes the exact tax deduction dollar amount for a single trip.
     * IRS Pub 463: Standard mileage deduction + allowable out-of-pocket business parking & tolls.
     */
    fun calculateTripDeduction(
        miles: Double,
        rateCents: Double,
        parkingTolls: Double? = null
    ): Double {
        val tollsBD = if (parkingTolls != null && parkingTolls > 0.0) {
            BigDecimal.valueOf(parkingTolls)
        } else {
            BigDecimal.ZERO
        }
        if (miles <= 0.0 || rateCents <= 0.0) {
            return tollsBD.setScale(2, RoundingMode.HALF_UP).toDouble()
        }
        val rateDollars = BigDecimal.valueOf(rateCents).divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP)
        val milesBD = BigDecimal.valueOf(miles)
        val mileageDeduction = milesBD.multiply(rateDollars)
        return mileageDeduction.add(tollsBD).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    /**
     * Data class holding aggregated calculations for a collection of trips.
     */
    data class AggregatedStats(
        val totalMiles: Double = 0.0,
        val businessMiles: Double = 0.0,
        val personalMiles: Double = 0.0,
        val charityMiles: Double = 0.0,
        val medicalMiles: Double = 0.0,
        val commuteMiles: Double = 0.0,
        val totalDeduction: Double = 0.0,
        val businessDeduction: Double = 0.0,
        val charityDeduction: Double = 0.0,
        val medicalDeduction: Double = 0.0,
        val totalParkingTolls: Double = 0.0,
        val estimatedTaxSavings: Double = 0.0, // Based on user tax bracket e.g. 25%
        val businessPercentage: Double = 0.0,
        val tripCount: Int = 0,
        val shiftCount: Int = 0
    ) {
        companion object {
            val EMPTY = AggregatedStats()
        }
    }

    /**
     * Calculates comprehensive stats from a list of trips and rate periods.
     */
    fun calculateStats(
        trips: List<Trip>,
        ratePeriods: List<RatePeriod>,
        taxBracketPercent: Double = 25.0,
        odoAnnualSpan: Double? = null
    ): AggregatedStats {
        var totalMiles = 0.0
        var businessMiles = 0.0
        var personalMiles = 0.0
        var charityMiles = 0.0
        var medicalMiles = 0.0
        var commuteMiles = 0.0
        var totalParkingTolls = 0.0

        var businessDeductionBD = BigDecimal.ZERO
        var charityDeductionBD = BigDecimal.ZERO
        var medicalDeductionBD = BigDecimal.ZERO
        var shifts = 0

        for (trip in trips) {
            val mi = trip.miles
            totalMiles += mi
            if (trip.isShift) shifts++
            if (trip.isCommute) {
                commuteMiles += mi
                continue
            }

            val rate = getRateCentsForDate(trip.date, trip.category, trip.isCommute, ratePeriods)
            val tolls = if (trip.category == TripCategory.BUSINESS && trip.parkingTolls != null && trip.parkingTolls > 0.0) {
                trip.parkingTolls
            } else 0.0
            totalParkingTolls += tolls

            val deduction = calculateTripDeduction(mi, rate, tolls)
            val deductionBD = BigDecimal.valueOf(deduction)

            when (trip.category) {
                TripCategory.BUSINESS -> {
                    businessMiles += mi
                    businessDeductionBD = businessDeductionBD.add(deductionBD)
                }
                TripCategory.CHARITY -> {
                    charityMiles += mi
                    charityDeductionBD = charityDeductionBD.add(deductionBD)
                }
                TripCategory.MEDICAL -> {
                    medicalMiles += mi
                    medicalDeductionBD = medicalDeductionBD.add(deductionBD)
                }
                TripCategory.PERSONAL -> {
                    personalMiles += mi
                }
            }
        }

        val totalDeductionBD = businessDeductionBD.add(charityDeductionBD).add(medicalDeductionBD)
        val totalDeduction = totalDeductionBD.setScale(2, RoundingMode.HALF_UP).toDouble()
        val estSavings = totalDeductionBD
            .multiply(BigDecimal.valueOf(taxBracketPercent))
            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP)
            .toDouble()

        val denominator = when {
            odoAnnualSpan != null && odoAnnualSpan > 0 -> odoAnnualSpan
            totalMiles > 0 -> totalMiles
            else -> 1.0
        }
        val bizPercent = if (totalMiles > 0) {
            roundToOneDecimal(minOf(100.0, (businessMiles / denominator) * 100.0))
        } else {
            0.0
        }

        return AggregatedStats(
            totalMiles = roundToOneDecimal(totalMiles),
            businessMiles = roundToOneDecimal(businessMiles),
            personalMiles = roundToOneDecimal(personalMiles),
            charityMiles = roundToOneDecimal(charityMiles),
            medicalMiles = roundToOneDecimal(medicalMiles),
            commuteMiles = roundToOneDecimal(commuteMiles),
            totalDeduction = totalDeduction,
            businessDeduction = businessDeductionBD.setScale(2, RoundingMode.HALF_UP).toDouble(),
            charityDeduction = charityDeductionBD.setScale(2, RoundingMode.HALF_UP).toDouble(),
            medicalDeduction = medicalDeductionBD.setScale(2, RoundingMode.HALF_UP).toDouble(),
            totalParkingTolls = BigDecimal.valueOf(totalParkingTolls).setScale(2, RoundingMode.HALF_UP).toDouble(),
            estimatedTaxSavings = estSavings,
            businessPercentage = bizPercent,
            tripCount = trips.size,
            shiftCount = shifts
        )
    }

    private fun roundToOneDecimal(value: Double): Double {
        return BigDecimal.valueOf(value).setScale(1, RoundingMode.HALF_UP).toDouble()
    }
}
