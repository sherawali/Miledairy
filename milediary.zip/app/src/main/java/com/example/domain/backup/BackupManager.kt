package com.example.domain.backup

import android.content.Context
import com.example.data.model.OdoBoundary
import com.example.data.model.Template
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.data.model.Vehicle
import com.example.data.repository.MileDiaryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {

    data class RestoreResult(
        val success: Boolean,
        val vehiclesRestored: Int = 0,
        val tripsRestored: Int = 0,
        val templatesRestored: Int = 0,
        val boundariesRestored: Int = 0,
        val message: String = ""
    )

    suspend fun generateBackupJson(repository: MileDiaryRepository): String = withContext(Dispatchers.IO) {
        val vehicles = repository.getAllVehiclesSync()
        val trips = repository.getAllTripsSync()
        val templates = repository.getAllTemplatesSync()
        val boundaries = repository.getAllBoundariesSync()
        val settings = repository.getAllSettingsSync()

        val root = JSONObject()
        root.put("appName", "MileDiary")
        root.put("schemaVersion", 2)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("exportDateFormatted", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))

        // Vehicles
        val vehiclesArray = JSONArray()
        vehicles.forEach { v ->
            val vObj = JSONObject()
            vObj.put("id", v.id)
            vObj.put("name", v.name)
            vObj.put("make", v.make)
            vObj.put("model", v.model)
            vObj.put("year", v.year)
            vObj.put("notes", v.notes)
            vObj.put("isPrimary", v.isPrimary)
            vObj.put("createdAt", v.createdAt)
            vehiclesArray.put(vObj)
        }
        root.put("vehicles", vehiclesArray)

        // Trips
        val tripsArray = JSONArray()
        trips.forEach { t ->
            val tObj = JSONObject()
            tObj.put("id", t.id)
            tObj.put("vehicleId", t.vehicleId)
            tObj.put("date", t.date)
            if (t.endDate != null) tObj.put("endDate", t.endDate)
            tObj.put("fromLoc", t.fromLoc)
            tObj.put("toLoc", t.toLoc)
            tObj.put("miles", t.miles)
            tObj.put("purpose", t.purpose)
            tObj.put("category", t.category.name)
            tObj.put("isShift", t.isShift)
            tObj.put("isCommute", t.isCommute)
            tObj.put("roundTrip", t.roundTrip)
            tObj.put("note", t.note)
            if (t.odoStart != null) tObj.put("odoStart", t.odoStart)
            if (t.odoEnd != null) tObj.put("odoEnd", t.odoEnd)
            if (t.parkingTolls != null) tObj.put("parkingTolls", t.parkingTolls)
            if (t.receiptPath != null) tObj.put("receiptPath", t.receiptPath)
            if (t.tag != null) tObj.put("tag", t.tag)
            if (t.platform != null) tObj.put("platform", t.platform)
            tObj.put("createdAt", t.createdAt)
            tripsArray.put(tObj)
        }
        root.put("trips", tripsArray)

        // Templates
        val templatesArray = JSONArray()
        templates.forEach { tmpl ->
            val tmplObj = JSONObject()
            tmplObj.put("id", tmpl.id)
            tmplObj.put("name", tmpl.name)
            tmplObj.put("fromLoc", tmpl.fromLoc)
            tmplObj.put("toLoc", tmpl.toLoc)
            tmplObj.put("miles", tmpl.miles)
            tmplObj.put("purpose", tmpl.purpose)
            tmplObj.put("category", tmpl.category.name)
            tmplObj.put("useCount", tmpl.useCount)
            tmplObj.put("lastUsed", tmpl.lastUsed)
            templatesArray.put(tmplObj)
        }
        root.put("templates", templatesArray)

        // Boundaries
        val boundariesArray = JSONArray()
        boundaries.forEach { b ->
            val bObj = JSONObject()
            bObj.put("id", b.id)
            bObj.put("vehicleId", b.vehicleId)
            bObj.put("year", b.year)
            if (b.jan1Odo != null) bObj.put("jan1Odo", b.jan1Odo)
            if (b.dec31Odo != null) bObj.put("dec31Odo", b.dec31Odo)
            boundariesArray.put(bObj)
        }
        root.put("boundaries", boundariesArray)

        // Settings
        val settingsObj = JSONObject()
        settings.forEach { s ->
            settingsObj.put(s.key, s.value)
        }
        root.put("settings", settingsObj)

        root.toString(2)
    }

    suspend fun exportBackupToFile(
        context: Context,
        repository: MileDiaryRepository
    ): File = withContext(Dispatchers.IO) {
        val jsonContent = generateBackupJson(repository)
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "MileDiary_Backup_$timestamp.json"
        val exportFile = File(context.cacheDir, fileName)
        exportFile.writeText(jsonContent, Charsets.UTF_8)
        exportFile
    }

    suspend fun performAutoBackup(
        context: Context,
        repository: MileDiaryRepository
    ): File = withContext(Dispatchers.IO) {
        val jsonContent = generateBackupJson(repository)
        val autoBackupDir = File(context.filesDir, "auto_backups").apply {
            if (!exists()) mkdirs()
        }
        val autoFile = File(autoBackupDir, "MileDiary_AutoBackup.json")
        autoFile.writeText(jsonContent, Charsets.UTF_8)

        // Maintain one rolling previous snapshot for ultra-durability
        try {
            val rollingFile = File(autoBackupDir, "MileDiary_AutoBackup_prev.json")
            if (autoFile.length() > 0) {
                autoFile.copyTo(rollingFile, overwrite = true)
            }
        } catch (_: Exception) {}

        autoFile
    }

    fun getLatestAutoBackupFile(context: Context): File? {
        val autoBackupDir = File(context.filesDir, "auto_backups")
        val autoFile = File(autoBackupDir, "MileDiary_AutoBackup.json")
        if (autoFile.exists() && autoFile.length() > 0) {
            return autoFile
        }
        val rollingFile = File(autoBackupDir, "MileDiary_AutoBackup_prev.json")
        return if (rollingFile.exists() && rollingFile.length() > 0) rollingFile else null
    }

    suspend fun restoreAutoBackup(
        context: Context,
        repository: MileDiaryRepository
    ): RestoreResult = withContext(Dispatchers.IO) {
        val backupFile = getLatestAutoBackupFile(context)
            ?: return@withContext RestoreResult(
                success = false,
                message = "No automatic backup snapshot found on device"
            )
        backupFile.inputStream().use { stream ->
            restoreBackupFromStream(stream, repository)
        }
    }

    suspend fun restoreBackupFromStream(
        inputStream: InputStream,
        repository: MileDiaryRepository
    ): RestoreResult = withContext(Dispatchers.IO) {
        try {
            val jsonString = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(jsonString)

            var vehiclesCount = 0
            var tripsCount = 0
            var templatesCount = 0
            var boundariesCount = 0

            // 1. Vehicles
            val vehicleIdMapping = mutableMapOf<Long, Long>()
            val existingVehicles = repository.getAllVehiclesSync().associateBy { it.name }

            if (root.has("vehicles")) {
                val vehiclesArray = root.getJSONArray("vehicles")
                for (i in 0 until vehiclesArray.length()) {
                    val vObj = vehiclesArray.getJSONObject(i)
                    val oldId = vObj.getLong("id")
                    val name = vObj.getString("name")
                    val existing = existingVehicles[name]

                    val finalVehicleId = if (existing != null) {
                        existing.id
                    } else {
                        repository.insertVehicle(
                            Vehicle(
                                name = name,
                                make = vObj.optString("make", ""),
                                model = vObj.optString("model", ""),
                                year = vObj.optString("year", ""),
                                notes = vObj.optString("notes", ""),
                                isPrimary = vObj.optBoolean("isPrimary", false),
                                createdAt = vObj.optLong("createdAt", System.currentTimeMillis())
                            )
                        )
                    }
                    vehicleIdMapping[oldId] = finalVehicleId
                    vehiclesCount++
                }
            }

            // 2. Templates
            if (root.has("templates")) {
                val templatesArray = root.getJSONArray("templates")
                for (i in 0 until templatesArray.length()) {
                    val tmplObj = templatesArray.getJSONObject(i)
                    val catName = tmplObj.optString("category", TripCategory.BUSINESS.name)
                    val category = runCatching { TripCategory.valueOf(catName) }.getOrDefault(TripCategory.BUSINESS)

                    repository.insertTemplate(
                        Template(
                            name = tmplObj.getString("name"),
                            fromLoc = tmplObj.getString("fromLoc"),
                            toLoc = tmplObj.getString("toLoc"),
                            miles = tmplObj.getDouble("miles"),
                            purpose = tmplObj.getString("purpose"),
                            category = category,
                            useCount = tmplObj.optInt("useCount", 0),
                            lastUsed = tmplObj.optLong("lastUsed", System.currentTimeMillis())
                        )
                    )
                    templatesCount++
                }
            }

            // 3. Boundaries
            if (root.has("boundaries")) {
                val boundariesArray = root.getJSONArray("boundaries")
                for (i in 0 until boundariesArray.length()) {
                    val bObj = boundariesArray.getJSONObject(i)
                    val oldVehicleId = bObj.getLong("vehicleId")
                    val actualVehicleId = vehicleIdMapping[oldVehicleId] ?: oldVehicleId
                    val year = bObj.getInt("year")
                    val startOdo = when {
                        bObj.has("jan1Odo") -> bObj.getDouble("jan1Odo")
                        bObj.has("startOfYearOdo") -> bObj.getDouble("startOfYearOdo")
                        else -> null
                    }
                    val endOdo = when {
                        bObj.has("dec31Odo") -> bObj.getDouble("dec31Odo")
                        bObj.has("endOfYearOdo") -> bObj.getDouble("endOfYearOdo")
                        else -> null
                    }

                    repository.saveOdoBoundary(
                        OdoBoundary(
                            vehicleId = actualVehicleId,
                            year = year,
                            jan1Odo = startOdo,
                            dec31Odo = endOdo
                        )
                    )
                    boundariesCount++
                }
            }

            // 4. Trips
            if (root.has("trips")) {
                val tripsArray = root.getJSONArray("trips")
                val tripsToInsert = mutableListOf<Trip>()

                for (i in 0 until tripsArray.length()) {
                    val tObj = tripsArray.getJSONObject(i)
                    val oldVehicleId = tObj.getLong("vehicleId")
                    val actualVehicleId = vehicleIdMapping[oldVehicleId] ?: oldVehicleId
                    val catName = tObj.optString("category", TripCategory.BUSINESS.name)
                    val category = runCatching { TripCategory.valueOf(catName) }.getOrDefault(TripCategory.BUSINESS)

                    val trip = Trip(
                        vehicleId = actualVehicleId,
                        date = tObj.getString("date"),
                        endDate = if (tObj.has("endDate")) tObj.getString("endDate") else null,
                        fromLoc = tObj.getString("fromLoc"),
                        toLoc = tObj.getString("toLoc"),
                        miles = tObj.getDouble("miles"),
                        purpose = tObj.getString("purpose"),
                        category = category,
                        isShift = tObj.optBoolean("isShift", false),
                        isCommute = tObj.optBoolean("isCommute", false),
                        roundTrip = tObj.optBoolean("roundTrip", false),
                        note = tObj.optString("note", ""),
                        odoStart = if (tObj.has("odoStart")) tObj.getDouble("odoStart") else null,
                        odoEnd = if (tObj.has("odoEnd")) tObj.getDouble("odoEnd") else null,
                        parkingTolls = if (tObj.has("parkingTolls")) tObj.getDouble("parkingTolls") else null,
                        receiptPath = if (tObj.has("receiptPath")) tObj.getString("receiptPath") else null,
                        tag = if (tObj.has("tag")) tObj.getString("tag") else null,
                        platform = if (tObj.has("platform")) tObj.getString("platform") else null,
                        createdAt = tObj.optLong("createdAt", System.currentTimeMillis())
                    )
                    tripsToInsert.add(trip)
                }

                if (tripsToInsert.isNotEmpty()) {
                    repository.insertTrips(tripsToInsert)
                    tripsCount = tripsToInsert.size
                }
            }

            // 5. Settings
            if (root.has("settings")) {
                val settingsObj = root.getJSONObject("settings")
                val keys = settingsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = settingsObj.getString(k)
                    repository.setSetting(k, v)
                }
            }

            RestoreResult(
                success = true,
                vehiclesRestored = vehiclesCount,
                tripsRestored = tripsCount,
                templatesRestored = templatesCount,
                boundariesRestored = boundariesCount,
                message = "Restored $tripsCount drives, $vehiclesCount vehicles, $templatesCount templates"
            )
        } catch (e: Exception) {
            RestoreResult(
                success = false,
                message = "Restore failed: ${e.localizedMessage ?: "Invalid backup file"}"
            )
        }
    }
}
