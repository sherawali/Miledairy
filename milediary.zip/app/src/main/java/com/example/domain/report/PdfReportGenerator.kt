package com.example.domain.report

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.data.model.OdoBoundary
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.Vehicle
import com.example.domain.engine.MathEngine
import com.example.util.FormatUtils
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    data class ReportMetadata(
        val taxpayerName: String = "",
        val businessName: String = "",
        val taxId: String = "",
        val signerName: String = "",
        val currencySymbol: String = "$",
        val distanceUnit: String = "mi"
    )

    fun generateIrsPdfReport(
        context: Context,
        taxpayerName: String,
        year: Int,
        vehicle: Vehicle?,
        boundary: OdoBoundary?,
        trips: List<Trip>,
        ratePeriods: List<RatePeriod>,
        businessName: String = "",
        taxId: String = "",
        signerName: String = "",
        currencySymbol: String = "$",
        distanceUnit: String = "mi"
    ): File {
        val pdfDocument = PdfDocument()

        val paint = Paint().apply { isAntiAlias = true }
        val headerPaint = Paint().apply {
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val rowsPerPage = 26
        val totalPages = maxOf(1, (trips.size + rowsPerPage - 1) / rowsPerPage)

        val stats = MathEngine.calculateStats(
            trips = trips,
            ratePeriods = ratePeriods,
            odoAnnualSpan = if (boundary?.jan1Odo != null && boundary.dec31Odo != null) {
                boundary.dec31Odo - boundary.jan1Odo
            } else null
        )

        try {
            for (pageIndex in 0 until totalPages) {
                // Standard A4 dimensions: 595 x 842 points
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                var y = 38f

                // --- Top Header Bar ---
                paint.color = Color.parseColor("#0F3E22") // Dark Forest Green
                canvas.drawRect(34f, y - 10f, 561f, y + 26f, paint)

                headerPaint.textSize = 13.5f
                headerPaint.color = Color.WHITE
                canvas.drawText("AUDIT-READY MILEAGE & EXPENSE RECORD", 44f, y + 14f, headerPaint)

                paint.textSize = 8.5f
                paint.color = Color.parseColor("#E0E0E0")
                paint.typeface = Typeface.DEFAULT
                canvas.drawText("IRS Pub 463 / IRC § 274(d) Compliant", 380f, y + 14f, paint)

                y += 40f

                // --- Document Metadata & Taxpayer Info ---
                paint.color = Color.parseColor("#212121")
                paint.textSize = 9.5f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val displayName = if (taxpayerName.isNotBlank()) taxpayerName else "Taxpayer / Vehicle Operator"
                val displayBiz = if (businessName.isNotBlank()) " | Business: $businessName" else ""
                val displayTaxId = if (taxId.isNotBlank()) " | Tax ID/EIN: $taxId" else ""
                canvas.drawText("Taxpayer: $displayName$displayBiz$displayTaxId", 36f, y, paint)

                paint.typeface = Typeface.DEFAULT
                val pageStr = "Page ${pageIndex + 1} of $totalPages"
                canvas.drawText(pageStr, 510f, y, paint)

                y += 14f
                val vehicleName = vehicle?.name ?: "All Registered Vehicles"
                val vehicleSpecs = if (vehicle != null && vehicle.make.isNotBlank()) " (${vehicle.year} ${vehicle.make} ${vehicle.model})" else ""
                val odoJan1 = boundary?.jan1Odo?.let { "Jan 1: ${String.format(Locale.US, "%,.0f", it)} $distanceUnit" } ?: "Jan 1 Odo: Pending"
                val odoDec31 = boundary?.dec31Odo?.let { "Dec 31: ${String.format(Locale.US, "%,.0f", it)} $distanceUnit" } ?: "Dec 31 Odo: In-Progress"
                val bizPctStr = if (stats.businessPercentage > 0.0) "${stats.businessPercentage}%" else "Calculated by Trip Ratio"
                canvas.drawText(
                    "Tax Year: $year | Vehicle: $vehicleName$vehicleSpecs | $odoJan1 | $odoDec31 | Business Use: $bizPctStr",
                    36f,
                    y,
                    paint
                )

                // --- Summary KPI Box on Page 1 ---
                if (pageIndex == 0) {
                    y += 16f
                    // Card background
                    paint.color = Color.parseColor("#F4F7F4")
                    canvas.drawRect(34f, y, 561f, y + 48f, paint)

                    // Card border
                    paint.color = Color.parseColor("#C8D8C9")
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 1f
                    canvas.drawRect(34f, y, 561f, y + 48f, paint)
                    paint.style = Paint.Style.FILL

                    // Summary items
                    val totalDistStr = FormatUtils.formatDistance(stats.totalMiles, distanceUnit)
                    val bizDistStr = FormatUtils.formatDistance(stats.businessMiles, distanceUnit)
                    val deductStr = FormatUtils.formatMoney(stats.totalDeduction, currencySymbol)
                    val tollsStr = if (stats.totalParkingTolls > 0.0) " | Tolls/Parking: ${FormatUtils.formatMoney(stats.totalParkingTolls, currencySymbol)}" else ""

                    headerPaint.textSize = 9.5f
                    headerPaint.color = Color.parseColor("#0F3E22")
                    canvas.drawText(
                        "ANNUAL SUMMARY: Total: $totalDistStr | Business: $bizDistStr | Total Drives: ${stats.tripCount}$tollsStr",
                        44f,
                        y + 18f,
                        headerPaint
                    )

                    paint.textSize = 9.5f
                    paint.color = Color.parseColor("#1B5E20")
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    canvas.drawText(
                        "TOTAL DEDUCTION / REIMBURSEMENT VALUE: $deductStr  (Calculated per Statutory IRS Standard Rates)",
                        44f,
                        y + 36f,
                        paint
                    )

                    y += 56f
                } else {
                    y += 14f
                }

                // --- Table Header Bar ---
                paint.color = Color.parseColor("#0F3E22")
                canvas.drawRect(34f, y - 6f, 561f, y + 16f, paint)

                headerPaint.color = Color.WHITE
                headerPaint.textSize = 8.5f
                canvas.drawText("Date", 38f, y + 8f, headerPaint)
                canvas.drawText("Route (Origin -> Destination)", 90f, y + 8f, headerPaint)
                canvas.drawText("Business Purpose / Client", 248f, y + 8f, headerPaint)
                canvas.drawText("Category", 385f, y + 8f, headerPaint)
                canvas.drawText("Distance", 442f, y + 8f, headerPaint)
                canvas.drawText("Rate", 486f, y + 8f, headerPaint)
                canvas.drawText("Amount", 522f, y + 8f, headerPaint)

                y += 24f

                // --- Table Rows ---
                val startIndex = pageIndex * rowsPerPage
                val endIndex = minOf(startIndex + rowsPerPage, trips.size)
                paint.textSize = 8f

                for (i in startIndex until endIndex) {
                    val trip = trips[i]
                    val rate = MathEngine.getRateCentsForDate(trip.date, trip.category, trip.isCommute, ratePeriods)
                    val deduct = MathEngine.calculateTripDeduction(trip.miles, rate, trip.parkingTolls)

                    // Row Zebra Striping
                    if (i % 2 == 1) {
                        paint.color = Color.parseColor("#F9FAF9")
                        canvas.drawRect(34f, y - 9f, 561f, y + 9f, paint)
                    }

                    // Bottom divider line
                    paint.color = Color.parseColor("#EEEEEE")
                    paint.strokeWidth = 0.5f
                    canvas.drawLine(34f, y + 9f, 561f, y + 9f, paint)

                    paint.color = Color.BLACK
                    paint.typeface = Typeface.DEFAULT

                    val dateLabel = if (trip.date.length >= 5) trip.date.substring(5) else trip.date
                    val shiftMark = if (trip.isShift) "◐ " else ""
                    val editMark = if (trip.edited) "*" else ""
                    canvas.drawText("$shiftMark$dateLabel$editMark", 38f, y + 3f, paint)

                    val route = "${trip.fromLoc} → ${trip.toLoc}"
                    val truncatedRoute = if (route.length > 32) route.take(30) + ".." else route
                    canvas.drawText(truncatedRoute, 90f, y + 3f, paint)

                    val purposeStr = if (trip.platform != null) "[${trip.platform}] ${trip.purpose}" else trip.purpose
                    val truncatedPurpose = if (purposeStr.length > 28) purposeStr.take(26) + ".." else purposeStr
                    canvas.drawText(truncatedPurpose, 248f, y + 3f, paint)

                    canvas.drawText(trip.category.displayName, 385f, y + 3f, paint)
                    canvas.drawText("${trip.miles} $distanceUnit", 442f, y + 3f, paint)
                    canvas.drawText("${rate}¢", 486f, y + 3f, paint)
                    canvas.drawText(FormatUtils.formatMoney(deduct, currencySymbol), 522f, y + 3f, paint)

                    y += 18f
                }

                // --- Official Certification & Signature Block on Last Page ---
                if (pageIndex == totalPages - 1) {
                    val certBoxY = 705f

                    // Certification box
                    paint.color = Color.parseColor("#FAFAFA")
                    canvas.drawRect(34f, certBoxY, 561f, certBoxY + 76f, paint)

                    paint.color = Color.parseColor("#D5D5D5")
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 0.8f
                    canvas.drawRect(34f, certBoxY, 561f, certBoxY + 76f, paint)
                    paint.style = Paint.Style.FILL

                    headerPaint.textSize = 7.5f
                    headerPaint.color = Color.parseColor("#0F3E22")
                    canvas.drawText("TAXPAYER / OPERATOR COMPLIANCE DECLARATION", 42f, certBoxY + 12f, headerPaint)

                    paint.textSize = 7.0f
                    paint.color = Color.parseColor("#424242")
                    paint.typeface = Typeface.DEFAULT
                    val certText1 = "Under penalties of perjury, I declare that I have examined this mileage and expense record, and to the best of my knowledge"
                    val certText2 = "and belief, it is true, correct, contemporaneous, and complete, prepared pursuant to IRC § 274(d) and IRS Publication 463."
                    canvas.drawText(certText1, 42f, certBoxY + 23f, paint)
                    canvas.drawText(certText2, 42f, certBoxY + 33f, paint)

                    // Signature line
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    val effectiveSigner = if (signerName.isNotBlank()) signerName else taxpayerName

                    if (effectiveSigner.isNotBlank()) {
                        paint.color = Color.parseColor("#1B5E20")
                        paint.textSize = 8.5f
                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                        canvas.drawText("Digitally Certified by: $effectiveSigner", 42f, certBoxY + 54f, paint)

                        paint.typeface = Typeface.DEFAULT
                        paint.color = Color.DKGRAY
                        paint.textSize = 7.5f
                        canvas.drawText("Date: $dateFormatted   |   Status: Verified Contemporaneous Log", 42f, certBoxY + 66f, paint)
                    } else {
                        paint.color = Color.BLACK
                        paint.textSize = 7.5f
                        canvas.drawText("Taxpayer Signature: _____________________________________      Date: ______________", 42f, certBoxY + 58f, paint)
                    }

                    // Disclaimer footer
                    paint.color = Color.GRAY
                    paint.textSize = 7f
                    canvas.drawText(
                        "* MileDiary logbook prepared for official tax filing and audit presentation. Keep with tax returns for 3 years pursuant to IRS rules.",
                        36f,
                        818f,
                        paint
                    )
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val fileName = "MileageLog_${year}_${System.currentTimeMillis()}.pdf"
            val outputFile = File(reportsDir, fileName)

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }

            return outputFile
        } finally {
            pdfDocument.close()
        }
    }
}
