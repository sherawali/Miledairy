package com.example.domain.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object ReceiptStorageManager {

    /**
     * Copies and safely compresses an image chosen from the Android Photo Picker into private internal app storage.
     * Prevents URI permission revocation and retains receipt photos permanently with the trip record.
     */
    suspend fun saveReceiptImage(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val receiptsDir = File(context.filesDir, "receipts").apply { mkdirs() }
            val destFile = File(receiptsDir, "receipt_${System.currentTimeMillis()}.jpg")

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                // Decode bounds first to prevent OutOfMemory errors on large camera images
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                val buffer = inputStream.readBytes()
                BitmapFactory.decodeByteArray(buffer, 0, buffer.size, options)

                // Downscale if image is exceedingly large (e.g. > 2048px width or height)
                var sampleSize = 1
                val maxDim = 2048
                while (options.outWidth / sampleSize > maxDim || options.outHeight / sampleSize > maxDim) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }
                val bitmap = BitmapFactory.decodeByteArray(buffer, 0, buffer.size, decodeOptions)

                if (bitmap != null) {
                    FileOutputStream(destFile).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
                    }
                    bitmap.recycle()
                    destFile.absolutePath
                } else {
                    // Fallback to direct raw copy if decoding wasn't possible
                    FileOutputStream(destFile).use { out ->
                        out.write(buffer)
                    }
                    destFile.absolutePath
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Removes an attached receipt file if it exists.
     */
    fun deleteReceiptImage(path: String?): Boolean {
        if (path.isNullOrBlank()) return false
        return try {
            val file = File(path)
            if (file.exists()) file.delete() else false
        } catch (e: Exception) {
            false
        }
    }
}
