package com.example.domain.report

import android.content.Context
import com.example.data.model.RatePeriod
import com.example.data.model.Trip
import com.example.data.model.TripCategory
import com.example.domain.engine.MathEngine
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.time.LocalDate

object CsvReportManager {

    fun generateCsvReport(
        context: Context,
        year: Int,
        trips: List<Trip>,
        ratePeriods: List<RatePeriod>
    ): File {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "MileDiary_Export_${year}_${System.currentTimeMillis()}.csv")

        FileOutputStream(file).bufferedWriter().use { writer ->
            // Header
            writer.write("Date,EndDate,FromLocation,ToLocation,Purpose,Category,Miles,OdoStart,OdoEnd,RateCents,DeductionDollars,ParkingTolls,ReceiptAttached,Platform,Tag,IsShift,IsCommute,Edited,Note,CreatedAt\n")

            for (trip in trips) {
                val rate = MathEngine.getRateCentsForDate(trip.date, trip.category, trip.isCommute, ratePeriods)
                val deduct = MathEngine.calculateTripDeduction(trip.miles, rate, trip.parkingTolls)

                val line = listOf(
                    escapeCsv(trip.date),
                    escapeCsv(trip.endDate ?: ""),
                    escapeCsv(trip.fromLoc),
                    escapeCsv(trip.toLoc),
                    escapeCsv(trip.purpose),
                    escapeCsv(trip.category.name),
                    trip.miles.toString(),
                    trip.odoStart?.toString() ?: "",
                    trip.odoEnd?.toString() ?: "",
                    rate.toString(),
                    String.format("%.2f", deduct),
                    trip.parkingTolls?.toString() ?: "",
                    if (!trip.receiptPath.isNullOrBlank()) "Yes" else "No",
                    escapeCsv(trip.platform ?: ""),
                    escapeCsv(trip.tag ?: ""),
                    trip.isShift.toString(),
                    trip.isCommute.toString(),
                    trip.edited.toString(),
                    escapeCsv(trip.note),
                    trip.createdAt.toString()
                ).joinToString(",")

                writer.write(line + "\n")
            }
        }

        return file
    }

    data class ImportResult(
        val totalParsed: Int,
        val importedTrips: List<Trip>,
        val duplicateCount: Int,
        val skippedCount: Int,
        val errorMessages: List<String>
    )

    fun parseCsv(
        inputStream: InputStream,
        targetVehicleId: Long,
        existingTrips: List<Trip>
    ): ImportResult {
        val reader = BufferedReader(InputStreamReader(inputStream))
        val lines = reader.readLines()
        if (lines.isEmpty()) {
            return ImportResult(0, emptyList(), 0, 0, listOf("File is empty"))
        }

        val headerTokens = parseCsvLine(lines[0]).map { it.trim().lowercase() }
        val dateIdx = headerTokens.indexOfFirst { it.contains("date") }
        val fromIdx = headerTokens.indexOfFirst { it.contains("from") || it.contains("origin") || it.contains("start location") }
        val toIdx = headerTokens.indexOfFirst { it.contains("to") || it.contains("dest") || it.contains("end location") }
        val milesIdx = headerTokens.indexOfFirst { it.contains("mile") || it.contains("distance") }
        val purposeIdx = headerTokens.indexOfFirst { it.contains("purpose") || it.contains("reason") || it.contains("description") }
        val catIdx = headerTokens.indexOfFirst { it.contains("cat") || it.contains("type") || it.contains("classification") }
        val odoStartIdx = headerTokens.indexOfFirst { it.contains("odo start") || it.contains("start odo") }
        val odoEndIdx = headerTokens.indexOfFirst { it.contains("odo end") || it.contains("end odo") }
        val parkingIdx = headerTokens.indexOfFirst { it.contains("parking") || it.contains("toll") }
        val platformIdx = headerTokens.indexOfFirst { it.contains("platform") }
        val tagIdx = headerTokens.indexOfFirst { it.contains("tag") || it.contains("client") }

        if (milesIdx == -1) {
            return ImportResult(0, emptyList(), 0, lines.size - 1, listOf("CSV must contain a 'miles' or 'distance' column"))
        }

        val imported = mutableListOf<Trip>()
        var duplicates = 0
        var skipped = 0
        val errors = mutableListOf<String>()

        val existingKeys = existingTrips.map { "${it.date}|${it.fromLoc.lowercase()}|${it.toLoc.lowercase()}|${it.miles}" }.toMutableSet()

        for (i in 1 until lines.size) {
            val line = lines[i]
            if (line.isBlank()) continue

            try {
                val tokens = parseCsvLine(line)
                if (tokens.size <= milesIdx) {
                    skipped++
                    continue
                }

                val milesVal = tokens[milesIdx].replace(",", "").toDoubleOrNull()
                if (milesVal == null || milesVal <= 0.0) {
                    skipped++
                    continue
                }

                var dateVal = if (dateIdx != -1 && dateIdx < tokens.size) tokens[dateIdx].trim() else ""
                dateVal = normalizeDate(dateVal)

                val fromVal = if (fromIdx != -1 && fromIdx < tokens.size) tokens[fromIdx].trim() else "Start"
                val toVal = if (toIdx != -1 && toIdx < tokens.size) tokens[toIdx].trim() else "Destination"
                val purposeVal = if (purposeIdx != -1 && purposeIdx < tokens.size && tokens[purposeIdx].isNotBlank()) {
                    tokens[purposeIdx].trim()
                } else {
                    "Business travel"
                }

                val catStr = if (catIdx != -1 && catIdx < tokens.size) tokens[catIdx].trim().uppercase() else "BUSINESS"
                val category = when {
                    catStr.contains("CHAR") -> TripCategory.CHARITY
                    catStr.contains("MED") -> TripCategory.MEDICAL
                    catStr.contains("PERS") -> TripCategory.PERSONAL
                    else -> TripCategory.BUSINESS
                }

                val odoStartVal = if (odoStartIdx != -1 && odoStartIdx < tokens.size) tokens[odoStartIdx].toDoubleOrNull() else null
                val odoEndVal = if (odoEndIdx != -1 && odoEndIdx < tokens.size) tokens[odoEndIdx].toDoubleOrNull() else null
                val parkingVal = if (parkingIdx != -1 && parkingIdx < tokens.size) tokens[parkingIdx].replace("$", "").trim().toDoubleOrNull() else null
                val platformVal = if (platformIdx != -1 && platformIdx < tokens.size && tokens[platformIdx].isNotBlank()) tokens[platformIdx].trim() else null
                val tagVal = if (tagIdx != -1 && tagIdx < tokens.size && tokens[tagIdx].isNotBlank()) tokens[tagIdx].trim() else null

                val dedupKey = "$dateVal|${fromVal.lowercase()}|${toVal.lowercase()}|$milesVal"
                if (existingKeys.contains(dedupKey)) {
                    duplicates++
                    continue
                }
                existingKeys.add(dedupKey)

                imported.add(
                    Trip(
                        vehicleId = targetVehicleId,
                        date = dateVal,
                        fromLoc = fromVal,
                        toLoc = toVal,
                        purpose = purposeVal,
                        category = category,
                        miles = milesVal,
                        odoStart = odoStartVal,
                        odoEnd = odoEndVal,
                        parkingTolls = parkingVal,
                        platform = platformVal,
                        tag = tagVal
                    )
                )
            } catch (e: Exception) {
                skipped++
                if (errors.size < 5) {
                    errors.add("Row ${i + 1}: ${e.message}")
                }
            }
        }

        return ImportResult(
            totalParsed = lines.size - 1,
            importedTrips = imported,
            duplicateCount = duplicates,
            skippedCount = skipped,
            errorMessages = errors
        )
    }

    fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }

    fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false
        var i = 0
        val len = line.length

        while (i < len) {
            val ch = line[i]
            if (ch == '\"') {
                if (inQuotes && i + 1 < len && line[i + 1] == '\"') {
                    sb.append('\"')
                    i += 2
                    continue
                } else {
                    inQuotes = !inQuotes
                }
            } else if (ch == ',' && !inQuotes) {
                result.add(sb.toString().trim())
                sb.clear()
            } else {
                sb.append(ch)
            }
            i++
        }
        result.add(sb.toString().trim())
        return result
    }

    fun normalizeDate(raw: String): String {
        val clean = raw.trim()
        if (clean.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) {
            return clean // Already YYYY-MM-DD
        }
        return try {
            // Handles YYYY/MM/DD, YYYY-M-D, MM/DD/YYYY, M/D/YYYY, MM-DD-YYYY
            if (clean.contains("/") || clean.contains("-")) {
                val delim = if (clean.contains("/")) "/" else "-"
                val parts = clean.split(delim)
                if (parts.size == 3) {
                    if (parts[0].length == 4) {
                        // YYYY/MM/DD or YYYY-M-D
                        val y = parts[0]
                        val m = parts[1].padStart(2, '0')
                        val d = parts[2].padStart(2, '0')
                        "$y-$m-$d"
                    } else {
                        // MM/DD/YYYY or M/D/YY or MM-DD-YYYY
                        val m = parts[0].padStart(2, '0')
                        val d = parts[1].padStart(2, '0')
                        val y = if (parts[2].length == 2) "20" + parts[2] else parts[2]
                        "$y-$m-$d"
                    }
                } else LocalDate.now().toString()
            } else {
                LocalDate.now().toString()
            }
        } catch (e: Exception) {
            LocalDate.now().toString()
        }
    }
}
