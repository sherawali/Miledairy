package com.example.util

import java.text.NumberFormat
import java.util.Locale

data class CurrencyOption(
    val code: String,
    val symbol: String,
    val displayName: String,
    val example: String
)

object FormatUtils {

    val SUPPORTED_CURRENCIES = listOf(
        CurrencyOption("USD", "$", "US Dollar ($)", "$125.00"),
        CurrencyOption("EUR", "€", "Euro (€)", "€125.00"),
        CurrencyOption("GBP", "£", "British Pound (£)", "£125.00"),
        CurrencyOption("CAD", "CA$", "Canadian Dollar (CA$)", "CA$125.00"),
        CurrencyOption("AUD", "AU$", "Australian Dollar (AU$)", "AU$125.00"),
        CurrencyOption("INR", "₹", "Indian Rupee (₹)", "₹125.00"),
        CurrencyOption("JPY", "¥", "Japanese Yen (¥)", "¥12,500"),
        CurrencyOption("CHF", "CHF ", "Swiss Franc (CHF)", "CHF 125.00"),
        CurrencyOption("NZD", "NZ$", "New Zealand Dollar (NZ$)", "NZ$125.00"),
        CurrencyOption("SEK", "kr ", "Swedish Krona (kr)", "125.00 kr"),
        CurrencyOption("ZAR", "R ", "South African Rand (R)", "R 125.00"),
        CurrencyOption("BRL", "R$", "Brazilian Real (R$)", "R$125.00"),
        CurrencyOption("MXN", "MX$", "Mexican Peso (MX$)", "MX$125.00"),
        CurrencyOption("PHP", "₱", "Philippine Peso (₱)", "₱125.00")
    )

    fun formatMoney(amount: Double, symbol: String = "$"): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        val formattedNumber = formatter.format(amount)
        return when {
            symbol.endsWith(" ") -> "$symbol$formattedNumber"
            symbol == "kr " -> "$formattedNumber kr"
            else -> "$symbol$formattedNumber"
        }
    }

    fun formatDistance(value: Double, unit: String = "mi"): String {
        val formatted = String.format(Locale.US, "%.1f", value)
        return "$formatted $unit"
    }

    fun getCurrencySymbol(currencyCode: String): String {
        return SUPPORTED_CURRENCIES.find { it.code.equals(currencyCode, ignoreCase = true) }?.symbol ?: "$"
    }
}
